//
//  PrefsAccountsVC.m
//  Itsycal
//

#import "PrefsAccountsVC.h"
#import "RemoteCenter.h"
#import "MoVFLHelper.h"

@implementation PrefsAccountsVC
{
    NSTextField *_clientID;
    NSSecureTextField *_clientSecret;
    NSTextField *_clientStatus;
    NSButton *_saveClient;
    NSTableView *_accountsTV;
    NSButton *_addGoogle, *_addCalDAV, *_remove, *_signInAgain, *_syncNow;
    NSTextField *_waiting;
    NSButton *_cancelWaiting;
    NSArray<RemoteAccount *> *_accounts;
    BOOL _signingIn;
}

- (void)loadView
{
    NSView *v = [NSView new];

    NSTextField* (^label)(NSString *, BOOL) = ^NSTextField *(NSString *s, BOOL bold) {
        NSTextField *t = [NSTextField labelWithString:s];
        if (bold) t.font = [NSFont boldSystemFontOfSize:[NSFont systemFontSize]];
        [v addSubview:t];
        return t;
    };
    NSTextField* (^note)(NSString *) = ^NSTextField *(NSString *s) {
        NSTextField *t = [NSTextField wrappingLabelWithString:s];
        t.font = [NSFont systemFontOfSize:[NSFont smallSystemFontSize]];
        t.textColor = [NSColor secondaryLabelColor];
        t.preferredMaxLayoutWidth = 400;
        [v addSubview:t];
        return t;
    };
    NSButton* (^button)(NSString *, SEL) = ^NSButton *(NSString *title, SEL action) {
        NSButton *b = [NSButton buttonWithTitle:title target:self action:action];
        [v addSubview:b];
        return b;
    };

    // --- Google sign-in app ---
    NSTextField *googleHeader = label(NSLocalizedString(@"Google sign-in app", @""), YES);
    NSTextField *googleNote = note(NSLocalizedString(@"Itsycal signs in to Google with your own OAuth client (Desktop app) from console.cloud.google.com. The ID and secret are stored only in this Mac's keychain.", @""));
    NSTextField *idLabel = label(NSLocalizedString(@"Client ID:", @""), NO);
    _clientID = [NSTextField textFieldWithString:@""];
    _clientID.placeholderString = NSLocalizedString(@"…apps.googleusercontent.com", @"");
    [v addSubview:_clientID];
    NSTextField *secretLabel = label(NSLocalizedString(@"Client secret:", @""), NO);
    _clientSecret = [NSSecureTextField new];
    [v addSubview:_clientSecret];
    _saveClient = button(NSLocalizedString(@"Save to Keychain", @""), @selector(saveClient:));
    _clientStatus = label(@"", NO);
    _clientStatus.font = [NSFont systemFontOfSize:[NSFont smallSystemFontSize]];

    // --- Accounts ---
    NSTextField *accountsHeader = label(NSLocalizedString(@"Calendar accounts", @""), YES);
    _accountsTV = [NSTableView new];
    _accountsTV.headerView = nil;
    _accountsTV.dataSource = self;
    _accountsTV.delegate = self;
    _accountsTV.rowHeight = 38;
    _accountsTV.allowsEmptySelection = YES;
    _accountsTV.usesAlternatingRowBackgroundColors = NO;
    if (@available(macOS 11.0, *)) {
        _accountsTV.style = NSTableViewStylePlain;
    }
    NSTableColumn *col = [[NSTableColumn alloc] initWithIdentifier:@"Account"];
    NSTextFieldCell *cell = [NSTextFieldCell new];
    cell.wraps = YES;
    cell.lineBreakMode = NSLineBreakByWordWrapping;
    col.dataCell = cell;
    col.resizingMask = NSTableColumnAutoresizingMask;
    [_accountsTV addTableColumn:col];
    _accountsTV.columnAutoresizingStyle = NSTableViewUniformColumnAutoresizingStyle;
    NSScrollView *tvContainer = [NSScrollView new];
    tvContainer.hasVerticalScroller = YES;
    tvContainer.documentView = _accountsTV;
    tvContainer.borderType = NSLineBorder;
    [v addSubview:tvContainer];

    _addGoogle   = button(NSLocalizedString(@"Add Google Account…", @""), @selector(addGoogle:));
    _addCalDAV   = button(NSLocalizedString(@"Add CalDAV Account…", @""), @selector(addCalDAV:));
    _remove      = button(NSLocalizedString(@"Remove", @""), @selector(removeAccount:));
    _signInAgain = button(NSLocalizedString(@"Sign In Again", @""), @selector(signInAgain:));
    _syncNow     = button(NSLocalizedString(@"Sync Now", @""), @selector(syncNow:));

    _waiting = label(NSLocalizedString(@"Finish signing in in your browser…", @""), NO);
    _waiting.textColor = [NSColor systemBlueColor];
    _cancelWaiting = button(NSLocalizedString(@"Cancel", @""), @selector(cancelSignIn:));

    NSButton *chooseCalendars = button(NSLocalizedString(@"Choose Which Google Calendars Itsycal Sees…", @""), @selector(openSyncSelect:));
    NSTextField *accountsNote = note(NSLocalizedString(@"Calendars from these accounts appear in the General tab, where you can tick or untick them. For now they're read-only in Itsycal: new events still go to the Mac's calendars. Shared Google calendars (like Family) appear after you tick them on the Google page above.", @""));

    MoVFLHelper *vfl = [[MoVFLHelper alloc] initWithSuperview:v metrics:@{@"m": @20} views:NSDictionaryOfVariableBindings(googleHeader, googleNote, idLabel, _clientID, secretLabel, _clientSecret, _saveClient, _clientStatus, accountsHeader, tvContainer, _addGoogle, _addCalDAV, _remove, _signInAgain, _syncNow, _waiting, _cancelWaiting, chooseCalendars, accountsNote)];
    [vfl :@"V:|-m-[googleHeader]-4-[googleNote]-10-[_clientID]-8-[_clientSecret]-10-[_saveClient]-20-[accountsHeader]-6-[tvContainer(130)]-8-[_addGoogle]-6-[_remove]-10-[_waiting]-10-[chooseCalendars]-8-[accountsNote]-m-|"];
    [vfl :@"H:|-m-[googleHeader]-(>=m)-|"];
    [vfl :@"H:|-m-[googleNote(400)]-m-|"];
    [vfl :@"H:|-m-[idLabel]-[_clientID]-m-|" :NSLayoutFormatAlignAllFirstBaseline];
    [vfl :@"H:|-m-[secretLabel]-[_clientSecret]-m-|" :NSLayoutFormatAlignAllFirstBaseline];
    [vfl :@"H:|-m-[_saveClient]-[_clientStatus]-(>=m)-|" :NSLayoutFormatAlignAllFirstBaseline];
    [vfl :@"H:|-m-[accountsHeader]-(>=m)-|"];
    [vfl :@"H:|-m-[tvContainer]-m-|"];
    [vfl :@"H:|-m-[_addGoogle]-[_addCalDAV]-(>=m)-|" :NSLayoutFormatAlignAllFirstBaseline];
    [vfl :@"H:|-m-[_remove]-[_signInAgain]-[_syncNow]-(>=m)-|" :NSLayoutFormatAlignAllFirstBaseline];
    [vfl :@"H:|-m-[_waiting]-[_cancelWaiting]-(>=m)-|" :NSLayoutFormatAlignAllFirstBaseline];
    [vfl :@"H:|-m-[chooseCalendars]-(>=m)-|"];
    [vfl :@"H:|-m-[accountsNote]-m-|"];
    // Line up the two text fields.
    [v addConstraint:[NSLayoutConstraint constraintWithItem:_clientID attribute:NSLayoutAttributeLeading relatedBy:NSLayoutRelationEqual toItem:_clientSecret attribute:NSLayoutAttributeLeading multiplier:1 constant:0]];

    self.view = v;
}

- (void)viewWillAppear
{
    [super viewWillAppear];
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(statusChanged:)
                                                     name:RemoteCenterStatusNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(statusChanged:)
                                                     name:RemoteCenterDidChangeNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(selectionChanged:)
                                                     name:NSTableViewSelectionDidChangeNotification object:self->_accountsTV];
    });
    [self refresh];
}

- (void)statusChanged:(NSNotification *)note { [self refresh]; }
- (void)selectionChanged:(NSNotification *)note { [self updateButtons]; }

- (void)refresh
{
    if (!self.isViewLoaded) return;
    BOOL hasClient = [RemoteCenter shared].hasGoogleClient;
    _clientStatus.stringValue = hasClient ? NSLocalizedString(@"✓ Saved in your keychain", @"")
                                          : NSLocalizedString(@"Not set yet", @"");
    _clientStatus.textColor = hasClient ? [NSColor systemGreenColor] : [NSColor secondaryLabelColor];
    _clientID.placeholderString = hasClient ? NSLocalizedString(@"Saved (type here to replace)", @"")
                                            : NSLocalizedString(@"…apps.googleusercontent.com", @"");
    _clientSecret.placeholderString = hasClient ? NSLocalizedString(@"Saved (type here to replace)", @"") : @"";

    RemoteAccount *selected = [self selectedAccount];
    _accounts = [RemoteCenter shared].accounts;
    [_accountsTV reloadData];
    NSUInteger i = selected ? [_accounts indexOfObject:selected] : NSNotFound;
    if (i != NSNotFound) [_accountsTV selectRowIndexes:[NSIndexSet indexSetWithIndex:i] byExtendingSelection:NO];
    [self updateButtons];
}

- (RemoteAccount *)selectedAccount
{
    NSInteger row = _accountsTV.selectedRow;
    return (row >= 0 && row < (NSInteger)_accounts.count) ? _accounts[row] : nil;
}

- (void)updateButtons
{
    RemoteAccount *a = [self selectedAccount];
    BOOL hasClient = [RemoteCenter shared].hasGoogleClient;
    _addGoogle.enabled = hasClient && !_signingIn;
    _addCalDAV.enabled = !_signingIn;
    _remove.enabled = a != nil && !_signingIn;
    _signInAgain.enabled = a.isGoogle && hasClient && !_signingIn;
    _syncNow.enabled = _accounts.count > 0;
    _waiting.hidden = !_signingIn;
    _cancelWaiting.hidden = !_signingIn;
}

#pragma mark Table

- (NSInteger)numberOfRowsInTableView:(NSTableView *)tableView
{
    return _accounts.count;
}

- (id)tableView:(NSTableView *)tableView objectValueForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row
{
    RemoteAccount *a = _accounts[row];
    NSMutableAttributedString *s = [NSMutableAttributedString new];
    NSString *kind = a.isGoogle ? @"Google" : @"CalDAV";
    [s appendAttributedString:[[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"%@  ", a.title]
        attributes:@{NSFontAttributeName: [NSFont systemFontOfSize:[NSFont systemFontSize]]}]];
    [s appendAttributedString:[[NSAttributedString alloc] initWithString:kind
        attributes:@{NSFontAttributeName: [NSFont systemFontOfSize:[NSFont smallSystemFontSize]],
                     NSForegroundColorAttributeName: [NSColor secondaryLabelColor]}]];
    NSString *status;
    NSColor *color = [NSColor secondaryLabelColor];
    if (a.syncing) {
        status = NSLocalizedString(@"Syncing…", @"");
    } else if (a.lastError) {
        status = a.lastError;
        color = [NSColor systemRedColor];
    } else if (a.lastSync) {
        NSString *time = [NSDateFormatter localizedStringFromDate:a.lastSync dateStyle:NSDateFormatterNoStyle timeStyle:NSDateFormatterShortStyle];
        NSUInteger n = a.calendars.count;
        status = [NSString stringWithFormat:NSLocalizedString(@"%lu calendar%@ · synced at %@", @""),
                  (unsigned long)n, n == 1 ? @"" : @"s", time];
    } else {
        NSUInteger n = a.calendars.count;
        status = n ? [NSString stringWithFormat:NSLocalizedString(@"%lu calendar%@", @""), (unsigned long)n, n == 1 ? @"" : @"s"]
                   : NSLocalizedString(@"Not synced yet", @"");
    }
    [s appendAttributedString:[[NSAttributedString alloc] initWithString:[@"\n" stringByAppendingString:status]
        attributes:@{NSFontAttributeName: [NSFont systemFontOfSize:[NSFont smallSystemFontSize]],
                     NSForegroundColorAttributeName: color}]];
    return s;
}

- (BOOL)tableView:(NSTableView *)tableView shouldEditTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row
{
    return NO;
}

#pragma mark Actions

- (void)saveClient:(id)sender
{
    NSCharacterSet *ws = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    NSString *cid = [_clientID.stringValue stringByTrimmingCharactersInSet:ws];
    NSString *secret = [_clientSecret.stringValue stringByTrimmingCharactersInSet:ws];
    if (!cid.length || !secret.length) {
        NSAlert *alert = [NSAlert new];
        alert.messageText = NSLocalizedString(@"Enter both the client ID and the client secret.", @"");
        alert.informativeText = NSLocalizedString(@"You'll find them in Google Cloud Console under APIs & Services → Credentials, in your Desktop app OAuth client.", @"");
        [alert beginSheetModalForWindow:self.view.window completionHandler:nil];
        return;
    }
    if (![cid hasSuffix:@".apps.googleusercontent.com"]) {
        NSAlert *alert = [NSAlert new];
        alert.messageText = NSLocalizedString(@"That doesn't look like a Google client ID.", @"");
        alert.informativeText = NSLocalizedString(@"Client IDs end in “.apps.googleusercontent.com”.", @"");
        [alert beginSheetModalForWindow:self.view.window completionHandler:nil];
        return;
    }
    [[RemoteCenter shared] setGoogleClientID:cid secret:secret];
    _clientID.stringValue = @"";
    _clientSecret.stringValue = @"";
    [self refresh];
}

- (void)showError:(NSError *)error title:(NSString *)title
{
    if (!error || error.code == NSUserCancelledError) return;
    NSAlert *alert = [NSAlert new];
    alert.messageText = title;
    alert.informativeText = error.localizedDescription ?: @"";
    if (self.view.window) [alert beginSheetModalForWindow:self.view.window completionHandler:nil];
    else [alert runModal];
}

- (void)addGoogle:(id)sender
{
    _signingIn = YES;
    [self updateButtons];
    [[RemoteCenter shared] addGoogleAccountWithCompletion:^(NSError *error) {
        self->_signingIn = NO;
        [self refresh];
        [self showError:error title:NSLocalizedString(@"Couldn't add the Google account", @"")];
    }];
}

- (void)signInAgain:(id)sender
{
    RemoteAccount *a = [self selectedAccount];
    if (!a.isGoogle) return;
    _signingIn = YES;
    [self updateButtons];
    [[RemoteCenter shared] signInAgain:a completion:^(NSError *error) {
        self->_signingIn = NO;
        [self refresh];
        [self showError:error title:NSLocalizedString(@"Couldn't sign in", @"")];
    }];
}

- (void)cancelSignIn:(id)sender
{
    [[RemoteCenter shared] cancelSignIn];
}

- (void)addCalDAV:(id)sender
{
    NSView *box = [[NSView alloc] initWithFrame:NSMakeRect(0, 0, 320, 92)];
    NSTextField *url = [[NSTextField alloc] initWithFrame:NSMakeRect(0, 64, 320, 24)];
    url.placeholderString = NSLocalizedString(@"Server, e.g. https://example.org/calendar/", @"");
    NSTextField *user = [[NSTextField alloc] initWithFrame:NSMakeRect(0, 32, 320, 24)];
    user.placeholderString = NSLocalizedString(@"Username", @"");
    NSSecureTextField *pass = [[NSSecureTextField alloc] initWithFrame:NSMakeRect(0, 0, 320, 24)];
    pass.placeholderString = NSLocalizedString(@"Password (app password if the service has them)", @"");
    [box addSubview:url]; [box addSubview:user]; [box addSubview:pass];
    url.nextKeyView = user; user.nextKeyView = pass; pass.nextKeyView = url;

    NSAlert *alert = [NSAlert new];
    alert.messageText = NSLocalizedString(@"Add a CalDAV account", @"");
    alert.informativeText = NSLocalizedString(@"For example your Radicale backup or Purelymail. The password is stored in your keychain.", @"");
    alert.accessoryView = box;
    [alert addButtonWithTitle:NSLocalizedString(@"Add", @"")];
    [alert addButtonWithTitle:NSLocalizedString(@"Cancel", @"")];
    alert.window.initialFirstResponder = url;
    [alert beginSheetModalForWindow:self.view.window completionHandler:^(NSModalResponse code) {
        if (code != NSAlertFirstButtonReturn) return;
        self->_signingIn = YES;
        self->_waiting.stringValue = NSLocalizedString(@"Checking the server…", @"");
        [self updateButtons];
        self->_cancelWaiting.hidden = YES;
        [[RemoteCenter shared] addCalDAVAccountWithURL:url.stringValue username:user.stringValue password:pass.stringValue completion:^(NSError *error) {
            self->_signingIn = NO;
            self->_waiting.stringValue = NSLocalizedString(@"Finish signing in in your browser…", @"");
            [self refresh];
            [self showError:error title:NSLocalizedString(@"Couldn't add the account", @"")];
        }];
    }];
}

- (void)removeAccount:(id)sender
{
    RemoteAccount *a = [self selectedAccount];
    if (!a) return;
    NSAlert *alert = [NSAlert new];
    alert.messageText = [NSString stringWithFormat:NSLocalizedString(@"Remove %@ from Itsycal?", @""), a.title];
    alert.informativeText = NSLocalizedString(@"Its calendars disappear from Itsycal and its sign-in is deleted from your keychain. Nothing is deleted from the account itself.", @"");
    [alert addButtonWithTitle:NSLocalizedString(@"Remove", @"")];
    [alert addButtonWithTitle:NSLocalizedString(@"Cancel", @"")];
    [alert beginSheetModalForWindow:self.view.window completionHandler:^(NSModalResponse code) {
        if (code != NSAlertFirstButtonReturn) return;
        [[RemoteCenter shared] removeAccount:a];
        [self refresh];
    }];
}

- (void)syncNow:(id)sender
{
    [[RemoteCenter shared] syncAll];
}

- (void)openSyncSelect:(id)sender
{
    [[NSWorkspace sharedWorkspace] openURL:[NSURL URLWithString:@"https://calendar.google.com/calendar/syncselect"]];
}

@end
