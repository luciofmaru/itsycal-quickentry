//
//  RemoteHTTP.m
//  Itsycal
//

#import "RemoteHTTP.h"

NSString * const RemoteHTTPErrorDomain = @"Itsycal.RemoteHTTP";

@implementation RemoteHTTP

+ (NSURLSession *)session
{
    static NSURLSession *session;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        NSURLSessionConfiguration *config = [NSURLSessionConfiguration ephemeralSessionConfiguration];
        config.HTTPCookieAcceptPolicy = NSHTTPCookieAcceptPolicyNever;
        config.HTTPShouldSetCookies = NO;
        config.URLCache = nil;
        config.requestCachePolicy = NSURLRequestReloadIgnoringLocalCacheData;
        config.timeoutIntervalForRequest = 60;
        config.timeoutIntervalForResource = 300;
        config.HTTPAdditionalHeaders = @{@"User-Agent": @"Itsycal-QuickEntry (personal build)"};
        session = [NSURLSession sessionWithConfiguration:config];
    });
    return session;
}

+ (NSData *)send:(NSURLRequest *)request status:(NSInteger *)status error:(NSError **)error
{
    NSHTTPURLResponse *response = nil;
    NSData *data = [self send:request response:&response error:error];
    if (status) *status = response.statusCode;
    return data;
}

+ (NSData *)send:(NSURLRequest *)request response:(NSHTTPURLResponse **)responseOut error:(NSError **)error
{
    __block NSData *body = nil;
    __block NSHTTPURLResponse *response = nil;
    __block NSError *failure = nil;
    dispatch_semaphore_t done = dispatch_semaphore_create(0);
    NSURLSessionDataTask *task = [[self session] dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *resp, NSError *err) {
        body = data;
        response = [resp isKindOfClass:[NSHTTPURLResponse class]] ? (NSHTTPURLResponse *)resp : nil;
        failure = err;
        dispatch_semaphore_signal(done);
    }];
    [task resume];
    dispatch_semaphore_wait(done, DISPATCH_TIME_FOREVER);
    if (responseOut) *responseOut = response;
    if (failure || !response) {
        if (error) *error = failure ?: [self errorWithStatus:0 message:@"No reply from the server."];
        return nil;
    }
    return body ?: [NSData data];
}

+ (NSMutableURLRequest *)davRequest:(NSString *)method url:(NSURL *)url depth:(NSString *)depth body:(NSString *)body
{
    NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:url];
    req.HTTPMethod = method;
    [req setValue:depth forHTTPHeaderField:@"Depth"];
    [req setValue:@"application/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    req.HTTPBody = [body dataUsingEncoding:NSUTF8StringEncoding];
    return req;
}

+ (NSString *)formEncode:(NSString *)s
{
    NSMutableCharacterSet *allowed = [NSMutableCharacterSet alphanumericCharacterSet];
    [allowed addCharactersInString:@"-._~"];
    return [s stringByAddingPercentEncodingWithAllowedCharacters:allowed] ?: @"";
}

+ (NSMutableURLRequest *)formPost:(NSURL *)url fields:(NSDictionary<NSString *, NSString *> *)fields
{
    NSMutableArray *parts = [NSMutableArray new];
    for (NSString *k in fields) {
        [parts addObject:[NSString stringWithFormat:@"%@=%@", [self formEncode:k], [self formEncode:fields[k]]]];
    }
    NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:url];
    req.HTTPMethod = @"POST";
    [req setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    req.HTTPBody = [[parts componentsJoinedByString:@"&"] dataUsingEncoding:NSUTF8StringEncoding];
    return req;
}

+ (NSError *)errorWithStatus:(NSInteger)status message:(NSString *)message
{
    return [NSError errorWithDomain:RemoteHTTPErrorDomain code:status
                           userInfo:@{NSLocalizedDescriptionKey: message ?: @"Request failed."}];
}

@end
