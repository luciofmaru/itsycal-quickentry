//
//  RemoteCenter.h
//  Itsycal
//
//  Itsycal's own calendar accounts: Google accounts signed in directly (no
//  macOS Internet Accounts) and plain CalDAV accounts (Radicale, Purelymail,
//  ...). Keeps a local copy of each calendar, syncs every few minutes, and
//  hands EventCenter calendars and events to show next to the Mac's own.
//
//  Secrets (Google client secret, sign-in tokens, passwords) live only in the
//  login keychain. Account names and calendar lists live in Itsycal's
//  preferences; the calendar copies in ~/Library/Application Support.
//

#import <Foundation/Foundation.h>
#import "RemoteItems.h"

NS_ASSUME_NONNULL_BEGIN

// Posted (main thread) when remote calendars or events changed.
extern NSString * const RemoteCenterDidChangeNotification;
// Posted (main thread) when an account's sync status changed.
extern NSString * const RemoteCenterStatusNotification;

@interface RemoteAccount : NSObject
@property (nonatomic, copy, readonly) NSString *accountID;
@property (nonatomic, copy, readonly) NSString *kind;        // "google" or "caldav"
@property (nonatomic, copy, readonly) NSString *title;       // email or user@server
@property (nonatomic, copy, readonly, nullable) NSString *serverURL;
@property (nonatomic, copy, readonly, nullable) NSString *username;
@property (atomic, readonly) NSArray<NSDictionary *> *calendars; // {key, url, name, color, writable}
// Status (not saved)
@property (atomic, readonly, nullable) NSDate *lastSync;
@property (atomic, copy, readonly, nullable) NSString *lastError;
@property (atomic, readonly) BOOL syncing;
@property (nonatomic, readonly) BOOL isGoogle;
// Itsycal shows this account's calendars but never changes them
// (for example a backup copy).
@property (atomic, readonly) BOOL viewOnly;
// Short name for quick-entry tags: "/personal" goes to this account's main
// calendar. nil if not set.
@property (atomic, copy, readonly, nullable) NSString *nickname;
@end

@interface RemoteCenter : NSObject

+ (instancetype)shared;

// Loads saved calendar copies and starts syncing. Call once at launch.
- (void)start;

@property (nonatomic, readonly) NSArray<RemoteAccount *> *accounts;

// Google "Desktop app" OAuth client, kept in the keychain.
@property (nonatomic, readonly) BOOL hasGoogleClient;
- (void)setGoogleClientID:(NSString *)clientID secret:(NSString *)secret;
- (void)forgetGoogleClient;

// Opens the browser for Google sign-in, then adds (or re-signs-in) that account.
- (void)addGoogleAccountWithCompletion:(void (^)(NSError * _Nullable error))completion;
- (void)signInAgain:(RemoteAccount *)account completion:(void (^)(NSError * _Nullable error))completion;
- (void)cancelSignIn;

// Checks the server and login, then adds the account.
- (void)addCalDAVAccountWithURL:(NSString *)url
                       username:(NSString *)username
                       password:(NSString *)password
                       viewOnly:(BOOL)viewOnly
                     completion:(void (^)(NSError * _Nullable error))completion;

- (void)removeAccount:(RemoteAccount *)account;
- (void)setAccount:(RemoteAccount *)account viewOnly:(BOOL)viewOnly;
- (void)setAccount:(RemoteAccount *)account nickname:(nullable NSString *)nickname;

// Quick check for changes (uses sync tokens / change markers).
- (void)syncAll;
// Thorough check: also re-lists calendars whose marker looks unchanged.
- (void)syncNow;

// Changes (completion on the main thread). Fields use remote.js's format:
// { title, location, notes, url, start, end, occStart, rrule, alarm } with
// times as { y, M, d, h, m, s, tz } or { y, M, d, date: true }. Only the
// keys present are changed.
- (void)createEventWithFields:(NSDictionary *)fields
                   inCalendar:(RemoteCalendarItem *)calendar
                   completion:(void (^)(NSError * _Nullable error))completion;
// scope: "this" (one occurrence) or "all" (the whole event / series).
- (void)updateEvent:(RemoteEventItem *)event
              scope:(NSString *)scope
             fields:(NSDictionary *)fields
         completion:(void (^)(NSError * _Nullable error))completion;
// scope: "this", "future" or "all".
- (void)deleteEvent:(RemoteEventItem *)event
              scope:(NSString *)scope
         completion:(void (^)(NSError * _Nullable error))completion;

// For EventCenter (any thread).
// [NSString account title, RemoteCalendarItem, ..., NSString, ...]
- (NSArray *)sourcesAndCalendars;
- (NSArray<RemoteEventItem *> *)eventsFromDate:(NSDate *)start toDate:(NSDate *)end;

@end

NS_ASSUME_NONNULL_END
