//
//  RemoteItems.m
//  Itsycal
//

#import "RemoteItems.h"
#import <os/log.h>

// Answer nil/0/NO for any EventKit selector we don't implement, rather than
// crashing with "unrecognized selector". Only object/integer-sized return
// values are safe this way, which covers every property Itsycal reads.
#define REMOTE_ITEM_FORWARDING \
- (NSMethodSignature *)methodSignatureForSelector:(SEL)sel \
{ \
    NSMethodSignature *sig = [super methodSignatureForSelector:sel]; \
    if (sig) return sig; \
    if (sel_getName(sel)[strlen(sel_getName(sel)) - 1] == ':') return nil; \
    return [NSMethodSignature signatureWithObjCTypes:"@@:"]; \
} \
- (void)forwardInvocation:(NSInvocation *)inv \
{ \
    os_log(OS_LOG_DEFAULT, "Itsycal: remote item has no %{public}s", sel_getName(inv.selector)); \
    void *nothing = NULL; \
    [inv setReturnValue:&nothing]; \
} \
- (id)valueForUndefinedKey:(NSString *)key { return nil; }

@implementation RemoteCalendarItem

+ (BOOL)isRemote:(id)calendarOrEvent
{
    return [calendarOrEvent isKindOfClass:[RemoteCalendarItem class]] ||
           [calendarOrEvent isKindOfClass:[RemoteEventItem class]];
}

REMOTE_ITEM_FORWARDING

@end

@implementation RemoteEventItem

- (BOOL)hasRecurrenceRules { return self.recurrenceRules.count > 0; }
- (BOOL)hasNotes           { return self.notes.length > 0; }
- (BOOL)hasAttendees       { return NO; }
- (NSArray *)attendees     { return nil; }
- (id)organizer            { return nil; }
- (NSInteger)participationStatus { return EKParticipantStatusUnknown; }
- (NSString *)calendarItemIdentifier { return self.eventIdentifier; }
- (NSTimeZone *)timeZone   { return self.allDay ? nil : [NSTimeZone localTimeZone]; }

- (NSURL *)itsyWebURL
{
    NSString *email = self.calendar.accountEmail;
    if (!email.length || !self.startDate) return nil;
    NSDateComponents *c = [[NSCalendar currentCalendar] components:NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay
                                                          fromDate:self.startDate];
    NSString *user = [email stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
    return [NSURL URLWithString:[NSString stringWithFormat:@"https://calendar.google.com/calendar/r/day/%zd/%zd/%zd?authuser=%@",
                                 c.year, c.month, c.day, user]];
}

static NSInteger IntOf(id v) { return [v isKindOfClass:[NSNumber class]] ? [v integerValue] : 0; }

// Date for a time dictionary from remote.js:
// { y, M, d, h, m, s, tz: "UTC" | Olson name | null, utc: ms | null, date: bool }
static NSDate *DateFromTime(NSDictionary *t)
{
    if (![t isKindOfClass:[NSDictionary class]]) return nil;
    NSDateComponents *c = [NSDateComponents new];
    c.year = IntOf(t[@"y"]); c.month = IntOf(t[@"M"]); c.day = IntOf(t[@"d"]);
    c.hour = IntOf(t[@"h"]); c.minute = IntOf(t[@"m"]); c.second = IntOf(t[@"s"]);

    NSCalendar *cal = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    BOOL isDate = [t[@"date"] boolValue];
    NSString *tz = [t[@"tz"] isKindOfClass:[NSString class]] ? t[@"tz"] : nil;
    NSNumber *utc = [t[@"utc"] isKindOfClass:[NSNumber class]] ? t[@"utc"] : nil;

    if (isDate) {
        cal.timeZone = [NSTimeZone localTimeZone];      // all-day: local midnight
        return [cal dateFromComponents:c];
    }
    NSTimeZone *zone = nil;
    if ([tz isEqualToString:@"UTC"]) zone = [NSTimeZone timeZoneForSecondsFromGMT:0];
    else if (tz.length) zone = [NSTimeZone timeZoneWithName:tz];
    if (zone) {
        cal.timeZone = zone;
        return [cal dateFromComponents:c];
    }
    if (utc) return [NSDate dateWithTimeIntervalSince1970:utc.doubleValue / 1000.0];
    cal.timeZone = [NSTimeZone localTimeZone];          // floating time
    return [cal dateFromComponents:c];
}

static EKRecurrenceRule *RuleFrom(NSDictionary *r)
{
    if (![r isKindOfClass:[NSDictionary class]]) return nil;
    NSString *freq = r[@"freq"];
    EKRecurrenceFrequency f;
    if ([freq isEqualToString:@"DAILY"]) f = EKRecurrenceFrequencyDaily;
    else if ([freq isEqualToString:@"WEEKLY"]) f = EKRecurrenceFrequencyWeekly;
    else if ([freq isEqualToString:@"MONTHLY"]) f = EKRecurrenceFrequencyMonthly;
    else if ([freq isEqualToString:@"YEARLY"]) f = EKRecurrenceFrequencyYearly;
    else return nil;
    NSInteger interval = MAX(1, IntOf(r[@"interval"]));
    EKRecurrenceEnd *end = nil;
    if (IntOf(r[@"count"]) > 0) end = [EKRecurrenceEnd recurrenceEndWithOccurrenceCount:IntOf(r[@"count"])];
    else if ([r[@"until"] isKindOfClass:[NSDictionary class]]) {
        NSDate *until = DateFromTime(r[@"until"]);
        if (until) end = [EKRecurrenceEnd recurrenceEndWithEndDate:until];
    }
    return [[EKRecurrenceRule alloc] initRecurrenceWithFrequency:f interval:interval end:end];
}

+ (instancetype)eventWithOccurrence:(NSDictionary *)occ calendar:(RemoteCalendarItem *)calendar
{
    NSDate *start = DateFromTime(occ[@"start"]);
    NSDate *end = DateFromTime(occ[@"end"]);
    if (!start) return nil;
    if (!end || [end compare:start] == NSOrderedAscending) end = start;

    RemoteEventItem *e = [RemoteEventItem new];
    e.calendar = calendar;
    e.allDay = [occ[@"allDay"] boolValue];
    if (e.allDay) {
        // iCalendar all-day ends are exclusive (the next midnight). Match what
        // EventKit hands Itsycal: before macOS 13 the next midnight, from 13 on
        // the last second of the final day (see AdjustedEventEndDate).
        if ([end compare:start] != NSOrderedDescending) {
            end = [[NSCalendar currentCalendar] dateByAddingUnit:NSCalendarUnitDay value:1 toDate:start options:0];
        }
        if (@available(macOS 13.0, *)) end = [end dateByAddingTimeInterval:-1];
    }
    e.startDate = start;
    e.endDate = end;

    id (^str)(NSString *) = ^id(NSString *k) {
        id v = occ[k];
        return [v isKindOfClass:[NSString class]] && [v length] ? v : nil;
    };
    e.title = str(@"title") ?: @"";
    e.location = str(@"location");
    e.notes = str(@"notes");
    NSString *url = str(@"url");
    e.URL = url ? [NSURL URLWithString:url] : nil;
    e.tentative = [occ[@"tentative"] boolValue];
    EKRecurrenceRule *rule = RuleFrom(occ[@"rrule"]);
    e.recurrenceRules = rule ? @[rule] : nil;
    e.eventIdentifier = [NSString stringWithFormat:@"%@|%@|%@", calendar.calendarIdentifier,
                         str(@"uid") ?: @"", str(@"rid") ?: @""];
    return e;
}

REMOTE_ITEM_FORWARDING

@end
