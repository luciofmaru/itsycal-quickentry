//
//  RemoteJS.m
//  Itsycal
//

#import "RemoteJS.h"
#import <JavaScriptCore/JavaScriptCore.h>

@implementation RemoteJS
{
    JSContext *_ctx;
    JSValue *_call;
    dispatch_queue_t _queue;
    NSString *_loadError;
}

+ (instancetype)shared
{
    static RemoteJS *shared;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ shared = [RemoteJS new]; });
    return shared;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        _queue = dispatch_queue_create("local.itsycal.remotejs", DISPATCH_QUEUE_SERIAL);
        dispatch_sync(_queue, ^{ [self load]; });
    }
    return self;
}

- (void)load
{
    NSString *path = [[NSBundle mainBundle] pathForResource:@"remote.bundle" ofType:@"js"];
    NSString *src = path ? [NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:NULL] : nil;
    if (!src) { _loadError = @"remote.bundle.js is missing from the app."; return; }
    _ctx = [JSContext new];
    __block NSString *exception = nil;
    _ctx.exceptionHandler = ^(JSContext *context, JSValue *value) {
        exception = [value toString];
    };
    [_ctx evaluateScript:src];
    _call = _ctx[@"ItsyRemote"][@"call"];
    if (exception || !_call || _call.isUndefined) {
        _loadError = [NSString stringWithFormat:@"Couldn't load remote.bundle.js: %@", exception ?: @"no ItsyRemote.call"];
        _call = nil;
    }
}

static NSError *JSError(NSString *message)
{
    return [NSError errorWithDomain:@"Itsycal.RemoteJS" code:1
                           userInfo:@{NSLocalizedDescriptionKey: message ?: @"Unknown error"}];
}

- (nullable id)call:(NSString *)name args:(NSArray *)args error:(NSError **)error
{
    NSData *argData = [NSJSONSerialization dataWithJSONObject:args ?: @[] options:0 error:NULL];
    NSString *argJSON = argData ? [[NSString alloc] initWithData:argData encoding:NSUTF8StringEncoding] : @"[]";
    __block NSString *out = nil;
    __block NSString *failure = nil;
    dispatch_sync(_queue, ^{
        if (!self->_call) { failure = self->_loadError ?: @"JavaScript not loaded."; return; }
        @autoreleasepool {
            out = [[self->_call callWithArguments:@[name, argJSON]] toString];
        }
    });
    if (failure) { if (error) *error = JSError(failure); return nil; }
    NSDictionary *reply = [out dataUsingEncoding:NSUTF8StringEncoding]
        ? [NSJSONSerialization JSONObjectWithData:[out dataUsingEncoding:NSUTF8StringEncoding] options:0 error:NULL]
        : nil;
    if (![reply isKindOfClass:[NSDictionary class]]) {
        if (error) *error = JSError([NSString stringWithFormat:@"%@: bad reply from JavaScript", name]);
        return nil;
    }
    if (![reply[@"ok"] boolValue]) {
        if (error) *error = JSError([NSString stringWithFormat:@"%@", reply[@"error"]]);
        return nil;
    }
    return reply[@"result"];
}

@end
