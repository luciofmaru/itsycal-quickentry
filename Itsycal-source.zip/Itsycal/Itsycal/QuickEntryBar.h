//
//  QuickEntryBar.h
//  Itsycal
//
//  The quick-entry field at the top of Itsycal's window (above the month).
//  Type "Lunch Fri 1pm at Nopa /work": a preview below the field shows exactly
//  what will be created; Return saves it; Command-Return opens the full New
//  Event form with the text filled in; Esc clears.
//

#import <Cocoa/Cocoa.h>
#import <EventKit/EventKit.h>

@class EventCenter;

NS_ASSUME_NONNULL_BEGIN

@interface QuickEntryBar : NSView <NSTextFieldDelegate>

@property (nonatomic, weak) EventCenter *ec;
@property (nonatomic, weak) NSCalendar *cal;

// The day selected in the month grid (used when no date is typed).
@property (nonatomic, copy) NSDate * (^selectedDay)(void);
// Called after an event is saved.
@property (nonatomic, copy, nullable) void (^didSaveEvent)(EKEvent *event);
// Command-Return: open the full form with this text.
@property (nonatomic, copy, nullable) void (^openFullForm)(NSString *text);
// Esc on an empty field: give focus back to the calendar.
@property (nonatomic, copy, nullable) void (^resignFocus)(void);

- (void)focus;

@end

NS_ASSUME_NONNULL_END
