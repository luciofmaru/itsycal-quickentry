//
//  EventDraft.h
//  Itsycal
//
//  What the New Event / Edit Event form and the quick-entry bar want an event
//  to be, before it's saved. EventCenter saves a draft to the right place:
//  the Mac's calendars (EventKit) or one of Itsycal's own accounts (Google,
//  CalDAV), so the form doesn't need to know which.
//

#import <Foundation/Foundation.h>
#import <EventKit/EventKit.h>

NS_ASSUME_NONNULL_BEGIN

// Which part of a repeating event a change applies to.
typedef NS_ENUM(NSInteger, ItsySpan) {
    ItsySpanThisEvent,     // only this occurrence
    ItsySpanFutureEvents,  // this and later occurrences
    ItsySpanAllEvents,     // the whole series
};

@interface EventDraft : NSObject

@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy, nullable) NSString *location;
@property (nonatomic, copy, nullable) NSString *notes;
@property (nonatomic, copy, nullable) NSURL *URL;
@property (nonatomic, getter=isAllDay) BOOL allDay;
// For all-day events, endDate is any time on the last day (as in the form).
@property (nonatomic) NSDate *startDate;
@property (nonatomic) NSDate *endDate;

// EKCalendar or RemoteCalendarItem.
@property (nonatomic) id calendar;

// Repeat: only applied when repeatSet is YES (so editing other things
// leaves an event's repeat exactly as it was). nil rule = doesn't repeat.
@property (nonatomic) BOOL repeatSet;
@property (nonatomic, nullable) EKRecurrenceRule *recurrenceRule;

// Alert: only applied when alertSet is YES. nil offset = no alert.
// For new events with alertSet NO, the calendar's default alerts are used.
@property (nonatomic) BOOL alertSet;
@property (nonatomic, nullable) NSNumber *alertOffset;   // seconds from start

@end

NS_ASSUME_NONNULL_END
