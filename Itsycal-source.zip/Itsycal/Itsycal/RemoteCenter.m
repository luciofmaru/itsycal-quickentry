//
//  RemoteCenter.m
//  Itsycal
//

#import "RemoteCenter.h"
#import "RemoteHTTP.h"
#import "RemoteJS.h"
#import "GoogleOAuth.h"
#import "Keychain.h"
#import <AppKit/AppKit.h>
#import <CommonCrypto/CommonDigest.h>
#import <os/log.h>

NSString * const RemoteCenterDidChangeNotification = @"RemoteCenterDidChangeNotification";
NSString * const RemoteCenterStatusNotification    = @"RemoteCenterStatusNotification";

static NSString * const kAccountsDefaultsKey = @"RemoteAccounts";
static NSString * const kKeyClientID         = @"google.client-id";
static NSString * const kKeyClientSecret     = @"google.client-secret";
static NSString * const kGoogleCalDAVRoot    = @"https://apidata.googleusercontent.com/caldav/v2/";
static const NSTimeInterval kSyncInterval    = 5 * 60;
static const NSUInteger kMultigetBatch       = 50;

static NSError *RemoteError(NSInteger code, NSString *message)
{
    return [RemoteHTTP errorWithStatus:code message:message];
}

// ===========================================================================
#pragma mark - RemoteAccount
// ===========================================================================

@interface RemoteAccount ()
@property (nonatomic, copy, readwrite) NSString *accountID;
@property (nonatomic, copy, readwrite) NSString *kind;
@property (nonatomic, copy, readwrite) NSString *title;
@property (nonatomic, copy, readwrite, nullable) NSString *serverURL;
@property (nonatomic, copy, readwrite, nullable) NSString *username;
@property (atomic, copy, nullable) NSString *home;          // calendar home URL, once found
@property (atomic, readwrite) NSArray<NSDictionary *> *calendars;
@property (atomic, readwrite, nullable) NSDate *lastSync;
@property (atomic, copy, readwrite, nullable) NSString *lastError;
@property (atomic, readwrite) BOOL syncing;
@property (atomic, readwrite) BOOL viewOnly;
@property (atomic, copy, readwrite, nullable) NSString *nickname;
@end

@implementation RemoteAccount

- (BOOL)isGoogle { return [self.kind isEqualToString:@"google"]; }

- (NSString *)secretKey { return [NSString stringWithFormat:@"account.%@", self.accountID]; }

- (NSDictionary *)dictionary
{
    NSMutableDictionary *d = [@{@"id": self.accountID, @"kind": self.kind, @"title": self.title,
                                @"calendars": self.calendars ?: @[]} mutableCopy];
    if (self.serverURL) d[@"serverURL"] = self.serverURL;
    if (self.username) d[@"username"] = self.username;
    if (self.home) d[@"home"] = self.home;
    if (self.viewOnly) d[@"viewOnly"] = @YES;
    if (self.nickname.length) d[@"nickname"] = self.nickname;
    return d;
}

+ (nullable instancetype)accountWithDictionary:(NSDictionary *)d
{
    if (![d isKindOfClass:[NSDictionary class]] || ![d[@"id"] isKindOfClass:[NSString class]]) return nil;
    RemoteAccount *a = [RemoteAccount new];
    a.accountID = d[@"id"];
    a.kind = d[@"kind"] ?: @"caldav";
    a.title = d[@"title"] ?: @"Calendar account";
    a.serverURL = d[@"serverURL"];
    a.username = d[@"username"];
    a.home = d[@"home"];
    a.calendars = [d[@"calendars"] isKindOfClass:[NSArray class]] ? d[@"calendars"] : @[];
    a.viewOnly = [d[@"viewOnly"] boolValue];
    a.nickname = [d[@"nickname"] isKindOfClass:[NSString class]] ? d[@"nickname"] : nil;
    return a;
}

@end

// ===========================================================================
#pragma mark - RemoteCenter
// ===========================================================================

@implementation RemoteCenter
{
    NSMutableArray<RemoteAccount *> *_accounts;           // guarded by self
    NSArray *_sourcesAndCalendars;                         // guarded by self
    NSDictionary<NSString *, RemoteCalendarItem *> *_itemsByKey; // guarded by self
    NSMutableSet<NSString *> *_loadedKeys;                 // guarded by self
    NSMutableDictionary<NSString *, NSDictionary *> *_accessTokens; // sync queue only
    NSMutableDictionary<NSString *, NSDictionary *> *_caches;       // sync queue only
    dispatch_queue_t _syncQueue;
    BOOL _syncQueued;                                      // guarded by self
    NSTimer *_timer;
    BOOL _started;
}

+ (instancetype)shared
{
    static RemoteCenter *shared;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ shared = [RemoteCenter new]; });
    return shared;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        _accounts = [NSMutableArray new];
        _sourcesAndCalendars = @[];
        _itemsByKey = @{};
        _loadedKeys = [NSMutableSet new];
        _accessTokens = [NSMutableDictionary new];
        _caches = [NSMutableDictionary new];
        _syncQueue = dispatch_queue_create("local.itsycal.remotesync", DISPATCH_QUEUE_SERIAL);
        for (NSDictionary *d in [[NSUserDefaults standardUserDefaults] arrayForKey:kAccountsDefaultsKey]) {
            RemoteAccount *a = [RemoteAccount accountWithDictionary:d];
            if (a) [_accounts addObject:a];
        }
        [self rebuildItems];
    }
    return self;
}

- (void)start
{
    if (_started) return;
    _started = YES;
    // Load the saved copies first so events show right away, then sync.
    dispatch_async(_syncQueue, ^{
        for (RemoteAccount *a in self.accounts) {
            for (NSDictionary *cal in a.calendars) {
                [self loadCacheForAccount:a calendar:cal];
            }
        }
        [self postChange];
    });
    [self syncAll];
    _timer = [NSTimer scheduledTimerWithTimeInterval:kSyncInterval target:self selector:@selector(timerFired:) userInfo:nil repeats:YES];
    _timer.tolerance = 30;
    [[NSWorkspace sharedWorkspace].notificationCenter addObserver:self selector:@selector(didWake:)
                                                             name:NSWorkspaceDidWakeNotification object:nil];
}

- (void)timerFired:(NSTimer *)timer { [self syncAll]; }

- (void)didWake:(NSNotification *)note
{
    // Give the network a moment to come back.
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(15 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self syncAll];
    });
}

#pragma mark Accounts list

- (NSArray<RemoteAccount *> *)accounts
{
    @synchronized (self) { return [_accounts copy]; }
}

- (void)saveAccounts
{
    NSMutableArray *list = [NSMutableArray new];
    @synchronized (self) {
        for (RemoteAccount *a in _accounts) [list addObject:[a dictionary]];
    }
    [[NSUserDefaults standardUserDefaults] setObject:list forKey:kAccountsDefaultsKey];
}

static NSString *JSKey(RemoteAccount *a, NSDictionary *cal)
{
    return [NSString stringWithFormat:@"remote:%@:%@", a.accountID, cal[@"key"]];
}

static NSColor *ColorFromHex(NSString *hex)
{
    if (![hex isKindOfClass:[NSString class]] || hex.length != 7) return nil;
    unsigned int v = 0;
    if (![[NSScanner scannerWithString:[hex substringFromIndex:1]] scanHexInt:&v]) return nil;
    return [NSColor colorWithSRGBRed:((v >> 16) & 0xFF) / 255.0 green:((v >> 8) & 0xFF) / 255.0
                                blue:(v & 0xFF) / 255.0 alpha:1];
}

static NSColor *FallbackColor(NSString *key)
{
    static NSArray *palette;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        palette = @[@"#039BE5", @"#33B679", @"#E67C73", @"#F6BF26", @"#8E24AA",
                    @"#F4511E", @"#3F51B5", @"#0B8043", @"#D50000", @"#616161"];
    });
    NSUInteger h = 0;
    for (NSUInteger i = 0; i < key.length; i++) h = h * 31 + [key characterAtIndex:i];
    return ColorFromHex(palette[h % palette.count]);
}

- (void)rebuildItems
{
    NSMutableArray *sources = [NSMutableArray new];
    NSMutableDictionary *items = [NSMutableDictionary new];
    @synchronized (self) {
        for (RemoteAccount *a in _accounts) {
            if (a.calendars.count == 0) continue;
            NSString *source = a.nickname.length ? [NSString stringWithFormat:@"%@ (%@)", a.nickname, a.title]
                             : a.isGoogle ? [NSString stringWithFormat:@"Google: %@", a.title] : a.title;
            [sources addObject:source];
            for (NSDictionary *cal in a.calendars) {
                RemoteCalendarItem *item = [RemoteCalendarItem new];
                item.calendarIdentifier = JSKey(a, cal);
                item.calendarKey = cal[@"key"];
                item.accountID = a.accountID;
                item.accountEmail = a.isGoogle ? a.title : nil;
                item.title = cal[@"name"] ?: @"Calendar";
                item.sourceTitle = source;
                item.accountNickname = a.nickname.length ? a.nickname : nil;
                // Main calendar: a Google account's own (named after its address),
                // otherwise the account's first calendar.
                NSString *calID = a.isGoogle ? [self googleCalendarIDForKey:cal[@"key"]] : nil;
                item.isPrimary = a.isGoogle ? [calID.lowercaseString isEqualToString:a.title.lowercaseString]
                                            : (cal == a.calendars.firstObject);
                item.color = ColorFromHex(cal[@"color"]) ?: FallbackColor(cal[@"key"] ?: @"");
                item.allowsContentModifications = !a.viewOnly && [self calendarWritable:cal account:a];
                [sources addObject:item];
                items[item.calendarIdentifier] = item;
            }
        }
        _sourcesAndCalendars = sources;
        _itemsByKey = items;
    }
}

- (NSArray *)sourcesAndCalendars
{
    @synchronized (self) { return _sourcesAndCalendars; }
}

- (void)postChange
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [[NSNotificationCenter defaultCenter] postNotificationName:RemoteCenterDidChangeNotification object:self];
    });
}

- (void)postStatus
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [[NSNotificationCenter defaultCenter] postNotificationName:RemoteCenterStatusNotification object:self];
    });
}

#pragma mark Google client

- (BOOL)hasGoogleClient
{
    return [Keychain stringForKey:kKeyClientID].length > 0 && [Keychain stringForKey:kKeyClientSecret].length > 0;
}

- (void)setGoogleClientID:(NSString *)clientID secret:(NSString *)secret
{
    NSCharacterSet *ws = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    [Keychain setString:[clientID stringByTrimmingCharactersInSet:ws] forKey:kKeyClientID];
    [Keychain setString:[secret stringByTrimmingCharactersInSet:ws] forKey:kKeyClientSecret];
    @synchronized (self) { [_accessTokens removeAllObjects]; }
}

- (void)forgetGoogleClient
{
    [Keychain removeKey:kKeyClientID];
    [Keychain removeKey:kKeyClientSecret];
}

#pragma mark Adding and removing accounts

- (void)addGoogleAccountWithCompletion:(void (^)(NSError *))completion
{
    [self googleSignInWithHint:nil completion:completion];
}

- (void)signInAgain:(RemoteAccount *)account completion:(void (^)(NSError *))completion
{
    [self googleSignInWithHint:account.title completion:completion];
}

- (void)cancelSignIn
{
    [GoogleOAuth cancelSignIn];
}

- (void)googleSignInWithHint:(NSString *)hint completion:(void (^)(NSError *))completion
{
    NSString *clientID = [Keychain stringForKey:kKeyClientID];
    NSString *secret = [Keychain stringForKey:kKeyClientSecret];
    if (!clientID.length || !secret.length) {
        completion(RemoteError(0, @"Enter your Google client ID and secret first."));
        return;
    }
    [GoogleOAuth signInWithClientID:clientID secret:secret loginHint:hint completion:^(NSDictionary *result, NSError *error) {
        if (!result) { completion(error); return; }
        NSString *email = result[@"email"];
        RemoteAccount *account = nil;
        for (RemoteAccount *a in self.accounts) {
            if (a.isGoogle && [a.title isEqualToString:email]) account = a;
        }
        BOOL isNew = (account == nil);
        if (isNew) {
            account = [RemoteAccount new];
            account.accountID = [[NSUUID UUID] UUIDString];
            account.kind = @"google";
            account.title = email;
            account.calendars = @[];
        }
        if (![Keychain setString:result[@"refresh_token"] forKey:[account secretKey]]) {
            completion(RemoteError(0, @"Couldn't save the sign-in to your keychain."));
            return;
        }
        account.lastError = nil;
        dispatch_async(self->_syncQueue, ^{
            self->_accessTokens[account.accountID] = @{@"token": result[@"access_token"], @"expires": result[@"expires_at"]};
        });
        if (isNew) {
            @synchronized (self) { [self->_accounts addObject:account]; }
        }
        [self saveAccounts];
        [self postStatus];
        [self syncAccount:account completion:^{ completion(nil); }];
    }];
}

- (BOOL)calendarWritable:(NSDictionary *)cal account:(RemoteAccount *)a
{
    if ([cal[@"writable"] isKindOfClass:[NSNumber class]]) return [cal[@"writable"] boolValue];
    if (a.isGoogle) {
        // Holidays, birthdays and other Google-made calendars can't be changed.
        NSString *calID = [self googleCalendarIDForKey:cal[@"key"]] ?: @"";
        if ([calID containsString:@"#"] || [calID hasSuffix:@"@group.v.calendar.google.com"]) return NO;
    }
    return YES;
}

- (void)setAccount:(RemoteAccount *)account nickname:(NSString *)nickname
{
    nickname = [nickname stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if ([nickname hasPrefix:@"/"]) nickname = [nickname substringFromIndex:1];
    account.nickname = nickname.length ? nickname : nil;
    [self saveAccounts];
    [self rebuildItems];
    [self postChange];
    [self postStatus];
}

- (void)setAccount:(RemoteAccount *)account viewOnly:(BOOL)viewOnly
{
    account.viewOnly = viewOnly;
    [self saveAccounts];
    [self rebuildItems];
    [self postChange];
    [self postStatus];
}

- (void)addCalDAVAccountWithURL:(NSString *)urlString username:(NSString *)username password:(NSString *)password
                       viewOnly:(BOOL)viewOnly completion:(void (^)(NSError *))completion
{
    urlString = [urlString stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if (![urlString containsString:@"://"]) urlString = [@"https://" stringByAppendingString:urlString];
    NSURL *url = [NSURL URLWithString:urlString];
    if (!url.host || ![url.scheme.lowercaseString isEqualToString:@"https"]) {
        completion(RemoteError(0, @"Enter the server's https:// address."));
        return;
    }
    if (![urlString hasSuffix:@"/"]) urlString = [urlString stringByAppendingString:@"/"];

    RemoteAccount *account = [RemoteAccount new];
    account.accountID = [[NSUUID UUID] UUIDString];
    account.kind = @"caldav";
    account.serverURL = urlString;
    account.username = username;
    account.title = [NSString stringWithFormat:@"%@ on %@", username, url.host];
    account.calendars = @[];
    account.viewOnly = viewOnly;

    dispatch_async(_syncQueue, ^{
        NSError *error = nil;
        NSString *auth = [self basicAuthForUser:username password:password];
        NSString *home = [self discoverHomeForAccount:account auth:auth error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (!home) { completion(error); return; }
            if (![Keychain setString:password forKey:[account secretKey]]) {
                completion(RemoteError(0, @"Couldn't save the password to your keychain."));
                return;
            }
            account.home = home;
            @synchronized (self) { [self->_accounts addObject:account]; }
            [self saveAccounts];
            [self postStatus];
            [self syncAccount:account completion:^{ completion(nil); }];
        });
    });
}

- (void)removeAccount:(RemoteAccount *)account
{
    @synchronized (self) { [_accounts removeObject:account]; }
    [self saveAccounts];
    [self rebuildItems];
    NSString *secret = [Keychain stringForKey:[account secretKey]];
    [Keychain removeKey:[account secretKey]];
    dispatch_async(_syncQueue, ^{
        for (NSDictionary *cal in account.calendars) {
            NSString *key = JSKey(account, cal);
            [[RemoteJS shared] call:@"removeCalendar" args:@[key] error:NULL];
            [self->_caches removeObjectForKey:key];
            @synchronized (self) { [self->_loadedKeys removeObject:key]; }
        }
        [self->_accessTokens removeObjectForKey:account.accountID];
        [[NSFileManager defaultManager] removeItemAtURL:[self cacheDirForAccount:account] error:NULL];
        // Tell Google this sign-in is no longer used.
        if (account.isGoogle && secret.length) [GoogleOAuth revokeToken:secret];
        [self postChange];
        [self postStatus];
    });
}

#pragma mark Sync

- (void)syncAll
{
    @synchronized (self) {
        if (_syncQueued) return;
        _syncQueued = YES;
    }
    dispatch_async(_syncQueue, ^{
        @synchronized (self) { self->_syncQueued = NO; }
        for (RemoteAccount *a in self.accounts) [self syncAccountNow:a];
    });
}

- (void)syncAccount:(RemoteAccount *)account completion:(void (^)(void))completion
{
    dispatch_async(_syncQueue, ^{
        [self syncAccountNow:account];
        if (completion) dispatch_async(dispatch_get_main_queue(), completion);
    });
}

// Sync queue only.
- (void)syncAccountNow:(RemoteAccount *)account
{
    @synchronized (self) { if (![_accounts containsObject:account]) return; }
    account.syncing = YES;
    [self postStatus];
    NSError *error = nil;
    BOOL ok = [self syncAccountContents:account error:&error];
    account.syncing = NO;
    if (ok) {
        account.lastSync = [NSDate date];
        account.lastError = nil;
    } else {
        account.lastError = error.localizedDescription ?: @"Sync failed.";
        os_log(OS_LOG_DEFAULT, "Itsycal: sync of %{private}@ failed: %{public}@", account.title, account.lastError);
    }
    [self postStatus];
}

- (BOOL)syncAccountContents:(RemoteAccount *)account error:(NSError **)error
{
    NSString *auth = [self authForAccount:account error:error];
    if (!auth) return NO;

    // 1. Find the calendar home (once).
    if (!account.home) {
        NSString *home = [self discoverHomeForAccount:account auth:auth error:error];
        if (!home) return NO;
        account.home = home;
        [self saveAccounts];
    }

    // 2. List calendars.
    NSInteger status = 0;
    NSString *xml = [self dav:@"PROPFIND" url:account.home depth:@"1"
                         body:[self js:@"propfindCalendarsBody" args:@[]] account:account auth:&auth status:&status error:error];
    if (!xml) return NO;
    if (status == 404 && account.isGoogle == NO) {
        account.home = nil;   // look it up again next time
        if (error) *error = RemoteError(status, @"The calendar list moved on the server; will look again.");
        return NO;
    }
    if (status != 207) {
        if (error) *error = [self errorForStatus:status account:account];
        return NO;
    }
    NSError *jsError = nil;
    NSArray *found = [[RemoteJS shared] call:@"calendarList" args:@[xml, account.home] error:&jsError];
    if (![found isKindOfClass:[NSArray class]]) {
        if (error) *error = jsError ?: RemoteError(0, @"Couldn't read the calendar list.");
        return NO;
    }
    if (found.count == 0 && account.isGoogle) {
        // Fall back to the account's main calendar.
        NSString *email = [account.title stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLPathAllowedCharacterSet]];
        NSString *url = [NSString stringWithFormat:@"%@%@/events/", kGoogleCalDAVRoot, email];
        found = @[@{@"url": url, @"key": [self js:@"hrefKey" args:@[url]] ?: url}];
    }

    // 3. Names and colours. Google's CalDAV may not send names; its Calendar
    //    API does (if that API is enabled for the sign-in app).
    NSDictionary *apiInfo = account.isGoogle ? [self googleCalendarListWithAuth:auth] : nil;
    NSMutableDictionary *previous = [NSMutableDictionary new];
    for (NSDictionary *c in account.calendars) if (c[@"key"]) previous[c[@"key"]] = c;

    NSMutableArray *calendars = [NSMutableArray new];
    for (NSDictionary *f in found) {
        NSMutableDictionary *c = [NSMutableDictionary new];
        c[@"key"] = f[@"key"];
        c[@"url"] = f[@"url"];
        NSString *name = [f[@"name"] isKindOfClass:[NSString class]] ? f[@"name"] : nil;
        NSString *color = [f[@"color"] isKindOfClass:[NSString class]] ? f[@"color"] : nil;
        if (account.isGoogle) {
            NSString *calID = [self googleCalendarIDForKey:f[@"key"]];
            NSDictionary *info = calID ? apiInfo[calID] : nil;
            if (info[@"name"]) name = info[@"name"];
            if (info[@"color"]) color = info[@"color"];
            if (!name) name = previous[f[@"key"]][@"name"];
            if (!name) name = [self googleFallbackNameForID:calID account:account];
        }
        if (!name) {
            NSString *last = [[f[@"key"] stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"/"]] lastPathComponent];
            name = last.length ? last : @"Calendar";
        }
        c[@"name"] = name;
        if (color) c[@"color"] = color;
        else if (previous[f[@"key"]][@"color"]) c[@"color"] = previous[f[@"key"]][@"color"];
        if ([f[@"writable"] isKindOfClass:[NSNumber class]]) c[@"writable"] = f[@"writable"];
        c[@"marker"] = [self markerFrom:f];
        [calendars addObject:c];
    }
    [calendars sortUsingComparator:^NSComparisonResult(NSDictionary *a, NSDictionary *b) {
        return [a[@"name"] localizedCaseInsensitiveCompare:b[@"name"]];
    }];

    // 4. Contents of each calendar.
    BOOL changed = ![[self namesAndColors:calendars] isEqual:[self namesAndColors:account.calendars]];
    NSError *firstError = nil;
    for (NSDictionary *cal in calendars) {
        NSError *calError = nil;
        BOOL calChanged = NO;
        if (![self syncCalendar:cal account:account auth:&auth changed:&calChanged error:&calError]) {
            if (!firstError) firstError = calError;
        }
        changed = changed || calChanged;
    }
    // Calendars no longer offered by the server.
    NSSet *keep = [NSSet setWithArray:[calendars valueForKey:@"key"]];
    for (NSDictionary *old in account.calendars) {
        if ([keep containsObject:old[@"key"]]) continue;
        NSString *key = JSKey(account, old);
        [[RemoteJS shared] call:@"removeCalendar" args:@[key] error:NULL];
        [_caches removeObjectForKey:key];
        @synchronized (self) { [_loadedKeys removeObject:key]; }
        [[NSFileManager defaultManager] removeItemAtURL:[self cacheFileForAccount:account calendarKey:old[@"key"]] error:NULL];
        changed = YES;
    }

    @synchronized (self) { account.calendars = calendars; }
    [self saveAccounts];
    [self rebuildItems];
    if (changed) [self postChange];
    if (firstError) {
        if (error) *error = firstError;
        return NO;
    }
    return YES;
}

- (NSArray *)namesAndColors:(NSArray<NSDictionary *> *)calendars
{
    NSMutableArray *out = [NSMutableArray new];
    for (NSDictionary *c in calendars) [out addObject:@[c[@"key"] ?: @"", c[@"name"] ?: @"", c[@"color"] ?: @""]];
    return out;
}

- (NSString *)markerFrom:(NSDictionary *)f
{
    NSString *ctag = [f[@"ctag"] isKindOfClass:[NSString class]] ? f[@"ctag"] : @"";
    NSString *token = [f[@"syncToken"] isKindOfClass:[NSString class]] ? f[@"syncToken"] : @"";
    return (ctag.length || token.length) ? [NSString stringWithFormat:@"%@|%@", ctag, token] : @"";
}

// Sync queue only. Brings one calendar's local copy up to date.
- (BOOL)syncCalendar:(NSDictionary *)cal account:(RemoteAccount *)account auth:(NSString **)auth
             changed:(BOOL *)changed error:(NSError **)error
{
    NSString *key = JSKey(account, cal);
    NSDictionary *cache = _caches[key] ?: [self loadCacheForAccount:account calendar:cal];
    NSString *marker = cal[@"marker"];
    BOOL loaded;
    @synchronized (self) { loaded = [_loadedKeys containsObject:key]; }
    if (cache && loaded && marker.length && [cache[@"marker"] isEqualToString:marker]) return YES;   // unchanged

    // Which events changed?
    NSInteger status = 0;
    NSString *xml = [self dav:@"PROPFIND" url:cal[@"url"] depth:@"1" body:[self js:@"propfindEtagsBody" args:@[]]
                      account:account auth:auth status:&status error:error];
    if (!xml) return NO;
    if (status != 207) {
        if (error) *error = [self errorForStatus:status account:account];
        return NO;
    }
    NSDictionary *items = [cache[@"items"] isKindOfClass:[NSDictionary class]] ? cache[@"items"] : @{};
    NSMutableDictionary *cachedEtags = [NSMutableDictionary new];
    for (NSString *k in items) cachedEtags[k] = items[k][@"etag"] ?: @"";
    NSError *jsError = nil;
    NSDictionary *diff = [[RemoteJS shared] call:@"diffEtags" args:@[xml, cal[@"url"], cachedEtags] error:&jsError];
    if (![diff isKindOfClass:[NSDictionary class]]) {
        if (error) *error = jsError;
        return NO;
    }
    NSArray *toFetch = diff[@"fetch"];
    NSDictionary *etags = diff[@"etags"];

    NSMutableDictionary *newItems = [NSMutableDictionary new];
    for (NSString *k in etags) {
        if (items[k] && [items[k][@"etag"] isEqual:etags[k]] && [etags[k] length]) newItems[k] = items[k];
    }
    // Download new and changed events in batches.
    for (NSUInteger i = 0; i < toFetch.count; i += kMultigetBatch) {
        NSArray *batch = [toFetch subarrayWithRange:NSMakeRange(i, MIN(kMultigetBatch, toFetch.count - i))];
        NSString *body = [self js:@"multigetBody" args:@[batch]];
        NSString *reply = [self dav:@"REPORT" url:cal[@"url"] depth:@"1" body:body account:account auth:auth status:&status error:error];
        if (!reply) return NO;
        if (status != 207) {
            if (error) *error = [self errorForStatus:status account:account];
            return NO;
        }
        NSArray *got = [[RemoteJS shared] call:@"resources" args:@[reply] error:&jsError];
        if (![got isKindOfClass:[NSArray class]]) {
            if (error) *error = jsError;
            return NO;
        }
        for (NSDictionary *r in got) {
            if (![r[@"key"] isKindOfClass:[NSString class]]) continue;
            newItems[r[@"key"]] = @{@"href": r[@"href"] ?: @"", @"etag": r[@"etag"] ?: @"", @"ics": r[@"ics"] ?: @""};
        }
    }

    BOOL contentChanged = toFetch.count > 0 || [diff[@"removed"] count] > 0 || !loaded;
    NSDictionary *newCache = @{@"marker": marker ?: @"", @"url": cal[@"url"] ?: @"", @"items": newItems};
    _caches[key] = newCache;
    [self saveCache:newCache account:account calendarKey:cal[@"key"]];
    if (contentChanged) [self loadIntoJS:newCache key:key account:account];
    if (changed) *changed = contentChanged;
    return YES;
}

- (void)loadIntoJS:(NSDictionary *)cache key:(NSString *)key account:(RemoteAccount *)account
{
    NSDictionary *items = cache[@"items"];
    NSMutableArray *list = [NSMutableArray arrayWithCapacity:items.count];
    for (NSString *k in items) {
        [list addObject:@{@"key": k, @"etag": items[k][@"etag"] ?: @"", @"ics": items[k][@"ics"] ?: @""}];
    }
    NSArray *selfEmails = account.isGoogle ? @[account.title]
                        : (account.username.length && [account.username containsString:@"@"] ? @[account.username] : @[]);
    NSError *error = nil;
    NSDictionary *r = [[RemoteJS shared] call:@"setCalendar" args:@[key, list, @{@"selfEmails": selfEmails}] error:&error];
    if ([r isKindOfClass:[NSDictionary class]] && [r[@"errors"] count]) {
        os_log(OS_LOG_DEFAULT, "Itsycal: %lu events couldn't be read", (unsigned long)[r[@"errors"] count]);
    }
    @synchronized (self) { [_loadedKeys addObject:key]; }
}

#pragma mark Discovery

// Sync queue only. Returns the calendar home URL.
- (NSString *)discoverHomeForAccount:(RemoteAccount *)account auth:(NSString *)auth error:(NSError **)error
{
    NSMutableArray *starts = [NSMutableArray new];
    if (account.isGoogle) {
        [starts addObject:kGoogleCalDAVRoot];
    } else {
        [starts addObject:account.serverURL];
        NSURL *u = [NSURL URLWithString:account.serverURL];
        NSString *wellKnown = [NSString stringWithFormat:@"%@://%@%@/.well-known/caldav", u.scheme, u.host,
                               u.port ? [NSString stringWithFormat:@":%@", u.port] : @""];
        if (![wellKnown isEqualToString:account.serverURL]) [starts addObject:wellKnown];
    }
    NSError *lastError = nil;
    for (NSString *start in starts) {
        NSInteger status = 0;
        NSString *a = auth;
        NSString *xml = [self dav:@"PROPFIND" url:start depth:@"0" body:[self js:@"propfindPrincipalBody" args:@[]]
                          account:account auth:&a status:&status error:&lastError];
        if (!xml) continue;
        if (status == 401 || status == 403) {
            if (error) *error = [self errorForStatus:status account:account];
            return nil;
        }
        if (status != 207) { lastError = [self errorForStatus:status account:account]; continue; }
        NSDictionary *info = [[RemoteJS shared] call:@"principalInfo" args:@[xml, start] error:&lastError];
        if (![info isKindOfClass:[NSDictionary class]]) continue;
        NSString *home = [info[@"home"] isKindOfClass:[NSString class]] ? info[@"home"] : nil;
        NSString *principal = [info[@"principal"] isKindOfClass:[NSString class]] ? info[@"principal"] : nil;
        if (!home && principal) {
            xml = [self dav:@"PROPFIND" url:principal depth:@"0" body:[self js:@"propfindHomeBody" args:@[]]
                    account:account auth:&a status:&status error:&lastError];
            if (xml && status == 207) {
                info = [[RemoteJS shared] call:@"principalInfo" args:@[xml, principal] error:&lastError];
                if ([info isKindOfClass:[NSDictionary class]] && [info[@"home"] isKindOfClass:[NSString class]]) home = info[@"home"];
            }
        }
        if (home) return home;
        lastError = RemoteError(0, @"The server didn't say where its calendars are.");
    }
    if (account.isGoogle) {
        // Google's documented per-account path, if discovery didn't answer.
        NSString *email = [account.title stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLPathAllowedCharacterSet]];
        return [NSString stringWithFormat:@"%@%@/", kGoogleCalDAVRoot, email];
    }
    if (error) *error = lastError ?: RemoteError(0, @"Couldn't find calendars on that server.");
    return nil;
}

#pragma mark Google extras

// "/caldav/v2/<calendar id>/events/" -> calendar id
- (NSString *)googleCalendarIDForKey:(NSString *)key
{
    NSArray *parts = [key componentsSeparatedByString:@"/"];
    NSUInteger i = [parts indexOfObject:@"v2"];
    if (i == NSNotFound || i + 1 >= parts.count) return nil;
    return [parts[i + 1] stringByRemovingPercentEncoding] ?: parts[i + 1];
}

- (NSString *)googleFallbackNameForID:(NSString *)calID account:(RemoteAccount *)account
{
    if (!calID) return nil;
    if ([calID.lowercaseString isEqualToString:account.title.lowercaseString]) return account.title;
    if ([calID containsString:@"#holiday"]) return @"Holidays";
    if ([calID containsString:@"#contacts"]) return @"Birthdays";
    if ([calID containsString:@"family"]) return @"Family";
    if ([calID hasSuffix:@"@group.calendar.google.com"]) return @"Shared calendar";
    return calID;
}

// { calendar id: { name, color } } from the Google Calendar API, or nil if
// that API isn't enabled for the sign-in app (then CalDAV names are used).
- (NSDictionary *)googleCalendarListWithAuth:(NSString *)auth
{
    NSURL *url = [NSURL URLWithString:@"https://www.googleapis.com/calendar/v3/users/me/calendarList?maxResults=250&fields=items(id,summary,summaryOverride,backgroundColor)"];
    NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:url];
    [req setValue:auth forHTTPHeaderField:@"Authorization"];
    NSInteger status = 0;
    NSData *data = [RemoteHTTP send:req status:&status error:NULL];
    if (!data || status != 200) return nil;
    NSDictionary *json = [NSJSONSerialization JSONObjectWithData:data options:0 error:NULL];
    if (![json isKindOfClass:[NSDictionary class]] || ![json[@"items"] isKindOfClass:[NSArray class]]) return nil;
    NSMutableDictionary *out = [NSMutableDictionary new];
    for (NSDictionary *item in json[@"items"]) {
        if (![item isKindOfClass:[NSDictionary class]] || ![item[@"id"] isKindOfClass:[NSString class]]) continue;
        NSMutableDictionary *info = [NSMutableDictionary new];
        NSString *name = item[@"summaryOverride"] ?: item[@"summary"];
        if ([name isKindOfClass:[NSString class]] && name.length) info[@"name"] = name;
        NSString *color = item[@"backgroundColor"];
        if ([color isKindOfClass:[NSString class]] && color.length == 7) info[@"color"] = color.uppercaseString;
        out[item[@"id"]] = info;
    }
    return out;
}

#pragma mark Auth and requests

- (NSString *)basicAuthForUser:(NSString *)user password:(NSString *)password
{
    NSData *d = [[NSString stringWithFormat:@"%@:%@", user, password] dataUsingEncoding:NSUTF8StringEncoding];
    return [@"Basic " stringByAppendingString:[d base64EncodedStringWithOptions:0]];
}

// Sync queue only.
- (NSString *)authForAccount:(RemoteAccount *)account error:(NSError **)error
{
    NSString *secret = [Keychain stringForKey:[account secretKey]];
    if (!secret.length) {
        if (error) *error = RemoteError(401, account.isGoogle ? @"Not signed in. Choose “Sign In Again”."
                                                              : @"No saved password. Remove and add the account again.");
        return nil;
    }
    if (!account.isGoogle) return [self basicAuthForUser:account.username ?: @"" password:secret];

    NSDictionary *cached = _accessTokens[account.accountID];
    if (cached && [cached[@"expires"] timeIntervalSinceNow] > 60) {
        return [@"Bearer " stringByAppendingString:cached[@"token"]];
    }
    NSString *clientID = [Keychain stringForKey:kKeyClientID];
    NSString *clientSecret = [Keychain stringForKey:kKeyClientSecret];
    if (!clientID.length || !clientSecret.length) {
        if (error) *error = RemoteError(0, @"The Google client ID and secret are missing from Itsycal's settings.");
        return nil;
    }
    NSDictionary *fresh = [GoogleOAuth refreshWithClientID:clientID secret:clientSecret refreshToken:secret error:error];
    if (!fresh) return nil;
    _accessTokens[account.accountID] = @{@"token": fresh[@"access_token"], @"expires": fresh[@"expires_at"]};
    return [@"Bearer " stringByAppendingString:fresh[@"access_token"]];
}

// Sync queue only. Sends a WebDAV request; for Google, renews the access
// token once if the server says it has expired. Returns the body as text.
- (NSString *)dav:(NSString *)method url:(NSString *)url depth:(NSString *)depth body:(NSString *)body
          account:(RemoteAccount *)account auth:(NSString **)auth status:(NSInteger *)status error:(NSError **)error
{
    NSURL *u = [NSURL URLWithString:url];
    if (!u) {
        if (error) *error = RemoteError(0, [NSString stringWithFormat:@"Bad address: %@", url]);
        return nil;
    }
    for (int attempt = 0; attempt < 2; attempt++) {
        NSMutableURLRequest *req = [RemoteHTTP davRequest:method url:u depth:depth body:body ?: @""];
        [req setValue:*auth forHTTPHeaderField:@"Authorization"];
        NSData *data = [RemoteHTTP send:req status:status error:error];
        if (!data) return nil;
        if (*status == 401 && account.isGoogle && attempt == 0) {
            [_accessTokens removeObjectForKey:account.accountID];
            NSString *fresh = [self authForAccount:account error:error];
            if (!fresh) return nil;
            *auth = fresh;
            continue;
        }
        return [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding]
            ?: [[NSString alloc] initWithData:data encoding:NSISOLatin1StringEncoding] ?: @"";
    }
    return nil;
}

- (NSError *)errorForStatus:(NSInteger)status account:(RemoteAccount *)account
{
    NSString *msg;
    switch (status) {
        case 401: msg = account.isGoogle ? @"Google refused the sign-in. Choose “Sign In Again”."
                                         : @"Wrong username or password."; break;
        case 403: msg = account.isGoogle ? @"Google refused access. Check that the CalDAV API is enabled for your sign-in app."
                                         : @"The server refused access."; break;
        case 404: msg = @"The server didn't find the calendar address."; break;
        case 429: msg = @"The server asked Itsycal to slow down; will try again later."; break;
        default:  msg = [NSString stringWithFormat:@"The server replied with an error (%ld).", (long)status]; break;
    }
    return RemoteError(status, msg);
}

- (id)js:(NSString *)name args:(NSArray *)args
{
    return [[RemoteJS shared] call:name args:args error:NULL];
}

#pragma mark Local copies

- (NSURL *)cacheDirForAccount:(RemoteAccount *)account
{
    NSURL *support = [[NSFileManager defaultManager] URLsForDirectory:NSApplicationSupportDirectory inDomains:NSUserDomainMask].firstObject;
    NSString *bundleID = [NSBundle mainBundle].bundleIdentifier ?: @"Itsycal";
    return [[[support URLByAppendingPathComponent:bundleID isDirectory:YES]
             URLByAppendingPathComponent:@"Remote" isDirectory:YES]
            URLByAppendingPathComponent:account.accountID isDirectory:YES];
}

- (NSURL *)cacheFileForAccount:(RemoteAccount *)account calendarKey:(NSString *)calKey
{
    NSData *d = [calKey dataUsingEncoding:NSUTF8StringEncoding];
    unsigned char digest[CC_SHA256_DIGEST_LENGTH];
    CC_SHA256(d.bytes, (CC_LONG)d.length, digest);
    NSMutableString *hex = [NSMutableString new];
    for (int i = 0; i < 16; i++) [hex appendFormat:@"%02x", digest[i]];
    return [[self cacheDirForAccount:account] URLByAppendingPathComponent:[hex stringByAppendingPathExtension:@"plist"]];
}

- (void)saveCache:(NSDictionary *)cache account:(RemoteAccount *)account calendarKey:(NSString *)calKey
{
    NSURL *dir = [self cacheDirForAccount:account];
    [[NSFileManager defaultManager] createDirectoryAtURL:dir withIntermediateDirectories:YES
                                              attributes:@{NSFilePosixPermissions: @0700} error:NULL];
    NSData *data = [NSPropertyListSerialization dataWithPropertyList:cache format:NSPropertyListBinaryFormat_v1_0 options:0 error:NULL];
    [data writeToURL:[self cacheFileForAccount:account calendarKey:calKey] options:NSDataWritingAtomic error:NULL];
}

// Sync queue only. Reads the saved copy and hands it to JavaScript.
- (NSDictionary *)loadCacheForAccount:(RemoteAccount *)account calendar:(NSDictionary *)cal
{
    NSString *key = JSKey(account, cal);
    NSData *data = [NSData dataWithContentsOfURL:[self cacheFileForAccount:account calendarKey:cal[@"key"]]];
    if (!data) return nil;
    NSDictionary *cache = [NSPropertyListSerialization propertyListWithData:data options:NSPropertyListImmutable format:NULL error:NULL];
    if (![cache isKindOfClass:[NSDictionary class]] || ![cache[@"items"] isKindOfClass:[NSDictionary class]]) return nil;
    _caches[key] = cache;
    [self loadIntoJS:cache key:key account:account];
    return cache;
}

#pragma mark Writing events

- (RemoteAccount *)accountWithID:(NSString *)accountID
{
    for (RemoteAccount *a in self.accounts) if ([a.accountID isEqualToString:accountID]) return a;
    return nil;
}

- (NSDictionary *)calendarWithKey:(NSString *)key inAccount:(RemoteAccount *)a
{
    for (NSDictionary *c in a.calendars) if ([c[@"key"] isEqualToString:key]) return c;
    return nil;
}

// Runs `work` on the sync queue (so it never overlaps a sync), then calls
// completion on the main thread with its error, if any.
- (void)write:(NSError *(^)(void))work completion:(void (^)(NSError *))completion
{
    dispatch_async(_syncQueue, ^{
        NSError *error = nil;
        @autoreleasepool { error = work(); }
        dispatch_async(dispatch_get_main_queue(), ^{ if (completion) completion(error); });
    });
}

static NSString *HeaderValue(NSHTTPURLResponse *response, NSString *name)
{
    for (id key in response.allHeaderFields) {
        if ([key isKindOfClass:[NSString class]] && [key caseInsensitiveCompare:name] == NSOrderedSame) {
            return response.allHeaderFields[key];
        }
    }
    return nil;
}

// Sync queue only. PUT or DELETE, renewing Google sign-in once if needed.
// Returns the HTTP status (0 on network failure, with *error set).
- (NSInteger)send:(NSString *)method url:(NSString *)url ics:(NSString *)ics ifMatch:(NSString *)etag
      ifNoneMatch:(BOOL)createOnly account:(RemoteAccount *)account auth:(NSString **)auth
             etag:(NSString **)newEtag error:(NSError **)error
{
    NSURL *u = [NSURL URLWithString:url];
    if (!u) {
        if (error) *error = RemoteError(0, @"Bad event address.");
        return 0;
    }
    for (int attempt = 0; attempt < 2; attempt++) {
        NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:u];
        req.HTTPMethod = method;
        [req setValue:*auth forHTTPHeaderField:@"Authorization"];
        if (ics) {
            [req setValue:@"text/calendar; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
            req.HTTPBody = [ics dataUsingEncoding:NSUTF8StringEncoding];
        }
        if (etag.length) [req setValue:etag forHTTPHeaderField:@"If-Match"];
        if (createOnly) [req setValue:@"*" forHTTPHeaderField:@"If-None-Match"];
        NSHTTPURLResponse *response = nil;
        NSData *data = [RemoteHTTP send:req response:&response error:error];
        if (!data) return 0;
        if (response.statusCode == 401 && account.isGoogle && attempt == 0) {
            [_accessTokens removeObjectForKey:account.accountID];
            NSString *fresh = [self authForAccount:account error:error];
            if (!fresh) return 0;
            *auth = fresh;
            continue;
        }
        if (newEtag) *newEtag = HeaderValue(response, @"ETag");
        return response.statusCode;
    }
    return 0;
}

- (NSError *)writeErrorForStatus:(NSInteger)status account:(RemoteAccount *)account
{
    switch (status) {
        case 412: return RemoteError(status, @"This event was changed somewhere else since Itsycal last synced. Itsycal is fetching the latest version; please try again in a moment.");
        case 403: return RemoteError(status, @"The server didn't allow this change. The calendar may be read-only for you.");
        case 404: return RemoteError(status, @"This event is no longer on the server.");
        default:  return [self errorForStatus:status account:account];
    }
}

static BOOL OK(NSInteger status) { return status >= 200 && status < 300; }

// Sync queue only. Updates the local copy after a successful write.
- (void)storeICS:(NSString *)ics href:(NSString *)href etag:(NSString *)etag
         account:(RemoteAccount *)account calendar:(NSDictionary *)cal
{
    NSString *jsKey = JSKey(account, cal);
    NSDictionary *cache = _caches[jsKey] ?: [self loadCacheForAccount:account calendar:cal]
                       ?: @{@"marker": @"", @"url": cal[@"url"] ?: @"", @"items": @{}};
    NSMutableDictionary *items = [cache[@"items"] mutableCopy] ?: [NSMutableDictionary new];
    NSString *key = [self js:@"hrefKey" args:@[href]] ?: href;
    if (ics) items[key] = @{@"href": href, @"etag": etag ?: @"", @"ics": ics};
    else [items removeObjectForKey:key];
    // Clear the marker so the next sync double-checks with the server.
    NSDictionary *newCache = @{@"marker": @"", @"url": cache[@"url"] ?: @"", @"items": items};
    _caches[jsKey] = newCache;
    [self saveCache:newCache account:account calendarKey:cal[@"key"]];
    [self loadIntoJS:newCache key:jsKey account:account];
    [self postChange];
}

- (void)syncSoon:(RemoteAccount *)account
{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)), _syncQueue, ^{
        [self syncAccountNow:account];
    });
}

- (void)createEventWithFields:(NSDictionary *)fields inCalendar:(RemoteCalendarItem *)calendar
                   completion:(void (^)(NSError *))completion
{
    [self write:^NSError *{
        RemoteAccount *a = [self accountWithID:calendar.accountID];
        NSDictionary *cal = a ? [self calendarWithKey:calendar.calendarKey inAccount:a] : nil;
        if (!cal) return RemoteError(0, @"That calendar is no longer available.");
        if (a.viewOnly) return RemoteError(0, @"That account is view-only in Itsycal.");
        NSError *error = nil;
        NSString *auth = [self authForAccount:a error:&error];
        if (!auth) return error;

        NSString *uid = [NSUUID UUID].UUIDString.lowercaseString;
        NSMutableDictionary *f = [fields mutableCopy];
        f[@"uid"] = uid;
        NSString *ics = [[RemoteJS shared] call:@"buildEvent" args:@[f] error:&error];
        if (![ics isKindOfClass:[NSString class]]) return error ?: RemoteError(0, @"Couldn't write the event.");

        NSString *base = cal[@"url"];
        if (![base hasSuffix:@"/"]) base = [base stringByAppendingString:@"/"];
        NSString *href = [base stringByAppendingFormat:@"%@.ics", uid];
        NSString *etag = nil;
        NSInteger status = [self send:@"PUT" url:href ics:ics ifMatch:nil ifNoneMatch:YES account:a auth:&auth etag:&etag error:&error];
        if (status == 0) return error;
        if (!OK(status)) return [self writeErrorForStatus:status account:a];
        [self storeICS:ics href:href etag:etag account:a calendar:cal];
        [self syncSoon:a];
        return nil;
    } completion:completion];
}

// Sync queue only. The event's account, calendar and cached resource.
- (NSError *)locate:(RemoteEventItem *)event account:(RemoteAccount **)aOut calendar:(NSDictionary **)calOut item:(NSDictionary **)itemOut
{
    RemoteAccount *a = [self accountWithID:event.calendar.accountID];
    NSDictionary *cal = a ? [self calendarWithKey:event.calendar.calendarKey inAccount:a] : nil;
    if (!cal) return RemoteError(0, @"That calendar is no longer available.");
    if (a.viewOnly) return RemoteError(0, @"That account is view-only in Itsycal.");
    NSString *jsKey = JSKey(a, cal);
    NSDictionary *cache = _caches[jsKey] ?: [self loadCacheForAccount:a calendar:cal];
    NSDictionary *item = cache[@"items"][event.resourceKey];
    if (![item isKindOfClass:[NSDictionary class]] || ![item[@"ics"] length]) {
        return RemoteError(404, @"Itsycal doesn't have this event's details yet. Try again after the next sync.");
    }
    *aOut = a; *calOut = cal; *itemOut = item;
    return nil;
}

- (NSString *)urlForItem:(NSDictionary *)item calendar:(NSDictionary *)cal
{
    return [self js:@"resolveUrl" args:@[cal[@"url"] ?: @"", item[@"href"] ?: @""]] ?: item[@"href"];
}

- (void)updateEvent:(RemoteEventItem *)event scope:(NSString *)scope fields:(NSDictionary *)fields
         completion:(void (^)(NSError *))completion
{
    [self write:^NSError *{
        RemoteAccount *a = nil; NSDictionary *cal = nil, *item = nil;
        NSError *error = [self locate:event account:&a calendar:&cal item:&item];
        if (error) return error;
        NSString *auth = [self authForAccount:a error:&error];
        if (!auth) return error;
        NSString *ics = [[RemoteJS shared] call:@"updateEvent"
                                           args:@[item[@"ics"], event.uid ?: @"", event.recurrenceID ?: [NSNull null], scope, fields]
                                          error:&error];
        if (![ics isKindOfClass:[NSString class]]) return error ?: RemoteError(0, @"Couldn't change the event.");
        NSString *url = [self urlForItem:item calendar:cal];
        NSString *etag = nil;
        NSInteger status = [self send:@"PUT" url:url ics:ics ifMatch:item[@"etag"] ifNoneMatch:NO account:a auth:&auth etag:&etag error:&error];
        if (status == 0) return error;
        if (!OK(status)) {
            if (status == 412 || status == 404) [self syncAccountNow:a];
            return [self writeErrorForStatus:status account:a];
        }
        [self storeICS:ics href:item[@"href"] ?: url etag:etag account:a calendar:cal];
        [self syncSoon:a];
        return nil;
    } completion:completion];
}

- (void)deleteEvent:(RemoteEventItem *)event scope:(NSString *)scope completion:(void (^)(NSError *))completion
{
    [self write:^NSError *{
        RemoteAccount *a = nil; NSDictionary *cal = nil, *item = nil;
        NSError *error = [self locate:event account:&a calendar:&cal item:&item];
        if (error) return error;
        NSString *auth = [self authForAccount:a error:&error];
        if (!auth) return error;
        NSNumber *occMs = @(floor(event.startDate.timeIntervalSince1970 * 1000));
        NSDictionary *plan = [[RemoteJS shared] call:@"deleteFromEvent"
                                                args:@[item[@"ics"], event.uid ?: @"", event.recurrenceID ?: [NSNull null], scope, occMs]
                                               error:&error];
        if (![plan isKindOfClass:[NSDictionary class]]) return error ?: RemoteError(0, @"Couldn't delete the event.");
        NSString *url = [self urlForItem:item calendar:cal];
        NSString *etag = nil;
        BOOL removeWhole = [plan[@"action"] isEqualToString:@"delete"];
        NSString *ics = removeWhole ? nil : plan[@"ics"];
        NSInteger status = [self send:removeWhole ? @"DELETE" : @"PUT" url:url ics:ics ifMatch:item[@"etag"]
                          ifNoneMatch:NO account:a auth:&auth etag:&etag error:&error];
        if (status == 0) return error;
        if (removeWhole && status == 404) status = 204;   // already gone
        if (!OK(status)) {
            if (status == 412 || status == 404) [self syncAccountNow:a];
            return [self writeErrorForStatus:status account:a];
        }
        [self storeICS:ics href:item[@"href"] ?: url etag:etag account:a calendar:cal];
        [self syncSoon:a];
        return nil;
    } completion:completion];
}

#pragma mark Events for EventCenter

- (NSArray<RemoteEventItem *> *)eventsFromDate:(NSDate *)start toDate:(NSDate *)end
{
    NSArray *keys;
    NSDictionary *itemsByKey;
    @synchronized (self) {
        keys = [_loadedKeys allObjects];
        itemsByKey = _itemsByKey;
    }
    NSMutableArray *wanted = [NSMutableArray new];
    for (NSString *k in keys) if (itemsByKey[k]) [wanted addObject:k];
    if (wanted.count == 0) return @[];
    NSError *error = nil;
    NSArray *occs = [[RemoteJS shared] call:@"expand"
                                       args:@[wanted, @(floor(start.timeIntervalSince1970 * 1000)), @(ceil(end.timeIntervalSince1970 * 1000))]
                                      error:&error];
    if (![occs isKindOfClass:[NSArray class]]) {
        os_log(OS_LOG_DEFAULT, "Itsycal: couldn't expand remote events: %{public}@", error.localizedDescription);
        return @[];
    }
    NSMutableArray *events = [NSMutableArray arrayWithCapacity:occs.count];
    for (NSDictionary *occ in occs) {
        RemoteCalendarItem *cal = itemsByKey[occ[@"cal"]];
        if (!cal) continue;
        RemoteEventItem *e = [RemoteEventItem eventWithOccurrence:occ calendar:cal];
        if (e) [events addObject:e];
    }
    return events;
}

@end
