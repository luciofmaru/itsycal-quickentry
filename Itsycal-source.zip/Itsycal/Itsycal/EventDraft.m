//
//  EventDraft.m
//  Itsycal
//

#import "EventDraft.h"

@implementation EventDraft
@end
