//
//  EventViewController.m
//  Itsycal
//
//  Created by Sanjay Madan on 2/25/15.
//  Copyright (c) 2015 mowglii.com. All rights reserved.
//

#import "EventViewController.h"
#import "EventCenter.h"
#import "MoThemeView.h"
#import "MoVFLHelper.h"
#import "NSMenuItem+NoImages.h"
#import "Themer.h"
#import "QuickEntryParser.h"
#import "EventDraft.h"
#import "RemoteItems.h"
#import "MoUtils.h"

// Tag of the alert menu item meaning "keep the event's current alert(s)".
static const NSInteger kKeepAlertTag = 999;

@interface HackyTextView : NSTextView
// The placeholderAttributedString property in NSTextView
// isn't exposed publicly.
// https://stackoverflow.com/a/47223845/111418
@property NSAttributedString *placeholderAttributedString;
@end

@implementation HackyTextView
- (BOOL)becomeFirstResponder
{
    // Empty NSTextView gets focus but no cursor is visible
    // https://stackoverflow.com/a/39167917
    // https://stackoverflow.com/a/77020301/111418
    BOOL result = [super becomeFirstResponder];
    if (result) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            if (!self.string.length) {
                self.string = @" ";
                self.string = @"";
            }
        });
    }
    return result;
}
@end

// These values map to _alertAllDayStrings and _alertRegularStrings.
enum {
    kAlertAllDayNumOffsets = 5,
    kAlertRegularNumOffsets = 10
};
const NSTimeInterval kAlertAllDayRelativeOffsets[kAlertAllDayNumOffsets] = {
    MAXFLOAT, // None
    32400,    // On day of event (9 AM)
    -54000,   // 1 day before (9 AM)
    -140400,  // 2 days before (9 AM)
    -572400   // 1 week before
};
// The Repeat menu has 6 built-in items. For repeats it can't express
// ("Every Tue, Thu", "Every 3 days, 10 times") quick entry appends a
// separator and then one custom item, at index 7.
static const NSInteger kBuiltInRepeatItems = 6;
static const NSInteger kCustomRepeatIndex = 7;

const NSTimeInterval kAlertRegularRelativeOffsets[kAlertRegularNumOffsets] = {
    MAXFLOAT, // None
    0,        // At time of event
    -300,     // 5 minutes before
    -600,     // 10 minutes before
    -900,     // 15 minutes before
    -1800,    // 30 minutes before
    -3600,    // 1 hour before
    -7200,    // 2 hours before
    -86400,   // 1 day before
    -172800   // 2 days before
};

@implementation EventViewController
{
    NSTextField *_quick, *_title, *_location, *_url, *_repEndLabel;
    // Quick-entry bookkeeping: what the quick-entry field last put in the
    // form, so it never overwrites something you typed by hand.
    NSString *_qeTitle, *_qeLocation;
    BOOL _qeSetDates, _qeSetRepeat, _qeSetCalendar;
    NSDate *_defaultStart, *_defaultEnd;
    NSInteger _defaultCalTag;
    EKRecurrenceRule *_qeCustomRule;
    NSButton *_allDayCheckbox, *_saveButton, *_cancelButton;
    NSBox *_quickLine;
    NSLayoutConstraint *_quickCollapsed;
    // Editing: only send what the user actually changed.
    BOOL _repeatTouched, _alertTouched, _saving;
    NSDate *_previousStart;
    NSDatePicker *_startDate, *_endDate, *_repEndDate;
    NSPopUpButton *_repPopup, *_repEndPopup, *_alertPopup, *_calPopup;
    NSArray<NSString *> *_alertAllDayStrings, *_alertRegularStrings;
    HackyTextView *_notes;
    NSScrollView *_notesScrollView;
    NSLayoutConstraint *_notesScrollViewHeightConstraint;
    CGFloat _notesHeightOfOneLine;
}

- (void)loadView
{
    // View controller content view
    NSView *v = [NSView new];
    
    // TextField maker
    NSTextField* (^txt)(NSString*, BOOL) = ^NSTextField* (NSString *stringValue, BOOL isEditable) {
        NSTextField *txt;
        if (isEditable) {
            txt = [NSTextField textFieldWithString:@""];
            txt.placeholderString = stringValue;
            txt.bezeled = NO;
            txt.focusRingType = NSFocusRingTypeNone;
            txt.drawsBackground = NO;
        }
        else {
            txt = [NSTextField labelWithString:stringValue];
            txt.alignment = NSTextAlignmentRight;
        }
        [v addSubview:txt];
        return txt;
    };

    // DatePicker maker
    NSDatePicker* (^picker)(void) = ^NSDatePicker* () {
        NSDatePicker *picker = [NSDatePicker new];
        picker.datePickerStyle = NSDatePickerStyleTextField;
        picker.locale = NSLocale.currentLocale;
        picker.bezeled  = NO;
        picker.bordered = NO;
        picker.drawsBackground = NO;
        picker.datePickerElements = NSDatePickerElementFlagYearMonthDay | NSDatePickerElementFlagHourMinute;
        [v addSubview:picker];
        return picker;
    };

    // PopUpButton maker
    NSPopUpButton* (^popup)(SEL) = ^NSPopUpButton* (SEL action) {
        NSPopUpButton *pop = [NSPopUpButton new];
        pop.target = self;
        pop.action = action;
        pop.menu.autoenablesItems = NO;
        [v addSubview:pop];
        return pop;
    };
    
    // Button maker
    NSButton* (^btn)(NSString*, id, SEL) = ^NSButton* (NSString *title, id target, SEL action) {
        NSButton *btn = [NSButton buttonWithTitle:title target:target action:action];
        [v addSubview:btn];
        return btn;
    };

    // Quick-entry field: type an event in plain English and the form
    // below fills itself in as you type.
    _quick = txt(NSLocalizedString(@"Quick entry: Lunch Fri 1pm at Nopa /work", @""), YES);
    _quick.delegate = self;
    _quick.font = [NSFont systemFontOfSize:14];
    _quick.toolTip = NSLocalizedString(@"Try: \"Dentist Tue 3:30pm for 45 min\", \"Yoga every Tue and Thu 6pm\", \"Trip to Boston Oct 20-23\", \"Standup weekdays 9:15am until Dec 1 /work\"", @"");
    NSBox *quickLine = [NSBox new];
    quickLine.boxType = NSBoxSeparator;
    [v addSubview:quickLine];
    _quickLine = quickLine;

    // Title, location, and URL text fields
    _title = txt(NSLocalizedString(@"New Event", @""), YES);
    _title.delegate = self;
    _title.font = [NSFont systemFontOfSize:16 weight:NSFontWeightMedium];
    _location = txt(NSLocalizedString(@"Add Location or Video Call", @""), YES);
    _url = txt(NSLocalizedString(@"Add URL", @""), YES);
    
    // All-day checkbox
    _allDayCheckbox = [NSButton new];
    _allDayCheckbox.title = @"";
    _allDayCheckbox.target = self;
    _allDayCheckbox.action = @selector(allDayClicked:);
    [_allDayCheckbox setButtonType:NSButtonTypeSwitch];
    [v addSubview:_allDayCheckbox];
    
    // Static labels
    NSTextField *allDayLabel = txt(NSLocalizedString(@"All-day:", @""), NO);
    NSTextField *startsLabel = txt(NSLocalizedString(@"Starts:", @""), NO);
    NSTextField *endsLabel   = txt(NSLocalizedString(@"Ends:", @""), NO);
    NSTextField *repLabel    = txt(NSLocalizedString(@"Repeat:", @""), NO);
                _repEndLabel = txt(NSLocalizedString(@"End Repeat:", @""), NO);
    NSTextField *alertLabel  = txt(NSLocalizedString(@"Alert:", @""), NO);
    
    // Date pickers
    _startDate = picker();
    _startDate.target = self;
    _startDate.action = @selector(startDateChanged:);
    _endDate    = picker();
    _repEndDate = picker();
    _repEndDate.datePickerElements = NSDatePickerElementFlagYearMonthDay;
    _repEndDate.target = self;
    _repEndDate.action = @selector(repEndDateChanged:);
    
    // Popups
    _repPopup = popup(@selector(repPopupChanged:));
    [_repPopup addItemsWithTitles:@[NSLocalizedString(@"None", @"Repeat none"),
                                    NSLocalizedString(@"Every Day", @""),
                                    NSLocalizedString(@"Every Week", @""),
                                    [NSString stringWithFormat:NSLocalizedString(@"Every %zd Weeks", nil), (NSInteger)2],
                                    NSLocalizedString(@"Every Month", @""),
                                    NSLocalizedString(@"Every Year", @"")]];
    
    _repEndPopup = popup(@selector(repEndPopupChanged:));
    [_repEndPopup addItemsWithTitles:@[NSLocalizedString(@"Never", @"Repeat ends never"),
                                       NSLocalizedString(@"On Date", @"")]];
    
    _alertPopup = popup(@selector(alertPopupChanged:));
    _alertAllDayStrings = @[
        NSLocalizedString(@"None", @"Alert none"),
        NSLocalizedString(@"On day of event (9 AM)", @""),
        NSLocalizedString(@"1 day before (9 AM)", @""),
        NSLocalizedString(@"2 days before (9 AM)", @""),
        NSLocalizedString(@"1 week before", @"")];
    _alertRegularStrings = @[
        NSLocalizedString(@"None", @"Alert none"),
        NSLocalizedString(@"At time of event", @""),
        NSLocalizedString(@"5 minutes before", @""),
        NSLocalizedString(@"10 minutes before", @""),
        NSLocalizedString(@"15 minutes before", @""),
        NSLocalizedString(@"30 minutes before", @""),
        NSLocalizedString(@"1 hour before", @""),
        NSLocalizedString(@"2 hours before", @""),
        NSLocalizedString(@"1 day before", @""),
        NSLocalizedString(@"2 days before", @"")];
    // This is a hack.
    // Populate the alert with all possible values (there are
    // different values for regular vs. all-day events) so the
    // Autolayout engine can calculate the correct maximum
    // width of the button. The real values will be repopulated
    // in -viewWillAppear. Without this hack, the view may
    // change width when the user toggles between regular and
    // all-day events as the popup gets wider or narrower.
    [_alertPopup addItemsWithTitles:_alertAllDayStrings];
    [_alertPopup addItemsWithTitles:_alertRegularStrings];

    // Notes (NSTextView embedded in NSScrollView)
    _notesScrollView = [[NSScrollView alloc] initWithFrame:NSMakeRect(0, 0, 100, 44)];
    _notesScrollView.translatesAutoresizingMaskIntoConstraints = NO;
    _notesScrollView.focusRingType = NSFocusRingTypeExterior;
    _notesScrollView.borderType = NSNoBorder;
    _notesScrollView.verticalScrollElasticity = NSScrollElasticityNone;
    _notesScrollView.drawsBackground = NO;
    _notesScrollView.hasVerticalScroller = YES;
    _notesScrollView.verticalScroller = [ThemedScroller new];
    [v addSubview:_notesScrollView];

    NSSize noteContentSize = _notesScrollView.contentSize;
    _notes = [[HackyTextView alloc] initWithFrame:NSMakeRect(0, 0, noteContentSize.width, noteContentSize.height)];
    _notes.delegate = self;
    _notes.font = _location.font; // _title.font is too big
    _notes.placeholderAttributedString = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"Add Notes", @"") attributes:@{NSFontAttributeName: _notes.font, NSForegroundColorAttributeName: NSColor.disabledControlTextColor}];
    _notes.allowsUndo = YES;
    _notes.drawsBackground = NO;
    _notes.richText = NO;
    _notes.focusRingType = NSFocusRingTypeNone;
    _notes.minSize = NSMakeSize(0, noteContentSize.height);
    _notes.maxSize = NSMakeSize(FLT_MAX, FLT_MAX);
    _notes.verticallyResizable = YES;
    _notes.horizontallyResizable = NO;
    _notes.autoresizingMask = NSViewWidthSizable;
    _notes.textContainer.widthTracksTextView = YES;
    [_notes.textContainer setLineFragmentPadding:0];
    [_notes.textContainer setContainerSize:NSMakeSize(noteContentSize.width, FLT_MAX)];

    _notesScrollView.documentView = _notes;

    _calPopup = popup(@selector(calPopupChanged:));
    _calPopup.imagePosition = NSImageOnly;
    
    // This is a hack.
    // Populate _calPopup with a dummy item so the Autolayout
    // engine can calculate its correct width. The real values
    // will be repopulated in -viewWillAppear.
    NSMenuItem *calItem = [NSMenuItem new];
    calItem.image = [NSImage imageWithSize:NSMakeSize(8, 8) flipped:NO drawingHandler:^BOOL(NSRect dstRect) { return YES; }];
    calItem.rs_shouldShowImage = YES;
    [_calPopup.menu addItem:calItem];
    
    // Save and Cancel buttons
    _saveButton = btn(NSLocalizedString(@"Save Event", @""), self, @selector(saveEvent:));
    _saveButton.enabled = NO; // we'll enable when the form is valid.
    NSButton *cancelButton = btn(NSLocalizedString(@"Cancel", @""), self, @selector(cancelOperation:));
    _cancelButton = cancelButton;
    
    MoVFLHelper *vfl = [[MoVFLHelper alloc] initWithSuperview:v metrics:nil views:NSDictionaryOfVariableBindings(_quick, quickLine, _title, _calPopup, _location, _allDayCheckbox, allDayLabel, startsLabel, endsLabel, _startDate, _endDate, repLabel, alertLabel, _repPopup, _repEndLabel, _repEndPopup, _repEndDate, _alertPopup, _notesScrollView, _url, cancelButton, _saveButton)];

    [vfl :@"V:|-[_quick]-8-[quickLine]-8-[_title]-[_location]-15-[_allDayCheckbox]"];
    [vfl :@"H:|-[_quick]-|"];
    [vfl :@"H:|-[quickLine]-|"];
    [vfl :@"V:[_allDayCheckbox]-[_startDate]-[_endDate]-[_repPopup]-[_repEndPopup]-[_alertPopup]" :NSLayoutFormatAlignAllLeading];
    [vfl :@"V:[_alertPopup]-20-[_notesScrollView]-10-[_url]-15-[_saveButton]-|"];
    [vfl :@"H:|-[_title]-[_calPopup]-|" :NSLayoutFormatAlignAllCenterY];
    [vfl :@"H:|-[_location]-|"];
    [vfl :@"H:|-[allDayLabel]-[_allDayCheckbox]-|" :NSLayoutFormatAlignAllBaseline];
    [vfl :@"H:|-[startsLabel]-[_startDate]-|" :NSLayoutFormatAlignAllBaseline];
    [vfl :@"H:|-[endsLabel]-[_endDate]-|" :NSLayoutFormatAlignAllBaseline];
    [vfl :@"H:|-[repLabel]-[_repPopup]-|" :NSLayoutFormatAlignAllBaseline];
    [vfl :@"H:|-[_repEndLabel]-[_repEndPopup]-[_repEndDate]-|" :NSLayoutFormatAlignAllBaseline];
    [vfl :@"H:|-[alertLabel]-[_alertPopup]-|" :NSLayoutFormatAlignAllBaseline];
    [vfl :@"H:|-[_notesScrollView(>=200)]-|"];
    [vfl :@"H:|-[_url]-|"];
    [vfl :@"H:[cancelButton]-[_saveButton]-|" :NSLayoutFormatAlignAllCenterY];
    
    // Get height of one line in _notes
    [_notes.layoutManager ensureLayoutForTextContainer:_notes.textContainer];
    _notesHeightOfOneLine = [_notes.layoutManager usedRectForTextContainer:_notes.textContainer].size.height;

    // When editing an existing event the quick-entry field is folded away.
    _quickCollapsed = [_quick.heightAnchor constraintEqualToConstant:0];

    // Set height of _notesScrollView to height of single line
    _notesScrollViewHeightConstraint = [_notesScrollView.heightAnchor constraintEqualToConstant:_notesHeightOfOneLine];
    _notesScrollViewHeightConstraint.active = YES;

    // Require All-day checkbox height to hug the checkbox. Without this,
    // the layout will look funny when the title is multi-line.
    [_allDayCheckbox setContentHuggingPriority:999 forOrientation:NSLayoutConstraintOrientationVertical];
    
    // Pickers' width will change depending on state of _allDayCheckbox.
    // We don't want the size of the picker control to change (shrink)
    // when this happens so we set a very low hugging priority.
    [_startDate setContentHuggingPriority:1 forOrientation:NSLayoutConstraintOrientationHorizontal];
    [_endDate   setContentHuggingPriority:1 forOrientation:NSLayoutConstraintOrientationHorizontal];
    
    if (@available(macOS 26.0, *)) {
        // On macOS 26 the trick we use in -viewDidAppear to paint
        // the popover's full background no longer works. Now we
        // set the popover's hasFullContentSize=YES and use the
        // safeAreaLayoutGuide of a view that paints its background
        // according to the Theme to inset our content.
        v.translatesAutoresizingMaskIntoConstraints = NO;
        MoThemeView *view = [MoThemeView new];
        [view addSubview:v];
        [NSLayoutConstraint activateConstraints:@[
            [v.topAnchor constraintEqualToAnchor:view.safeAreaLayoutGuide.topAnchor],
            [v.bottomAnchor constraintEqualToAnchor:view.safeAreaLayoutGuide.bottomAnchor],
            [v.leftAnchor constraintEqualToAnchor:view.safeAreaLayoutGuide.leftAnchor],
            [v.rightAnchor constraintEqualToAnchor:view.safeAreaLayoutGuide.rightAnchor],
        ]];
        self.view = view;
        return;
    }
    
    self.view = v;
}

- (void)viewWillAppear
{
    [super viewWillAppear];

    self.view.window.defaultButtonCell = _saveButton.cell;
    
    // If self.calSelectedDate is today, the initialStart is set to
    // the next whole hour. Otherwise, 8am of self.calselectedDate.
    // Default duration is same as setting in Calendar.app.
    NSDate *initialStart, *initialEnd, *today = [NSDate new];
    if ([self.cal isDate:self.calSelectedDate inSameDayAsDate:today]) {
        NSInteger hour;
        [self.cal getHour:&hour minute:NULL second:NULL nanosecond:NULL fromDate:today];
        hour = (hour == 23) ? 0 : hour+1;
        initialStart = [self.cal nextDateAfterDate:today matchingUnit:NSCalendarUnitHour value:hour options:NSCalendarMatchNextTimePreservingSmallerUnits];
    }
    else {
        initialStart = [self.cal dateBySettingHour:8 minute:0 second:0 ofDate:self.calSelectedDate options:0];
    }
    NSInteger newEventDuration = [self defaultDurationInMinutesForNewEvent];
    initialEnd = [self.cal dateByAddingUnit:NSCalendarUnitMinute
                                      value:newEventDuration
                                     toDate:initialStart
                                    options:0];
    
    // Initial values for form fields.
    _defaultStart = initialStart;
    _defaultEnd = initialEnd;
    _previousStart = initialStart;
    _repeatTouched = _alertTouched = _saving = NO;
    BOOL editing = self.editEvent != nil;
    _quick.hidden = editing;
    _quickLine.hidden = editing;
    _quickCollapsed.active = editing;
    _saveButton.title = editing ? NSLocalizedString(@"Save Changes", @"") : NSLocalizedString(@"Save Event", @"");
    _cancelButton.enabled = YES;
    _quick.stringValue = @"";
    _qeTitle = _qeLocation = @"";
    _qeSetDates = _qeSetRepeat = _qeSetCalendar = NO;
    _qeCustomRule = nil;
    [self removeCustomRepeatItem];
    _title.stringValue = @"";
    _location.stringValue = @"";
    _url.stringValue = @"";
    _notes.string = @"";
    _allDayCheckbox.state = NSControlStateValueOff;
    _startDate.datePickerElements = NSDatePickerElementFlagYearMonthDay | NSDatePickerElementFlagHourMinute;
    _endDate.datePickerElements   = NSDatePickerElementFlagYearMonthDay | NSDatePickerElementFlagHourMinute;
    _startDate.dateValue = initialStart;
    _endDate.minDate     = initialStart; // !! Must set minDate before dateValue !!
    _endDate.dateValue   = initialEnd;
    _repEndLabel.hidden  = YES;
    _repEndPopup.hidden  = YES;
    _repEndDate.hidden   = YES;
    _repEndDate.minDate  = initialStart;
    _repEndDate.dateValue = initialEnd;
    [_repPopup selectItemAtIndex:0];     // 'None' selected
    [_repEndPopup selectItemAtIndex:0];  // 'Never' selected
    [_alertPopup selectItemAtIndex:0];   // 'None' selected
    _saveButton.enabled  = NO;
    
    // Function to make colored dots for calendar popup.
    NSImage* (^coloredDot)(NSColor *) = ^NSImage* (NSColor *color) {
        return [NSImage imageWithSize:NSMakeSize(8, 8) flipped:NO drawingHandler:^BOOL(NSRect dstRect) {
            [color set];
            [[NSBezierPath bezierPathWithOvalInRect:NSMakeRect(0, 0, 8, 8)] fill];
            return YES;
        }];
    };
    
    // Populate calendar popup: the Mac's calendars grouped by account, then
    // Itsycal's own accounts (Google, CalDAV).
    // When editing: an Apple-calendar event can move to another of the Mac's
    // calendars; a Google/CalDAV event stays in its calendar.
    BOOL editingRemote = editing && [RemoteCalendarItem isRemote:self.editEvent];
    NSString *selectIdentifier = editing ? self.editEvent.calendar.calendarIdentifier : [self.ec defaultCalendarIdentifier];
    NSArray *sourcesAndCalendars = [self.ec sourcesAndCalendars];
    NSString *currentGroup = nil;
    [_calPopup.menu removeAllItems];
    for (id obj in sourcesAndCalendars) {
        if ([obj isKindOfClass:[NSString class]]) continue; // Skip Sources
        CalendarInfo *calInfo = obj;
        // Only add menu items for calendars that can be modified.
        if (!calInfo.calendar.allowsContentModifications) continue;
        BOOL isRemote = [RemoteCalendarItem isRemote:calInfo.calendar];
        if (editing) {
            if (editingRemote && ![calInfo.calendar.calendarIdentifier isEqualToString:selectIdentifier]) continue;
            if (!editingRemote && isRemote) continue;
        }
        // Add a Source item to the menu if necessary.
        NSString *group = isRemote ? ((RemoteCalendarItem *)calInfo.calendar).sourceTitle
                                   // MacOS 13 sometimes returns nil for non-iCloud source titles.
                                   : (calInfo.calendar.source.title ?: @"???");
        if (![group isEqualToString:currentGroup]) {
            if (_calPopup.menu.itemArray.count != 0) {
                [_calPopup.menu addItem:[NSMenuItem separatorItem]];
            }
            NSMenuItem *sourceItem = [NSMenuItem new];
            sourceItem.title   = group ?: @"???";
            sourceItem.enabled = NO;
            [_calPopup.menu addItem:sourceItem];
            currentGroup = group;
        }
        NSMenuItem *calItem = [NSMenuItem new];
        calItem.title = calInfo.calendar.title;
        calItem.image = coloredDot(calInfo.calendar.color);
        calItem.tag   = [sourcesAndCalendars indexOfObject:obj];
        calItem.rs_shouldShowImage = YES;
        [_calPopup.menu addItem:calItem];
        if ([calInfo.calendar.calendarIdentifier isEqualToString:selectIdentifier]) {
            [_calPopup selectItemWithTag:calItem.tag];
        }
    }
    // Never leave an account heading selected.
    if (!_calPopup.selectedItem.isEnabled) {
        for (NSMenuItem *item in _calPopup.menu.itemArray) {
            if (item.isEnabled && !item.isSeparatorItem) { [_calPopup selectItem:item]; break; }
        }
    }
    _calPopup.enabled = !editingRemote;

    _defaultCalTag = _calPopup.selectedItem.tag;

    // Populate alert popup AFTER calendar popup since its
    // contents depends on which calendar is selected.
    [self populateAlertPopup];

    if (editing) {
        [self fillFormFromEvent:self.editEvent];
        [self updateSaveButton];
        return;
    }

    // Arrived from the main window's quick-entry bar with text already typed.
    if (self.initialQuickText.length) {
        _quick.stringValue = self.initialQuickText;
        [self applyQuickEntry];
        [self updateSaveButton];
    }
}

- (void)viewDidAppear
{
    [super viewDidAppear];

    // Start typing straight into the quick-entry field (or the title, when editing).
    [self.view.window makeFirstResponder:self.editEvent ? _title : _quick];

    // macOS 26 uses MoThemeView and fullSizeContent on the popover
    // to paint the whole background so we can just return early.
    if (@available(macOS 26.0, *)) return;

    // Add a colored subview at the bottom the of popover's
    // window's frameView's view hierarchy. This should color
    // the popover including the arrow.
    NSView *frameView = self.view.window.contentView.superview;
    if (!frameView) return;
    if (frameView.subviews.count > 0
        && [frameView.subviews[0].identifier isEqualToString:@"popoverBackgroundBox"]) return;
    NSBox *backgroundColorView = [[NSBox alloc] initWithFrame:frameView.bounds];
    backgroundColorView.identifier = @"popoverBackgroundBox";
    backgroundColorView.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    backgroundColorView.boxType = NSBoxCustom;
    backgroundColorView.borderWidth = 0;
    backgroundColorView.fillColor = Theme.mainBackgroundColor;
    [frameView addSubview:backgroundColorView positioned:NSWindowBelow relativeTo:nil];
}

- (NSInteger)defaultDurationInMinutesForNewEvent {
    NSUserDefaults *calendarDefaults = [[NSUserDefaults alloc] initWithSuiteName:@"com.apple.iCal"];
    NSNumber *durationMinutes = [calendarDefaults objectForKey:@"Default duration in minutes for new event"];

    // Check if the value was found.
    if (durationMinutes != nil) {
        return [durationMinutes longValue];
    }
    // Return the system default (60 minutes) if the
    // setting isn't explicitly defined.
    return 60;
}

- (void)cancelOperation:(id)sender
{
    // User hit 'esc' or pressed Cancel button.
    [self.enclosingPopover close];
}

- (void)controlTextDidChange:(NSNotification *)obj
{
    if (obj.object == _quick) {
        [self applyQuickEntry];
    }
    [self updateSaveButton];
}

- (void)updateSaveButton
{
    // Enable the Save button if the title is non-whitespace.
    NSString *trimmedTitle = [_title.stringValue stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    _saveButton.enabled = ![trimmedTitle isEqualToString:@""];
}

- (void)allDayClicked:(NSButton *)allDayCheckbox
{
    // The All-day checkbox toggles the hour/minute controls of the date pickers.
    if (allDayCheckbox.state == NSControlStateValueOn) {
        _startDate.datePickerElements = NSDatePickerElementFlagYearMonthDay;
        _endDate.datePickerElements = NSDatePickerElementFlagYearMonthDay;
    }
    else {
        _startDate.datePickerElements = NSDatePickerElementFlagYearMonthDay | NSDatePickerElementFlagHourMinute;
        _endDate.datePickerElements = NSDatePickerElementFlagYearMonthDay | NSDatePickerElementFlagHourMinute;
    }
    
    // All-day events have different alert options from regular events.
    [self populateAlertPopup];
}

- (void)startDateChanged:(NSDatePicker *)startPicker
{
    // Moving the start keeps the event's length (as Calendar.app does).
    // Make sure endDate is never before startDate, and repeatEndDate never
    // before the start.
    NSTimeInterval length = _previousStart ? [_endDate.dateValue timeIntervalSinceDate:_previousStart]
                                           : [self defaultDurationInMinutesForNewEvent] * 60.0;
    if (length < 0) length = 0;
    _endDate.minDate    = _startDate.dateValue;
    _repEndDate.minDate = _startDate.dateValue;
    _endDate.dateValue  = [_startDate.dateValue dateByAddingTimeInterval:length];
    _previousStart = _startDate.dateValue;
}

- (void)repPopupChanged:(id)sender
{
    if (sender) _repeatTouched = YES;
    NSInteger repIndex = [_repPopup indexOfItem:_repPopup.selectedItem];
    NSInteger repEndIndex = [_repEndPopup indexOfItem:_repEndPopup.selectedItem];
    if (repIndex == 0) {
        [_repEndPopup selectItemAtIndex:0];
    }
    // A quick-entry custom repeat carries its own end, so hide End Repeat.
    BOOL noEndControls = repIndex == 0 || repIndex == kCustomRepeatIndex;
    if (noEndControls) {
        [_repEndPopup selectItemAtIndex:0];
        repEndIndex = 0;
    }
    _repEndLabel.hidden = noEndControls;
    _repEndPopup.hidden = noEndControls;
    _repEndDate.hidden  = noEndControls || repEndIndex == 0;
}

- (void)repEndDateChanged:(id)sender
{
    _repeatTouched = YES;
}

- (void)alertPopupChanged:(id)sender
{
    _alertTouched = _alertPopup.selectedItem.tag != kKeepAlertTag;
}

- (void)repEndPopupChanged:(id)sender
{
    if (sender) _repeatTouched = YES;
    NSInteger repEndIndex = [_repEndPopup indexOfItem:_repEndPopup.selectedItem];
    _repEndDate.hidden = repEndIndex == 0;
}

- (void)calPopupChanged:(id)sender
{
    // Different calendars have different alert options.
    [self populateAlertPopup];
}

- (void)populateAlertPopup
{
    [_alertPopup removeAllItems];
    
    NSInteger numOffsets = 0;
    const NSTimeInterval *offsets = nil;

    if (_allDayCheckbox.state == NSControlStateValueOn) {
        [_alertPopup addItemsWithTitles:_alertAllDayStrings];
        numOffsets = kAlertAllDayNumOffsets;
        offsets = kAlertAllDayRelativeOffsets;
    } else {
        [_alertPopup addItemsWithTitles:_alertRegularStrings];
        numOffsets = kAlertRegularNumOffsets;
        offsets = kAlertRegularRelativeOffsets;
    }

    [_alertPopup selectItemAtIndex:0];

    // Editing: show the event's own alert (unless the user already picked one).
    if (self.editEvent && !_alertTouched) {
        NSNumber *current = [self currentAlertOffsetOfEvent:self.editEvent];
        BOOL hasAlert = current != nil || (![RemoteCalendarItem isRemote:self.editEvent] && self.editEvent.alarms.count > 0);
        if (!hasAlert) return;
        for (NSInteger i = 1; current && i < numOffsets; i++) {
            if (offsets[i] == current.doubleValue) {
                [_alertPopup selectItemAtIndex:i];
                [_alertPopup selectedItem].tag = kKeepAlertTag;  // unchanged unless picked again
                return;
            }
        }
        // An alert the menu can't show: offer to keep it as it is.
        [_alertPopup.menu addItem:[NSMenuItem separatorItem]];
        NSMenuItem *keep = [_alertPopup.menu addItemWithTitle:NSLocalizedString(@"Keep current alert", @"") action:NULL keyEquivalent:@""];
        keep.tag = kKeepAlertTag;
        [_alertPopup selectItem:keep];
        return;
    }

    // Get the selected calendar.
    NSInteger index = _calPopup.selectedItem.tag;
    NSArray *sourcesAndCalendars = [self.ec sourcesAndCalendars];
    if (index < 0 || index >= (NSInteger)sourcesAndCalendars.count) return;
    CalendarInfo *calInfo = sourcesAndCalendars[index];
    if (![calInfo isKindOfClass:[CalendarInfo class]]) return;
    // Google/CalDAV calendars don't have default alerts in Itsycal.
    if ([RemoteCalendarItem isRemote:calInfo.calendar]) return;

    // Make a dummy event for the selected calendar in order to get
    // the default alert time offset.
    EKEvent *dummyEvent  = [self.ec newEvent];
    dummyEvent.calendar  = calInfo.calendar;
    dummyEvent.allDay    = _allDayCheckbox.state == NSControlStateValueOn;

    // If the dummy event has an alert, try to set it as the default.
    if (dummyEvent.alarms.count > 0) {
        for (NSInteger i = 0; i < numOffsets; i++) {
            if (dummyEvent.alarms.firstObject.relativeOffset == offsets[i]) {
                [_alertPopup selectItemAtIndex:i];
                break;
            }
        }
    }
}

// The event's first alert, in seconds from its start (nil if none or not relative).
- (NSNumber *)currentAlertOffsetOfEvent:(EKEvent *)event
{
    if ([RemoteCalendarItem isRemote:event]) return ((RemoteEventItem *)event).alarmOffset;
    EKAlarm *alarm = event.alarms.firstObject;
    return (alarm && !alarm.absoluteDate) ? @(alarm.relativeOffset) : nil;
}

// 1 Every Day, 2 Every Week, 3 Every 2 Weeks, 4 Every Month, 5 Every Year, 0 = none of these.
- (NSInteger)simpleRepeatIndexForRule:(EKRecurrenceRule *)rule start:(NSDate *)start
{
    if (rule.daysOfTheMonth.count || rule.monthsOfTheYear.count || rule.setPositions.count ||
        rule.daysOfTheYear.count || rule.weeksOfTheYear.count || rule.recurrenceEnd.occurrenceCount) return 0;
    NSInteger weekday = [self.cal component:NSCalendarUnitWeekday fromDate:start];
    BOOL daysMatchStart = rule.daysOfTheWeek.count == 0 ||
        (rule.daysOfTheWeek.count == 1 && rule.daysOfTheWeek.firstObject.dayOfTheWeek == weekday &&
         rule.daysOfTheWeek.firstObject.weekNumber == 0);
    if (!daysMatchStart) return 0;
    switch (rule.frequency) {
        case EKRecurrenceFrequencyDaily:   return (rule.interval == 1 && rule.daysOfTheWeek.count == 0) ? 1 : 0;
        case EKRecurrenceFrequencyWeekly:  return rule.interval == 1 ? 2 : (rule.interval == 2 ? 3 : 0);
        case EKRecurrenceFrequencyMonthly: return (rule.interval == 1 && rule.daysOfTheWeek.count == 0) ? 4 : 0;
        case EKRecurrenceFrequencyYearly:  return (rule.interval == 1 && rule.daysOfTheWeek.count == 0) ? 5 : 0;
    }
    return 0;
}

// Fills the form with an existing event (Edit).
- (void)fillFormFromEvent:(EKEvent *)event
{
    _title.stringValue    = event.title ?: @"";
    _location.stringValue = event.location ?: @"";
    _url.stringValue      = event.URL.absoluteString ?: @"";
    _notes.string         = event.notes ?: @"";
    [self textDidChange:[NSNotification notificationWithName:NSTextDidChangeNotification object:_notes]];

    BOOL allDay = event.isAllDay;
    _allDayCheckbox.state = allDay ? NSControlStateValueOn : NSControlStateValueOff;
    _startDate.datePickerElements = allDay ? NSDatePickerElementFlagYearMonthDay
                                           : NSDatePickerElementFlagYearMonthDay | NSDatePickerElementFlagHourMinute;
    _endDate.datePickerElements = _startDate.datePickerElements;
    NSDate *start = event.startDate;
    NSDate *end = allDay ? AdjustedEventEndDate(event, self.cal) : event.endDate;
    if ([end compare:start] == NSOrderedAscending) end = start;
    _startDate.dateValue = start;
    _endDate.minDate     = start; // !! Must set minDate before dateValue !!
    _endDate.dateValue   = end;
    _repEndDate.minDate  = start;
    _previousStart = start;

    // Repeat.
    [self removeCustomRepeatItem];
    _qeCustomRule = nil;
    [_repPopup selectItemAtIndex:0];
    [_repEndPopup selectItemAtIndex:0];
    EKRecurrenceRule *rule = event.hasRecurrenceRules ? event.recurrenceRules.firstObject : nil;
    if (rule) {
        NSInteger simple = [self simpleRepeatIndexForRule:rule start:start];
        if (simple > 0) {
            [_repPopup selectItemAtIndex:simple];
            if (rule.recurrenceEnd.endDate) {
                [_repEndPopup selectItemAtIndex:1]; // 'On Date'
                _repEndDate.dateValue = rule.recurrenceEnd.endDate;
            }
        } else {
            _qeCustomRule = rule;
            [_repPopup.menu addItem:[NSMenuItem separatorItem]];
            NSMenuItem *custom = [_repPopup.menu addItemWithTitle:NSLocalizedString(@"Custom (unchanged)", @"") action:NULL keyEquivalent:@""];
            [_repPopup selectItem:custom];
        }
    }
    [self repPopupChanged:nil];
    _repEndDate.hidden = _repEndPopup.hidden || [_repEndPopup indexOfSelectedItem] == 0;

    // Alerts for the all-day/timed state, showing the event's own alert.
    [self populateAlertPopup];
}

// Everything in the form, as a draft.
- (EventDraft *)draftFromForm
{
    NSCharacterSet *whitespaceSet = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    BOOL editing = self.editEvent != nil;
    EventDraft *d = [EventDraft new];
    d.title    = [_title.stringValue stringByTrimmingCharactersInSet:whitespaceSet];
    d.location = [_location.stringValue stringByTrimmingCharactersInSet:whitespaceSet];
    NSString *url = [_url.stringValue stringByTrimmingCharactersInSet:whitespaceSet];
    d.URL      = url.length ? [NSURL URLWithString:url] : nil;
    d.notes    = [_notes.string stringByTrimmingCharactersInSet:whitespaceSet];
    d.allDay   = _allDayCheckbox.state == NSControlStateValueOn;
    d.startDate = _startDate.dateValue;
    d.endDate   = _endDate.dateValue;

    NSInteger index = _calPopup.selectedItem.tag;
    NSArray *sourcesAndCalendars = [self.ec sourcesAndCalendars];
    if (index >= 0 && index < (NSInteger)sourcesAndCalendars.count &&
        [sourcesAndCalendars[index] isKindOfClass:[CalendarInfo class]]) {
        d.calendar = ((CalendarInfo *)sourcesAndCalendars[index]).calendar;
    } else if (editing) {
        d.calendar = self.editEvent.calendar;
    }

    // Repeat (for edits only if it was changed).
    d.repeatSet = !editing || _repeatTouched;
    if (d.repeatSet) {
        EKRecurrenceFrequency frequency = EKRecurrenceFrequencyDaily;
        NSInteger interval = 1;
        NSInteger repIndex = [_repPopup indexOfItem:_repPopup.selectedItem];
        switch (repIndex) {
            case 1: frequency = EKRecurrenceFrequencyDaily; break;          // Every Day
            case 2: frequency = EKRecurrenceFrequencyWeekly; break;         // Every Week
            case 3: frequency = EKRecurrenceFrequencyWeekly; interval = 2; break; // Every 2 Weeks
            case 4: frequency = EKRecurrenceFrequencyMonthly; break;        // Every Month
            case 5: frequency = EKRecurrenceFrequencyYearly; break;         // Every Year
            default: break;
        }
        EKRecurrenceEnd *recurrenceEnd = nil;
        NSInteger repEndIndex = [_repEndPopup indexOfItem:_repEndPopup.selectedItem];
        if (repEndIndex != 0) {
            recurrenceEnd = [EKRecurrenceEnd recurrenceEndWithEndDate:_repEndDate.dateValue];
        }
        if (repIndex == kCustomRepeatIndex && _qeCustomRule != nil) {
            d.recurrenceRule = _qeCustomRule;
        } else if (repIndex > 0 && repIndex < kBuiltInRepeatItems) {
            d.recurrenceRule = [[EKRecurrenceRule alloc] initRecurrenceWithFrequency:frequency interval:interval end:recurrenceEnd];
        }
    }

    // Alert (for edits only if it was changed).
    d.alertSet = (!editing || _alertTouched) && _alertPopup.selectedItem.tag != kKeepAlertTag;
    if (d.alertSet) {
        NSInteger alertIndex = [_alertPopup indexOfItem:_alertPopup.selectedItem];
        NSTimeInterval offset = MAXFLOAT;
        if (alertIndex > 0) { // 0 == no alert
            if (d.allDay && alertIndex < kAlertAllDayNumOffsets) offset = kAlertAllDayRelativeOffsets[alertIndex];
            else if (!d.allDay && alertIndex < kAlertRegularNumOffsets) offset = kAlertRegularRelativeOffsets[alertIndex];
        }
        d.alertOffset = offset != MAXFLOAT ? @(offset) : nil;
    }
    return d;
}

- (void)setSaving:(BOOL)saving
{
    _saving = saving;
    _saveButton.enabled = !saving;
    _cancelButton.enabled = !saving;
    _saveButton.title = saving ? NSLocalizedString(@"Saving…", @"")
                      : (self.editEvent ? NSLocalizedString(@"Save Changes", @"") : NSLocalizedString(@"Save Event", @""));
    if (!saving) [self updateSaveButton];
}

- (void)finishWithError:(NSError *)error
{
    [self setSaving:NO];
    if (error) {
        NSAlert *alert = [NSAlert new];
        alert.messageText = self.editEvent ? NSLocalizedString(@"The changes couldn't be saved.", @"")
                                           : NSLocalizedString(@"The event couldn't be saved.", @"");
        alert.informativeText = error.localizedDescription ?: @"";
        [alert runModal];
        return;
    }
    [self.enclosingPopover close];
}

- (void)saveEvent:(id)sender
{
    if (_saving) return;
    EventDraft *draft = [self draftFromForm];
    if (!draft.calendar) {
        NSBeep();
        return;
    }
    __weak typeof(self) weakSelf = self;

    if (!self.editEvent) {
        [self setSaving:YES];
        [self.ec createEventFromDraft:draft completion:^(NSError *error) {
            [weakSelf finishWithError:error];
        }];
        return;
    }

    // Editing. For a repeating event, ask which occurrences to change.
    EKEvent *event = self.editEvent;
    BOOL remote = [RemoteCalendarItem isRemote:event];
    BOOL series = remote ? ((RemoteEventItem *)event).isSeriesOccurrence : event.hasRecurrenceRules;
    ItsySpan span = ItsySpanAllEvents;
    if (series) {
        if (_repeatTouched) {
            // A new repeat applies to the series.
            span = remote ? ItsySpanAllEvents : ItsySpanFutureEvents;
        } else {
            NSAlert *alert = [NSAlert new];
            alert.messageText = NSLocalizedString(@"This is a repeating event.", @"");
            alert.informativeText = remote
                ? NSLocalizedString(@"Do you want to change only this occurrence, or every occurrence of the event?", @"")
                : NSLocalizedString(@"Do you want to change only this occurrence, or this and all future occurrences?", @"");
            [alert addButtonWithTitle:NSLocalizedString(@"Only This Event", @"")];
            [alert addButtonWithTitle:remote ? NSLocalizedString(@"All Events", @"") : NSLocalizedString(@"All Future Events", @"")];
            [alert addButtonWithTitle:NSLocalizedString(@"Cancel", @"")];
            NSModalResponse response = [alert runModal];
            if (response == NSAlertThirdButtonReturn) return;
            span = response == NSAlertFirstButtonReturn ? ItsySpanThisEvent
                 : (remote ? ItsySpanAllEvents : ItsySpanFutureEvents);
        }
    }
    [self setSaving:YES];
    [self.ec updateEvent:event withDraft:draft span:span completion:^(NSError *error) {
        [weakSelf finishWithError:error];
    }];
}

#pragma mark -
#pragma mark Quick entry

- (void)applyQuickEntry
{
    QuickEntryResult *r = [[QuickEntryParser sharedParser] parse:_quick.stringValue];
    if (r == nil) return;

    // Title and location. Only replace text quick entry put there itself;
    // if you've edited a field by hand, it's left alone.
    if ([_title.stringValue isEqualToString:_qeTitle]) {
        _title.stringValue = r.title;
        _qeTitle = r.title;
    }
    NSString *location = r.location ?: @"";
    if ([_location.stringValue isEqualToString:_qeLocation]) {
        _location.stringValue = location;
        _qeLocation = location;
    }

    // Calendar ("/work").
    NSMenuItem *calItem = r.calendarTag ? [self calendarItemMatchingTag:r.calendarTag] : nil;
    if (calItem) {
        if (calItem != _calPopup.selectedItem) {
            [_calPopup selectItem:calItem];
            [self populateAlertPopup];
        }
        _qeSetCalendar = YES;
    }
    else if (_qeSetCalendar) {
        [_calPopup selectItemWithTag:_defaultCalTag];
        [self populateAlertPopup];
        _qeSetCalendar = NO;
    }

    // Dates and times.
    NSInteger defaultDuration = [self defaultDurationInMinutesForNewEvent];
    NSDate *start = nil, *end = nil;
    BOOL allDay = NO;
    if (r.hasDate && r.start) {
        start  = r.start;
        allDay = r.allDay;
        if (r.end) {
            end = r.end;
        }
        else if (allDay) {
            end = start;
        }
        else {
            NSInteger minutes = r.durationMinutes > 0 ? r.durationMinutes : defaultDuration;
            end = [self.cal dateByAddingUnit:NSCalendarUnitMinute value:minutes toDate:start options:0];
        }
        _qeSetDates = YES;
    }
    else if (r.durationMinutes > 0) {
        // "for 45 min" with no date: keep the start, change the length.
        start = _qeSetDates ? _defaultStart : _startDate.dateValue;
        end   = [self.cal dateByAddingUnit:NSCalendarUnitMinute value:r.durationMinutes toDate:start options:0];
        _qeSetDates = YES;
    }
    else if (_qeSetDates) {
        // The date was deleted from the quick-entry text: back to the defaults.
        start = _defaultStart;
        end   = _defaultEnd;
        _qeSetDates = NO;
    }
    if (start) {
        if ((_allDayCheckbox.state == NSControlStateValueOn) != allDay) {
            _allDayCheckbox.state = allDay ? NSControlStateValueOn : NSControlStateValueOff;
            [self allDayClicked:_allDayCheckbox];
        }
        if ([end compare:start] == NSOrderedAscending) end = start;
        _startDate.dateValue = start;
        _endDate.minDate     = start; // !! Must set minDate before dateValue !!
        _endDate.dateValue   = end;
        _repEndDate.minDate  = start;
        _previousStart       = start;
    }

    // Repeat.
    [self removeCustomRepeatItem];
    _qeCustomRule = nil;
    if (r.repeats) {
        NSInteger simpleIndex = [self simpleRepeatIndexForResult:r start:_startDate.dateValue];
        if (simpleIndex > 0 && r.count == 0) {
            // Fits the existing Repeat menu.
            [_repPopup selectItemAtIndex:simpleIndex];
            if (r.until) {
                [_repEndPopup selectItemAtIndex:1]; // 'On Date'
                // End of that day, so the last day is included.
                _repEndDate.dateValue = [self.cal dateBySettingHour:23 minute:59 second:0 ofDate:r.until options:0] ?: r.until;
            }
            else {
                [_repEndPopup selectItemAtIndex:0]; // 'Never'
            }
        }
        else {
            // Something the menu can't show: add it as an extra item.
            _qeCustomRule = r.rule;
            [_repPopup.menu addItem:[NSMenuItem separatorItem]];
            NSMenuItem *custom = [_repPopup.menu addItemWithTitle:r.repeatSummary ?: @"Custom" action:NULL keyEquivalent:@""];
            [_repPopup selectItem:custom];
        }
        _qeSetRepeat = YES;
    }
    else if (_qeSetRepeat) {
        [_repPopup selectItemAtIndex:0];    // 'None'
        [_repEndPopup selectItemAtIndex:0]; // 'Never'
        _qeSetRepeat = NO;
    }
    [self repPopupChanged:nil];
}

// The separator and custom item sit at the end of the Repeat menu.
- (void)removeCustomRepeatItem
{
    while (_repPopup.numberOfItems > kBuiltInRepeatItems) {
        [_repPopup removeItemAtIndex:_repPopup.numberOfItems - 1];
    }
}

// Maps a parsed repeat onto the existing menu items, or returns 0.
// 1 Every Day, 2 Every Week, 3 Every 2 Weeks, 4 Every Month, 5 Every Year
- (NSInteger)simpleRepeatIndexForResult:(QuickEntryResult *)r start:(NSDate *)start
{
    NSInteger weekday = [self.cal component:NSCalendarUnitWeekday fromDate:start];
    BOOL daysMatchStart = r.daysOfWeek.count == 0
        || (r.daysOfWeek.count == 1 && r.daysOfWeek.firstObject.integerValue == weekday);
    switch (r.frequency) {
        case EKRecurrenceFrequencyDaily:
            return (r.interval == 1 && r.daysOfWeek.count == 0) ? 1 : 0;
        case EKRecurrenceFrequencyWeekly:
            if (!daysMatchStart) return 0;
            if (r.interval == 1) return 2;
            if (r.interval == 2) return 3;
            return 0;
        case EKRecurrenceFrequencyMonthly:
            return r.interval == 1 ? 4 : 0;
        case EKRecurrenceFrequencyYearly:
            return r.interval == 1 ? 5 : 0;
    }
    return 0;
}

// "/work" matches a writable calendar named "Work", "Work Events", "work-stuff"...
- (NSMenuItem *)calendarItemMatchingTag:(NSString *)tag
{
    NSString* (^squash)(NSString *) = ^NSString* (NSString *s) {
        NSCharacterSet *drop = [[NSCharacterSet alphanumericCharacterSet] invertedSet];
        return [[[s lowercaseString] componentsSeparatedByCharactersInSet:drop] componentsJoinedByString:@""];
    };
    NSString *want = squash(tag);
    if (want.length == 0) return nil;
    NSMenuItem *prefixMatch = nil;
    for (NSMenuItem *item in _calPopup.menu.itemArray) {
        if (item.isSeparatorItem || !item.isEnabled) continue; // skip account headers
        NSString *have = squash(item.title);
        if ([have isEqualToString:want]) return item;
        if (!prefixMatch && [have hasPrefix:want]) prefixMatch = item;
    }
    return prefixMatch;
}

#pragma mark -
#pragma mark NSTextViewDelegate

- (BOOL)textView:(NSTextView *)aTextView doCommandBySelector:(SEL)aSelector
{
    // _notes textview handles Tab/Backtab like other controls
    // by navigating to next/previous control.
    // https://stackoverflow.com/a/2485987/111418
    if (aTextView != _notes) return NO;
    if (aSelector == @selector(insertTab:)) {
        [_notes.window makeFirstResponder:_url];
        return YES;
    }
    else if (aSelector == @selector(insertBacktab:)) {
        [_notes.window makeFirstResponder:_alertPopup];
        return YES;
    }
    return NO;
}

- (void)textDidChange:(NSNotification *)notification
{
    if (notification.object != _notes) return;

    // _notesScrollView will grow to at most this many lines
    // after which it will scroll.
    NSInteger maxVisibleLines = 16;

    // Get height of text in _notes
    [_notes.layoutManager ensureLayoutForTextContainer:_notes.textContainer];
    CGFloat height = [_notes.layoutManager usedRectForTextContainer:_notes.textContainer].size.height;
    
    // Grow _notesScrollView to at most maxVisibleLines * _notesHeightOfOneLine
    height = MIN(height, maxVisibleLines * _notesHeightOfOneLine);
    _notesScrollViewHeightConstraint.constant = height;
    
    // Get number of lines in _notes
    // https://macosx-dev.omnigroup.narkive.com/RH9lsO7P/number-of-lines-in-nstextview#post2
    NSInteger numberOfLines, idx, numberOfGlyphs = [_notes.layoutManager numberOfGlyphs];
    NSRange lineRange;
    for (numberOfLines = 0, idx = 0; idx < numberOfGlyphs; numberOfLines++) {
        (void)[_notes.layoutManager lineFragmentRectForGlyphAtIndex:idx effectiveRange:&lineRange];
        idx = NSMaxRange(lineRange);
    }
    
    // Disable elasticity if all lines are visible
    if (numberOfLines <= maxVisibleLines) {
        _notesScrollView.verticalScrollElasticity = NSScrollElasticityNone;
    }
    else {
        _notesScrollView.verticalScrollElasticity = NSScrollElasticityAutomatic;
    }
}

@end
