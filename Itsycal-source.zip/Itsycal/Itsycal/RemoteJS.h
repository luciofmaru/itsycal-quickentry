//
//  RemoteJS.h
//  Itsycal
//
//  Runs remote.bundle.js (CalDAV XML and iCalendar handling, see
//  QuickEntry/remote.js) in JavaScriptCore. Thread-safe: every call runs on
//  one private serial queue.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface RemoteJS : NSObject

+ (instancetype)shared;

// Calls ItsyRemote.<name>(...args). Arguments and result are JSON values
// (NSString, NSNumber, NSArray, NSDictionary, NSNull). Returns nil and sets
// *error if the function threw.
- (nullable id)call:(NSString *)name args:(NSArray *)args error:(NSError * _Nullable * _Nullable)error;

@end

NS_ASSUME_NONNULL_END
