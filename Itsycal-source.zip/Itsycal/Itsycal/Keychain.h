//
//  Keychain.h
//  Itsycal
//
//  Small wrapper around the login keychain for Itsycal's own secrets
//  (Google sign-in app ID and secret, account sign-in tokens, passwords).
//  Items are generic passwords under the service "Itsycal QuickEntry".
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Keychain : NSObject

+ (nullable NSString *)stringForKey:(NSString *)key;
+ (BOOL)setString:(NSString *)value forKey:(NSString *)key;
+ (void)removeKey:(NSString *)key;

@end

NS_ASSUME_NONNULL_END
