//
//  QuickEntryEvent.m
//  Itsycal
//

#import "QuickEntryEvent.h"
#import "EventCenter.h"

@implementation QuickEntryEvent

+ (NSInteger)defaultDurationMinutes
{
    NSUserDefaults *calendarDefaults = [[NSUserDefaults alloc] initWithSuiteName:@"com.apple.iCal"];
    NSNumber *minutes = [calendarDefaults objectForKey:@"Default duration in minutes for new event"];
    return (minutes != nil && minutes.integerValue > 0) ? minutes.integerValue : 60;
}

+ (NSDate *)defaultStartForDay:(NSDate *)day calendar:(NSCalendar *)cal
{
    NSDate *now = [NSDate new];
    if ([cal isDate:day inSameDayAsDate:now]) {
        NSInteger hour;
        [cal getHour:&hour minute:NULL second:NULL nanosecond:NULL fromDate:now];
        hour = (hour == 23) ? 0 : hour + 1;
        return [cal nextDateAfterDate:now matchingUnit:NSCalendarUnitHour value:hour
                              options:NSCalendarMatchNextTimePreservingSmallerUnits];
    }
    return [cal dateBySettingHour:8 minute:0 second:0 ofDate:day options:0];
}

+ (NSArray<EKCalendar *> *)writableCalendarsInEventCenter:(EventCenter *)ec
{
    NSMutableArray *calendars = [NSMutableArray new];
    for (id obj in [ec sourcesAndCalendars]) {
        if (![obj isKindOfClass:[CalendarInfo class]]) continue;
        EKCalendar *calendar = ((CalendarInfo *)obj).calendar;
        if (calendar.allowsContentModifications) [calendars addObject:calendar];
    }
    return calendars;
}

static NSString *Squash(NSString *s)
{
    NSCharacterSet *drop = [[NSCharacterSet alphanumericCharacterSet] invertedSet];
    return [[[s lowercaseString] componentsSeparatedByCharactersInSet:drop] componentsJoinedByString:@""];
}

+ (nullable EKCalendar *)calendarForTag:(NSString *)tag inCalendars:(NSArray<EKCalendar *> *)calendars
{
    NSString *want = Squash(tag);
    if (want.length == 0) return nil;
    EKCalendar *prefixMatch = nil;
    for (EKCalendar *calendar in calendars) {
        NSString *have = Squash(calendar.title ?: @"");
        if ([have isEqualToString:want]) return calendar;
        if (!prefixMatch && [have hasPrefix:want]) prefixMatch = calendar;
    }
    return prefixMatch;
}

+ (nullable EKCalendar *)calendarForResult:(QuickEntryResult *)r eventCenter:(EventCenter *)ec
{
    NSArray<EKCalendar *> *calendars = [self writableCalendarsInEventCenter:ec];
    if (r.calendarTag) {
        EKCalendar *tagged = [self calendarForTag:r.calendarTag inCalendars:calendars];
        if (tagged) return tagged;
    }
    NSString *defaultID = ec.defaultCalendarIdentifier;
    for (EKCalendar *calendar in calendars) {
        if ([calendar.calendarIdentifier isEqualToString:defaultID]) return calendar;
    }
    return calendars.firstObject;
}

+ (nullable EKEvent *)eventForResult:(QuickEntryResult *)r
                         eventCenter:(EventCenter *)ec
                            calendar:(NSCalendar *)cal
                         selectedDay:(NSDate *)selectedDay
{
    EKCalendar *calendar = [self calendarForResult:r eventCenter:ec];
    if (!calendar) return nil;

    NSDate *start, *end;
    BOOL allDay = NO;
    if (r.hasDate && r.start) {
        start  = r.start;
        allDay = r.allDay;
        if (r.end) {
            end = r.end;
        }
        else if (allDay) {
            end = start;
        }
        else {
            NSInteger minutes = r.durationMinutes > 0 ? r.durationMinutes : [self defaultDurationMinutes];
            end = [cal dateByAddingUnit:NSCalendarUnitMinute value:minutes toDate:start options:0];
        }
    }
    else {
        start = [self defaultStartForDay:selectedDay calendar:cal];
        NSInteger minutes = r.durationMinutes > 0 ? r.durationMinutes : [self defaultDurationMinutes];
        end = [cal dateByAddingUnit:NSCalendarUnitMinute value:minutes toDate:start options:0];
    }
    if ([end compare:start] == NSOrderedAscending) end = start;

    EKEvent *event = [ec newEvent];
    event.calendar  = calendar;          // brings the calendar's default alerts
    event.title     = r.title;
    event.location  = r.location;
    event.allDay    = allDay;
    event.startDate = start;
    event.endDate   = end;
    // timeZone MUST be nil for all-day events (see EventViewController -saveEvent:).
    event.timeZone  = allDay ? nil : [NSTimeZone localTimeZone];
    EKRecurrenceRule *rule = r.rule;
    if (rule) event.recurrenceRules = @[rule];
    return event;
}

+ (NSString *)whenStringForEvent:(EKEvent *)event
{
    NSDateFormatter *day = [NSDateFormatter new];
    day.locale = [NSLocale currentLocale];
    day.dateFormat = [NSDateFormatter dateFormatFromTemplate:@"EEEMMMd" options:0 locale:day.locale];
    NSDateFormatter *time = [NSDateFormatter new];
    time.dateStyle = NSDateFormatterNoStyle;
    time.timeStyle = NSDateFormatterShortStyle;

    NSCalendar *cal = [NSCalendar currentCalendar];
    BOOL sameDay = [cal isDate:event.startDate inSameDayAsDate:event.endDate];
    if (event.isAllDay) {
        if (sameDay) {
            return [NSString stringWithFormat:NSLocalizedString(@"%@ (all day)", @""), [day stringFromDate:event.startDate]];
        }
        return [NSString stringWithFormat:NSLocalizedString(@"%@ – %@ (all day)", @""),
                [day stringFromDate:event.startDate], [day stringFromDate:event.endDate]];
    }
    if (sameDay) {
        return [NSString stringWithFormat:@"%@, %@ – %@", [day stringFromDate:event.startDate],
                [time stringFromDate:event.startDate], [time stringFromDate:event.endDate]];
    }
    return [NSString stringWithFormat:@"%@, %@ – %@, %@",
            [day stringFromDate:event.startDate], [time stringFromDate:event.startDate],
            [day stringFromDate:event.endDate], [time stringFromDate:event.endDate]];
}

@end
