//
//  QuickEntryParser.m
//  Itsycal
//

#import "QuickEntryParser.h"
#import <JavaScriptCore/JavaScriptCore.h>

@implementation QuickEntryResult

- (instancetype)init
{
    self = [super init];
    if (self) {
        _title = @"";
        _interval = 1;
        _daysOfWeek = @[];
    }
    return self;
}

- (nullable EKRecurrenceRule *)rule
{
    if (!self.repeats) return nil;

    EKRecurrenceEnd *recurrenceEnd = nil;
    if (self.count > 0) {
        recurrenceEnd = [EKRecurrenceEnd recurrenceEndWithOccurrenceCount:self.count];
    }
    else if (self.until) {
        // Include the whole of the last day.
        NSCalendar *cal = [NSCalendar currentCalendar];
        NSDate *endOfDay = [cal dateBySettingHour:23 minute:59 second:59 ofDate:self.until options:0];
        recurrenceEnd = [EKRecurrenceEnd recurrenceEndWithEndDate:endOfDay ?: self.until];
    }

    NSMutableArray<EKRecurrenceDayOfWeek *> *days = nil;
    if (self.daysOfWeek.count > 0) {
        days = [NSMutableArray new];
        for (NSNumber *d in self.daysOfWeek) {
            [days addObject:[EKRecurrenceDayOfWeek dayOfWeek:(EKWeekday)d.integerValue]];
        }
    }

    return [[EKRecurrenceRule alloc] initRecurrenceWithFrequency:self.frequency
                                                        interval:MAX(1, self.interval)
                                                   daysOfTheWeek:days
                                                  daysOfTheMonth:nil
                                                 monthsOfTheYear:nil
                                                  weeksOfTheYear:nil
                                                   daysOfTheYear:nil
                                                    setPositions:nil
                                                             end:recurrenceEnd];
}

- (nullable NSString *)repeatSummary
{
    if (!self.repeats) return nil;

    NSString *unit;
    switch (self.frequency) {
        case EKRecurrenceFrequencyDaily:   unit = self.interval == 1 ? NSLocalizedString(@"day", @"")   : NSLocalizedString(@"days", @"");   break;
        case EKRecurrenceFrequencyWeekly:  unit = self.interval == 1 ? NSLocalizedString(@"week", @"")  : NSLocalizedString(@"weeks", @"");  break;
        case EKRecurrenceFrequencyMonthly: unit = self.interval == 1 ? NSLocalizedString(@"month", @"") : NSLocalizedString(@"months", @""); break;
        case EKRecurrenceFrequencyYearly:  unit = self.interval == 1 ? NSLocalizedString(@"year", @"")  : NSLocalizedString(@"years", @"");  break;
    }

    NSMutableString *s = [NSMutableString new];
    if (self.daysOfWeek.count > 0 && self.interval == 1) {
        [s appendString:NSLocalizedString(@"Every ", @"")];
    }
    else if (self.interval == 1) {
        [s appendFormat:NSLocalizedString(@"Every %@", @""), unit];
    }
    else {
        [s appendFormat:NSLocalizedString(@"Every %zd %@", @""), self.interval, unit];
    }

    if (self.daysOfWeek.count > 0) {
        NSArray<NSString *> *symbols = [[NSDateFormatter new] shortWeekdaySymbols];
        NSMutableArray *names = [NSMutableArray new];
        for (NSNumber *d in self.daysOfWeek) {
            NSInteger i = d.integerValue - 1;
            if (i >= 0 && i < (NSInteger)symbols.count) [names addObject:symbols[i]];
        }
        if (self.interval != 1) [s appendString:NSLocalizedString(@" on ", @"")];
        [s appendString:[names componentsJoinedByString:@", "]];
    }

    if (self.count > 0) {
        [s appendFormat:NSLocalizedString(@", %zd times", @""), self.count];
    }
    else if (self.until) {
        NSString *date = [NSDateFormatter localizedStringFromDate:self.until
                                                        dateStyle:NSDateFormatterMediumStyle
                                                        timeStyle:NSDateFormatterNoStyle];
        [s appendFormat:NSLocalizedString(@", until %@", @""), date];
    }
    return s;
}

@end

#pragma mark -

@implementation QuickEntryParser
{
    JSContext *_context;
    JSValue *_parseFunction;
}

+ (instancetype)sharedParser
{
    static QuickEntryParser *shared = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        shared = [QuickEntryParser new];
    });
    return shared;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        NSString *path = [[NSBundle mainBundle] pathForResource:@"quickentry.bundle" ofType:@"js"];
        NSString *source = path ? [NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:NULL] : nil;
        if (!source) {
            NSLog(@"QuickEntry: quickentry.bundle.js is missing from the app's resources.");
            return self;
        }
        _context = [JSContext new];
        _context.exceptionHandler = ^(JSContext *ctx, JSValue *exception) {
            NSLog(@"QuickEntry JavaScript error: %@", exception);
        };
        [_context evaluateScript:source];
        _parseFunction = _context[@"QuickEntry"][@"parse"];
        if (_parseFunction.isUndefined) {
            NSLog(@"QuickEntry: the bundle loaded but QuickEntry.parse is undefined.");
            _parseFunction = nil;
        }
    }
    return self;
}

static NSDate *DateFromMillis(id value)
{
    if (![value isKindOfClass:[NSNumber class]]) return nil;
    return [NSDate dateWithTimeIntervalSince1970:[value doubleValue] / 1000.0];
}

static NSString *StringOrNil(id value)
{
    if (![value isKindOfClass:[NSString class]]) return nil;
    NSString *s = [value stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    return s.length ? s : nil;
}

- (nullable QuickEntryResult *)parse:(NSString *)text
{
    if (!_parseFunction) return nil;

    double nowMillis = [[NSDate date] timeIntervalSince1970] * 1000.0;
    JSValue *jsResult = [_parseFunction callWithArguments:@[text ?: @"", @(nowMillis)]];
    if (!jsResult.isString) return nil;

    NSData *data = [[jsResult toString] dataUsingEncoding:NSUTF8StringEncoding];
    NSDictionary *d = [NSJSONSerialization JSONObjectWithData:data options:0 error:NULL];
    if (![d isKindOfClass:[NSDictionary class]]) return nil;

    QuickEntryResult *r = [QuickEntryResult new];
    r.title       = StringOrNil(d[@"title"]) ?: @"";
    r.location    = StringOrNil(d[@"location"]);
    r.calendarTag = StringOrNil(d[@"calendar"]);
    r.hasDate     = [d[@"hasDate"] boolValue];
    r.allDay      = [d[@"allDay"] boolValue];
    r.start       = DateFromMillis(d[@"start"]);
    r.end         = DateFromMillis(d[@"end"]);
    if ([d[@"durationMinutes"] isKindOfClass:[NSNumber class]]) {
        r.durationMinutes = [d[@"durationMinutes"] integerValue];
    }

    NSDictionary *rec = d[@"recurrence"];
    if ([rec isKindOfClass:[NSDictionary class]]) {
        NSString *freq = rec[@"frequency"];
        r.repeats = YES;
        if ([freq isEqualToString:@"daily"])        r.frequency = EKRecurrenceFrequencyDaily;
        else if ([freq isEqualToString:@"weekly"])  r.frequency = EKRecurrenceFrequencyWeekly;
        else if ([freq isEqualToString:@"monthly"]) r.frequency = EKRecurrenceFrequencyMonthly;
        else if ([freq isEqualToString:@"yearly"])  r.frequency = EKRecurrenceFrequencyYearly;
        else r.repeats = NO;
        if ([rec[@"interval"] isKindOfClass:[NSNumber class]]) r.interval = MAX(1, [rec[@"interval"] integerValue]);
        if ([rec[@"daysOfWeek"] isKindOfClass:[NSArray class]]) r.daysOfWeek = rec[@"daysOfWeek"];
        r.until = DateFromMillis(rec[@"until"]);
        if ([rec[@"count"] isKindOfClass:[NSNumber class]]) r.count = [rec[@"count"] integerValue];
    }
    return r;
}

@end
