//
//  PrefsAccountsVC.h
//  Itsycal
//
//  Settings tab for Itsycal's own calendar accounts: the Google sign-in app
//  (client ID and secret, stored in the keychain), Google accounts and plain
//  CalDAV accounts.
//

#import <Cocoa/Cocoa.h>

@class EventCenter;

@interface PrefsAccountsVC : NSViewController <NSTableViewDataSource, NSTableViewDelegate>

@property (nonatomic, weak) EventCenter *ec;

@end
