//
//  PrefsAccountsVC.h
//  Itsycal
//
//  Settings tab for Itsycal's own calendar accounts: the Google sign-in app
//  (client ID and secret, stored in the keychain), Google accounts and plain
//  CalDAV accounts.
//

#import <Cocoa/Cocoa.h>

@interface PrefsAccountsVC : NSViewController <NSTableViewDataSource, NSTableViewDelegate>

@end
