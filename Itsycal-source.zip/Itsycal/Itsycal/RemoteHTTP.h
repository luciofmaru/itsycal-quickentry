//
//  RemoteHTTP.h
//  Itsycal
//
//  Blocking HTTP helper for Itsycal's background sync queue (never call it on
//  the main thread). Uses an ephemeral session: no cookies, no disk cache.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

extern NSString * const RemoteHTTPErrorDomain;

@interface RemoteHTTP : NSObject

// Sends the request and waits for the reply. Returns the body (possibly
// empty) and the HTTP status in *status; nil and *error on network failure.
+ (nullable NSData *)send:(NSURLRequest *)request status:(nullable NSInteger *)status error:(NSError * _Nullable * _Nullable)error;

// A WebDAV request (PROPFIND/REPORT) with an XML body.
+ (NSMutableURLRequest *)davRequest:(NSString *)method url:(NSURL *)url depth:(NSString *)depth body:(NSString *)body;

// application/x-www-form-urlencoded POST.
+ (NSMutableURLRequest *)formPost:(NSURL *)url fields:(NSDictionary<NSString *, NSString *> *)fields;

+ (NSString *)formEncode:(NSString *)s;

+ (NSError *)errorWithStatus:(NSInteger)status message:(NSString *)message;

@end

NS_ASSUME_NONNULL_END
