//
//  EventCenter.m
//  Itsycal
//
//  Created by Sanjay Madan on 2/12/15.
//  Copyright (c) 2015 mowglii.com. All rights reserved.
//

#import <os/log.h>
#import <AppKit/NSWorkspace.h>
#import "EventCenter.h"
#import "RemoteCenter.h"

NSString * const kDefaultNewEventCalendar = @"DefaultNewEventCalendar";

// NSUserDefaults key for array of selected calendar IDs.
static NSString *kSelectedCalendars = @"SelectedCalendars";
// Remote calendars Itsycal has seen before. New ones start out ticked.
static NSString *kKnownRemoteCalendars = @"KnownRemoteCalendars";

// Properties auto-synthesized.
@implementation CalendarInfo @end
@implementation EventInfo    @end

@implementation EventCenter {                      // Accessed on:
    EKEventStore         *_store;
    NSCalendar           *_cal;
    NSMutableDictionary  *_eventsForDate;          // _queueWork
    NSDictionary         *_filteredEventsForDate;  // _queueIsol
    NSMutableIndexSet    *_previouslyFetchedDates; // _queueWork
    NSArray              *_sourcesAndCalendars;    // _queueIsol2
    dispatch_queue_t      _queueWork;
    dispatch_queue_t      _queueIsol;
    dispatch_queue_t      _queueIsol2;
}

- (instancetype)initWithCalendar:(NSCalendar *)calendar delegate:(id<EventCenterDelegate>)delegate {
    
    EKEventStoreRequestAccessCompletionHandler requestCompletionHandler = ^(BOOL granted, NSError *error) {
        if (granted) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [self->_store reset];
                [self refetchAll];
            });
        }
        else {
            // Fail silently. The alternative is to kick out to the
            // delegate so it can display an informative alert. But
            // that would happen every time the user launches Itsycal
            // (including when the system launches it at startup) and
            // seeing the same modal alert would get old fast.
        }
    };
    
    self = [super init];
    if (self) {
        _cal = calendar;
        _delegate = delegate;
        _sourcesAndCalendars = [NSArray new];
        _eventsForDate  = [NSMutableDictionary new];
        _filteredEventsForDate = [NSDictionary new];
        _previouslyFetchedDates = [NSMutableIndexSet new];
        _queueWork = dispatch_queue_create("com.mowglii.Itsycal.queueWork", DISPATCH_QUEUE_SERIAL);
        _queueIsol = dispatch_queue_create("com.mowglii.Itsycal.queueIsol", DISPATCH_QUEUE_SERIAL);
        _queueIsol2 = dispatch_queue_create("com.mowglii.Itsycal.queueIsol2", DISPATCH_QUEUE_SERIAL);
        _store = [EKEventStore new];
#if MAC_OS_X_VERSION_MAX_ALLOWED >= 140000
        if (@available(macOS 14.0, *)) {
            [_store requestFullAccessToEventsWithCompletion:requestCompletionHandler];
        } else {
            [_store requestAccessToEntityType:EKEntityTypeEvent completion:requestCompletionHandler];
        }
#else
        [_store requestAccessToEntityType:EKEntityTypeEvent completion:requestCompletionHandler];
#endif

        // Refetch everything when the event store has changed.
        __weak __typeof(self) weakSelf = self;
        [[NSNotificationCenter defaultCenter] addObserverForName:EKEventStoreChangedNotification object:_store queue:[NSOperationQueue mainQueue] usingBlock:^(NSNotification *note) {
            [weakSelf refetchAll];
        }];
        // ...and when Itsycal's own accounts (Google, CalDAV) have news.
        [[NSNotificationCenter defaultCenter] addObserverForName:RemoteCenterDidChangeNotification object:nil queue:[NSOperationQueue mainQueue] usingBlock:^(NSNotification *note) {
            [weakSelf refetchAll];
        }];
    }
    return self;
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

#pragma mark - Public (main thread)

- (BOOL)calendarAccessGranted {
#if MAC_OS_X_VERSION_MAX_ALLOWED >= 140000
    if (@available(macOS 14.0, *)) {
        return [EKEventStore authorizationStatusForEntityType:EKEntityTypeEvent] == EKAuthorizationStatusFullAccess;
    } else {
        return [EKEventStore authorizationStatusForEntityType:EKEntityTypeEvent] == EKAuthorizationStatusAuthorized;
    }
#else
    return [EKEventStore authorizationStatusForEntityType:EKEntityTypeEvent] == EKAuthorizationStatusAuthorized;
#endif
}

- (NSString *)defaultCalendarIdentifier {
    // A calendar chosen in Itsycal's settings (can be a Google calendar)...
    NSString *chosen = [[NSUserDefaults standardUserDefaults] stringForKey:kDefaultNewEventCalendar];
    if (chosen.length) {
        id calendar = [self calendarWithIdentifier:chosen];
        if ([calendar allowsContentModifications]) return chosen;
    }
    // ...or the Mac's default calendar.
    EKCalendar *cal = [_store defaultCalendarForNewEvents];
    return cal.calendarIdentifier;
}

- (id)calendarWithIdentifier:(NSString *)identifier {
    for (id obj in [self sourcesAndCalendars]) {
        if (![obj isKindOfClass:[CalendarInfo class]]) continue;
        CalendarInfo *info = obj;
        if ([info.calendar.calendarIdentifier isEqualToString:identifier]) return info.calendar;
    }
    return nil;
}

#pragma mark - Saving drafts

static NSError *ItsyError(NSString *message) {
    return [NSError errorWithDomain:@"Itsycal" code:1 userInfo:@{NSLocalizedDescriptionKey: message}];
}

static NSString *Trimmed(NSString *s) {
    return [s stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] ?: @"";
}

// Fills in an EventKit event from a draft.
- (void)applyDraft:(EventDraft *)d toEvent:(EKEvent *)e isNew:(BOOL)isNew {
    if ([d.calendar isKindOfClass:[EKCalendar class]] &&
        (isNew || ![e.calendar.calendarIdentifier isEqualToString:((EKCalendar *)d.calendar).calendarIdentifier])) {
        e.calendar = d.calendar;   // a new event also gets the calendar's default alerts
    }
    e.title    = Trimmed(d.title);
    e.location = Trimmed(d.location).length ? Trimmed(d.location) : nil;
    e.URL      = d.URL;
    e.notes    = Trimmed(d.notes).length ? Trimmed(d.notes) : nil;
    e.allDay   = d.allDay;
    e.startDate = d.startDate;
    e.endDate   = d.endDate;
    // timeZone MUST be nil for all-day events (see the note in EventViewController).
    e.timeZone = d.allDay ? nil : (isNew ? [NSTimeZone localTimeZone] : (e.timeZone ?: [NSTimeZone localTimeZone]));
    if (d.repeatSet) {
        e.recurrenceRules = d.recurrenceRule ? @[d.recurrenceRule] : nil;
    }
    if (d.alertSet) {
        for (EKAlarm *alarm in [e.alarms copy]) [e removeAlarm:alarm];
        if (d.alertOffset) [e addAlarm:[EKAlarm alarmWithRelativeOffset:d.alertOffset.doubleValue]];
    }
}

// Wall-clock fields of `date` in `zone`, in remote.js's format.
static NSDictionary *TimeDict(NSDate *date, NSTimeZone *zone) {
    NSCalendar *cal = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    cal.timeZone = zone;
    NSDateComponents *c = [cal components:NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay |
                           NSCalendarUnitHour | NSCalendarUnitMinute | NSCalendarUnitSecond fromDate:date];
    NSString *name = zone.secondsFromGMT == 0 && [zone.name hasPrefix:@"GMT"] ? @"UTC" : zone.name;
    return @{@"y": @(c.year), @"M": @(c.month), @"d": @(c.day), @"h": @(c.hour), @"m": @(c.minute),
             @"s": @(c.second), @"tz": name};
}

static NSDictionary *DateDict(NSDate *date) {
    NSCalendar *cal = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    cal.timeZone = [NSTimeZone localTimeZone];
    NSDateComponents *c = [cal components:NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay fromDate:date];
    return @{@"y": @(c.year), @"M": @(c.month), @"d": @(c.day), @"date": @YES};
}

static NSDictionary *RuleDict(EKRecurrenceRule *rule, BOOL allDay) {
    NSString *freq = @"DAILY";
    switch (rule.frequency) {
        case EKRecurrenceFrequencyDaily:   freq = @"DAILY"; break;
        case EKRecurrenceFrequencyWeekly:  freq = @"WEEKLY"; break;
        case EKRecurrenceFrequencyMonthly: freq = @"MONTHLY"; break;
        case EKRecurrenceFrequencyYearly:  freq = @"YEARLY"; break;
    }
    NSMutableDictionary *r = [@{@"freq": freq, @"interval": @(MAX(1, rule.interval))} mutableCopy];
    if (rule.daysOfTheWeek.count) {
        NSArray *names = @[@"SU", @"MO", @"TU", @"WE", @"TH", @"FR", @"SA"];
        NSMutableArray *days = [NSMutableArray new];
        for (EKRecurrenceDayOfWeek *d in rule.daysOfTheWeek) {
            NSInteger i = d.dayOfTheWeek - 1;
            if (i < 0 || i > 6) continue;
            [days addObject:d.weekNumber ? [NSString stringWithFormat:@"%ld%@", (long)d.weekNumber, names[i]] : names[i]];
        }
        r[@"byday"] = days;
    }
    if (rule.daysOfTheMonth.count) r[@"bymonthday"] = rule.daysOfTheMonth;
    if (rule.monthsOfTheYear.count) r[@"bymonth"] = rule.monthsOfTheYear;
    if (rule.setPositions.count) r[@"bysetpos"] = rule.setPositions;
    EKRecurrenceEnd *end = rule.recurrenceEnd;
    if (end.occurrenceCount > 0) {
        r[@"count"] = @(end.occurrenceCount);
    } else if (end.endDate) {
        r[@"until"] = allDay ? DateDict(end.endDate) : TimeDict(end.endDate, [NSTimeZone timeZoneForSecondsFromGMT:0]);
    }
    return r;
}

// A draft in remote.js's format. zoneName: the zone to write times in
// (an edited event keeps its own); occurrenceStart/wasAllDay: the occurrence
// being edited, so a series moves by the same amount.
- (NSDictionary *)remoteFieldsForDraft:(EventDraft *)d zoneName:(NSString *)zoneName
                       occurrenceStart:(NSDate *)occurrenceStart wasAllDay:(BOOL)wasAllDay {
    NSTimeZone *zone = nil;
    if ([zoneName isEqualToString:@"UTC"]) zone = [NSTimeZone timeZoneForSecondsFromGMT:0];
    else if (zoneName.length) zone = [NSTimeZone timeZoneWithName:zoneName];
    if (!zone) zone = [NSTimeZone localTimeZone];

    NSMutableDictionary *f = [NSMutableDictionary new];
    f[@"title"]    = Trimmed(d.title);
    f[@"location"] = Trimmed(d.location);
    f[@"notes"]    = Trimmed(d.notes);
    f[@"url"]      = d.URL.absoluteString ?: @"";
    if (d.allDay) {
        // iCalendar all-day ends are the day after the last day.
        NSCalendar *cal = [NSCalendar currentCalendar];
        NSDate *lastDay = [cal startOfDayForDate:d.endDate];
        NSDate *firstDay = [cal startOfDayForDate:d.startDate];
        if ([lastDay compare:firstDay] == NSOrderedAscending) lastDay = firstDay;
        f[@"start"] = DateDict(firstDay);
        f[@"end"]   = DateDict([cal dateByAddingUnit:NSCalendarUnitDay value:1 toDate:lastDay options:0]);
    } else {
        f[@"start"] = TimeDict(d.startDate, zone);
        f[@"end"]   = TimeDict([d.endDate compare:d.startDate] == NSOrderedAscending ? d.startDate : d.endDate, zone);
    }
    if (occurrenceStart) {
        f[@"occStart"] = wasAllDay ? DateDict(occurrenceStart) : TimeDict(occurrenceStart, zone);
    }
    if (d.repeatSet) {
        f[@"rrule"] = d.recurrenceRule ? RuleDict(d.recurrenceRule, d.allDay) : [NSNull null];
    }
    if (d.alertSet) {
        f[@"alarm"] = d.alertOffset ?: [NSNull null];
    }
    return f;
}

- (void)createEventFromDraft:(EventDraft *)draft completion:(void (^)(NSError *))completion {
    if ([RemoteCalendarItem isRemote:draft.calendar]) {
        NSDictionary *fields = [self remoteFieldsForDraft:draft zoneName:nil occurrenceStart:nil wasAllDay:NO];
        [[RemoteCenter shared] createEventWithFields:fields inCalendar:draft.calendar completion:completion];
        return;
    }
    if (![draft.calendar isKindOfClass:[EKCalendar class]]) {
        completion(ItsyError(NSLocalizedString(@"Choose a calendar for the event.", @"")));
        return;
    }
    EKEvent *event = [EKEvent eventWithEventStore:_store];
    [self applyDraft:draft toEvent:event isNew:YES];
    NSError *error = nil;
    BOOL saved = [_store saveEvent:event span:EKSpanThisEvent commit:YES error:&error];
    completion(saved ? nil : (error ?: ItsyError(NSLocalizedString(@"The event couldn't be saved.", @""))));
}

- (void)updateEvent:(EKEvent *)event withDraft:(EventDraft *)draft span:(ItsySpan)span completion:(void (^)(NSError *))completion {
    if ([RemoteCalendarItem isRemote:event]) {
        RemoteEventItem *remote = (RemoteEventItem *)event;
        BOOL series = remote.isSeriesOccurrence;
        NSString *scope = (series && span == ItsySpanThisEvent) ? @"this" : @"all";
        NSDictionary *fields = [self remoteFieldsForDraft:draft zoneName:remote.startTimeZoneName
                                          occurrenceStart:remote.startDate wasAllDay:remote.isAllDay];
        [[RemoteCenter shared] updateEvent:remote scope:scope fields:fields completion:completion];
        return;
    }
    if (![event refresh]) {
        completion(ItsyError(NSLocalizedString(@"This event no longer exists.", @"")));
        return;
    }
    [self applyDraft:draft toEvent:event isNew:NO];
    NSError *error = nil;
    EKSpan ekSpan = (event.hasRecurrenceRules && span != ItsySpanThisEvent) ? EKSpanFutureEvents : EKSpanThisEvent;
    BOOL saved = [_store saveEvent:event span:ekSpan commit:YES error:&error];
    if (!saved) [event reset];
    completion(saved ? nil : (error ?: ItsyError(NSLocalizedString(@"The event couldn't be saved.", @""))));
}

- (void)deleteEvent:(EKEvent *)event span:(ItsySpan)span completion:(void (^)(NSError *))completion {
    if ([RemoteCalendarItem isRemote:event]) {
        RemoteEventItem *remote = (RemoteEventItem *)event;
        NSString *scope = !remote.isSeriesOccurrence ? @"all"
                        : span == ItsySpanThisEvent ? @"this"
                        : span == ItsySpanFutureEvents ? @"future" : @"all";
        [[RemoteCenter shared] deleteEvent:remote scope:scope completion:completion];
        return;
    }
    NSError *error = nil;
    EKSpan ekSpan = span == ItsySpanThisEvent ? EKSpanThisEvent : EKSpanFutureEvents;
    BOOL removed = [_store removeEvent:event span:ekSpan commit:YES error:&error];
    completion(removed ? nil : (error ?: ItsyError(NSLocalizedString(@"The event couldn't be deleted.", @""))));
}

- (EKEvent *)newEvent {
    return [EKEvent eventWithEventStore:_store];
}

- (BOOL)saveEvent:(EKEvent *)event error:(NSError **)error {
    return [_store saveEvent:event span:EKSpanThisEvent commit:YES error:error];
}

- (BOOL)removeEvent:(EKEvent *)event span:(EKSpan)span error:(NSError **)error {
    return [_store removeEvent:event span:span commit:YES error:error];
}

- (void)updateSelectedCalendarsForIdentifier:(NSString *)identifier selected:(BOOL)selected {
    //os_log(OS_LOG_DEFAULT, "%s", __FUNCTION__);
    // The user has selected/unselected a calendar in Prefs.
    // Update the kSelectedCalendars array in NSUserDefaults.
    __block NSMutableArray *selectedCalendars = [NSMutableArray new];
    dispatch_sync(_queueIsol2, ^{
        for (id obj in self->_sourcesAndCalendars) {
            if ([obj isKindOfClass:[CalendarInfo class]]) {
                CalendarInfo *info = obj;
                if ([info.calendar.calendarIdentifier isEqualToString:identifier]) {
                    info.selected = selected;
                }
                if (info.selected) {
                    [selectedCalendars addObject:info.calendar.calendarIdentifier];
                }
            }
        }
    });
    [[NSUserDefaults standardUserDefaults] setObject:selectedCalendars forKey:kSelectedCalendars];
    
    // Filter events based on new calendar selection.
    dispatch_async(_queueWork, ^{
        [self _filterEvents];
    });
}

- (NSArray *)sourcesAndCalendars {
    //os_log(OS_LOG_DEFAULT, "%s", __FUNCTION__);
    __block NSArray *sourcesAndCalendars;
    dispatch_sync(_queueIsol2, ^{
        sourcesAndCalendars = [self->_sourcesAndCalendars copy];
    });
    return sourcesAndCalendars;
}

- (NSDictionary *)filteredEventsForDate {
    //os_log(OS_LOG_DEFAULT, "%s", __FUNCTION__);
    __block NSDictionary *filteredEventsForDate;
    dispatch_sync(_queueIsol, ^{
        filteredEventsForDate = [self->_filteredEventsForDate copy];
    });
    return filteredEventsForDate;
}

- (void)fetchEvents {
    //os_log(OS_LOG_DEFAULT, "%s", __FUNCTION__);
    MoDate startMoDate = [self.delegate fetchStartDate];
    MoDate endMoDate   = [self.delegate fetchEndDate];
    dispatch_async(_queueWork, ^{
        @autoreleasepool {
            [self _fetchEventsWithStartDate:startMoDate endDate:endMoDate refetch:NO];
        }
    });
}

- (void)refetchAll {
    //os_log(OS_LOG_DEFAULT, "%s", __FUNCTION__);
    // Either the system told us the event store has changed or
    // we were called by the main controller. Clear the cache
    // and refetch everything.
    MoDate startMoDate = [self.delegate fetchStartDate];
    MoDate endMoDate   = [self.delegate fetchEndDate];
    dispatch_async(_queueWork, ^{
        @autoreleasepool {
            [self _fetchSourcesAndCalendars];
            [self _fetchEventsWithStartDate:startMoDate endDate:endMoDate refetch:YES];
        }
    });
}

- (void)refresh {
    dispatch_async(_queueWork, ^{
        [self->_store reset];
        [self->_store refreshSourcesIfNecessary];
    });
    [[RemoteCenter shared] syncAll];
}

#pragma mark - Private (GCD thread pool)

- (void)_fetchSourcesAndCalendars {
    //os_log(OS_LOG_DEFAULT, " %s", __FUNCTION__);
    // Get an array of the user's calendars sorted first by
    // source title and then by calendar title.
    NSArray *calendars = [[_store calendarsForEntityType:EKEntityTypeEvent] sortedArrayUsingComparator:^NSComparisonResult(EKCalendar *cal1, EKCalendar *cal2) {
        if ([cal1.source.sourceIdentifier isEqualToString:cal2.source.sourceIdentifier]) {
            return [cal1.title compare:cal2.title];
        }
        else {
            return [cal1.source.title compare:cal2.source.title];
        }
    }];
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSSet *selectedCalendars = [NSSet setWithArray:[defaults arrayForKey:kSelectedCalendars]];
    
    // Make an array of source titles and calendar info.
    NSMutableArray *sourcesAndCalendars = [NSMutableArray new];
    NSString *currentSourceTitle = @"";
    for (EKCalendar *calendar in calendars) {
        NSString *calendarSourceTitle = calendar.source.title;
        // (!) Should never hit this case, but MacOS 13 sometimes returns
        // nil for non-iCloud source titles. Use a dummy title instead.
        if (!calendar.source.title) calendarSourceTitle = @"???";
        if (!calendar.color) {
            // Skip calendars where the color is nil.
            // This normally doesn't happen, but there are some
            // edge cases where it does.
            // See: github.com/sfsam/Itsycal/issues/152
            continue;
        }
        if (![calendarSourceTitle isEqualToString:currentSourceTitle]) {
            [sourcesAndCalendars addObject:calendarSourceTitle];
            currentSourceTitle = calendarSourceTitle;
        }
        CalendarInfo *calInfo = [CalendarInfo new];
        calInfo.calendar = calendar;
        calInfo.selected = selectedCalendars ? [selectedCalendars containsObject:calendar.calendarIdentifier] : NO;
        [sourcesAndCalendars addObject:calInfo];
    }

    // Calendars from Itsycal's own accounts follow the Mac's calendars.
    NSMutableArray *known = [[defaults arrayForKey:kKnownRemoteCalendars] mutableCopy] ?: [NSMutableArray new];
    NSMutableArray *selected = [[defaults arrayForKey:kSelectedCalendars] mutableCopy] ?: [NSMutableArray new];
    BOOL defaultsChanged = NO;
    for (id obj in [[RemoteCenter shared] sourcesAndCalendars]) {
        if ([obj isKindOfClass:[NSString class]]) {
            [sourcesAndCalendars addObject:obj];
            continue;
        }
        RemoteCalendarItem *remote = obj;
        NSString *identifier = remote.calendarIdentifier;
        if (![known containsObject:identifier]) {
            [known addObject:identifier];
            if (![selected containsObject:identifier]) [selected addObject:identifier];
            defaultsChanged = YES;
        }
        CalendarInfo *calInfo = [CalendarInfo new];
        calInfo.calendar = (EKCalendar *)remote;   // see RemoteItems.h
        calInfo.selected = [selected containsObject:identifier];
        [sourcesAndCalendars addObject:calInfo];
    }
    if (defaultsChanged) {
        [defaults setObject:known forKey:kKnownRemoteCalendars];
        [defaults setObject:selected forKey:kSelectedCalendars];
    }

    dispatch_async(_queueIsol2, ^{
        self->_sourcesAndCalendars = [NSArray arrayWithArray:sourcesAndCalendars];
    });
}

- (NSArray *)_validCalendars
{
    // Valid calendars are calendars in _sourcesAndCalendars.
    // They have been filtered to remove calendars where the color is nil.
    // See -_fetchSourcesAndCalendars
    __block NSMutableArray *calendars = [NSMutableArray new];
    dispatch_sync(_queueIsol2, ^{
        for (id obj in self->_sourcesAndCalendars) {
            if ([obj isKindOfClass:[CalendarInfo class]]) {
                CalendarInfo *calInfo = obj;
                // Only EventKit calendars; remote ones never go to EKEventStore.
                if ([calInfo.calendar isKindOfClass:[EKCalendar class]]) {
                    [calendars addObject:calInfo.calendar];
                }
            }
        }
    });
    return calendars;
}

- (void)_fetchEventsWithStartDate:(MoDate)startMoDate endDate:(MoDate)endMoDate refetch:(BOOL)refetch
{
    //os_log(OS_LOG_DEFAULT, " %s", __FUNCTION__);
    if (refetch) {
        _previouslyFetchedDates = [NSMutableIndexSet new];
        _eventsForDate = [NSMutableDictionary new];
    }
    // Return immediately if we've already fetched for this date range.
    NSRange dateRange = NSMakeRange(startMoDate.julian, endMoDate.julian - startMoDate.julian);
    if ([_previouslyFetchedDates containsIndexesInRange:dateRange])  {
        //os_log(OS_LOG_DEFAULT, "SKIPPING: %@ - %@", NSStringFromMoDate(startMoDate), NSStringFromMoDate(endMoDate));
        return;
    }
    
    // Reduce the range [startMoDate, endMoDate] based on dates previously fetched.
    NSMutableIndexSet *notYetFetchedDates = [NSMutableIndexSet new];
    for (NSInteger julian = startMoDate.julian; julian <= endMoDate.julian; julian++) {
        if (![_previouslyFetchedDates containsIndex:julian]) {
            [notYetFetchedDates addIndex:julian];
        }
    }
    if (notYetFetchedDates.count > 0) {
        startMoDate = MakeGregorian(notYetFetchedDates.firstIndex);
        endMoDate   = MakeGregorian(notYetFetchedDates.lastIndex);
    }
    
    // Update _previouslyFetchedDates for this fetch.
    [_previouslyFetchedDates addIndexesInRange:dateRange];
    
    NSDate *startDate = MakeNSDateWithDate(startMoDate, _cal);
    NSDate *endDate   = MakeNSDateWithDate(endMoDate,   _cal);
    NSArray *cals = [self _validCalendars];
    NSMutableArray *events = [NSMutableArray new];
    if (cals.count > 0) {
        NSPredicate *predicate = [_store predicateForEventsWithStartDate:startDate endDate:endDate calendars:cals];
        [events addObjectsFromArray:[_store eventsMatchingPredicate:predicate] ?: @[]];
    }
    // Events from Itsycal's own accounts (RemoteEventItem; see RemoteItems.h).
    [events addObjectsFromArray:[[RemoteCenter shared] eventsFromDate:startDate toDate:endDate]];
    NSMutableDictionary *eventsForDate = [NSMutableDictionary new];
    
    // Does EKEvent still respond to the private 'participationStatus'
    // selector? Check once instead of risking an NSUndefinedKeyException
    // on every event if a future OS renames or removes it.
    static BOOL participationStatusKeySupported;
    static dispatch_once_t participationStatusOnceToken;
    dispatch_once(&participationStatusOnceToken, ^{
        participationStatusKeySupported = [EKEvent instancesRespondToSelector:NSSelectorFromString(@"participationStatus")];
    });

    // Iterate over events matching startDate/endDate. We will
    // populate a dictionary, eventsForDate, that maps each date
    // to an array of events that fall on that date.
    for (EKEvent *event in events) {
        
        // Skip events the current user has declined.
        // Use 'valueForKey' to get private 'participationStatus' property.
        // This is much faster than accessing the 'attendees' property
        // and then looping over the participants to see if the current
        // user has declined the event.
        if (event.hasAttendees && participationStatusKeySupported &&
            [[event valueForKey:@"participationStatus"] integerValue] == EKParticipantStatusDeclined) {
            continue;
        }
        
        // Iterate through the days this event spans. We only care about
        // days for this event that are between startDate and endDate.
        NSDate *date  = [event.startDate laterDate:startDate];
        NSDate *final = [event.endDate earlierDate:endDate];
        date  = [_cal startOfDayForDate:date];
        while ([date compare:final] == NSOrderedAscending) {
            
            NSDate *nextDate = [_cal dateByAddingUnit:NSCalendarUnitDay value:1 toDate:date options:0];
            nextDate = [_cal startOfDayForDate:nextDate];
            
            // Make an EventInfo object...
            EventInfo *info = [EventInfo new];
            info.event       = event;
            //   isStartDate = (it starts on `date` AND ends not before `nextDate`)
            info.isStartDate = ([_cal isDate:date inSameDayAsDate:event.startDate] &&
                                [event.endDate compare:nextDate] != NSOrderedAscending);
            //   isEndDate   = (it ends on `date` AND starts before `date`)
            info.isEndDate   = ([_cal isDate:date inSameDayAsDate:event.endDate] &&
                                [event.startDate compare:date] == NSOrderedAscending);
            //   isAllDay    = (it's a real all-day event OR
            //                  (it starts before `date` AND ends not before `nextDate`))
            info.isAllDay    = (event.allDay ||
                                ([event.startDate compare:date] == NSOrderedAscending &&
                                 [event.endDate compare:nextDate] != NSOrderedAscending));
            // ...and add it to the array in eventsForDate.
            if (eventsForDate[date] == nil) {
                eventsForDate[date] = [NSMutableArray new];
            }
            [eventsForDate[date] addObject:info];
            
            date = nextDate;
        }
    }
    
    // eventsForDate is a dict that maps dates to an array of EventInfo objects.
    // Sort those arrays so that AllDay events are first, the sort by startTime.
    // All-day events are sorted by calendar title with real all-day events before
    // spanning all-day events.
    for (NSDate *date in eventsForDate) {
        [eventsForDate[date] sortUsingComparator:^NSComparisonResult(EventInfo *e1, EventInfo *e2) {
            if (e1.event.isAllDay && e2.event.isAllDay)  { return [e1.event.calendar.title compare:e2.event.calendar.title];}
            else if (e1.event.isAllDay && !e2.event.isAllDay) { return NSOrderedAscending; }
            else if (!e1.event.isAllDay && e2.event.isAllDay) { return NSOrderedDescending; }
            else if (e1.isAllDay && e2.isAllDay) { return [e1.event.calendar.title compare:e2.event.calendar.title];}
            else if (e1.isAllDay) { return NSOrderedAscending;  }
            else if (e2.isAllDay) { return NSOrderedDescending; }
            else { return [e1.event.startDate compare:e2.event.startDate]; }
        }];
    }
    
    [_eventsForDate addEntriesFromDictionary:eventsForDate];
    [self _filterEvents];
}

- (void)_filterEvents {
    //os_log(OS_LOG_DEFAULT, " %s", __FUNCTION__);
    NSMutableDictionary *filteredEventsForDate = [NSMutableDictionary new];
    NSArray *selectedCalendars = [[NSUserDefaults standardUserDefaults] arrayForKey:kSelectedCalendars];
    for (NSDate *date in _eventsForDate) {
        for (EventInfo *info in _eventsForDate[date]) {
            if ([selectedCalendars containsObject:info.event.calendar.calendarIdentifier]) {
                if (filteredEventsForDate[date] == nil) {
                    filteredEventsForDate[date] = [NSMutableArray new];
                }
                // Check if there is a virtual meeting (e.g. Zoom) link.
                // We limit this check to filtered events in an
                // attempt to limit how much text processing we do.
                [self checkForZoomURL:info];
                [filteredEventsForDate[date] addObject:info];
            }
        }
    }
    // Notify the delegate from inside the _queueIsol block so the
    // write to _filteredEventsForDate is visible before the delegate
    // reads it back via -filteredEventsForDate.
    dispatch_async(_queueIsol, ^{
        self->_filteredEventsForDate = [filteredEventsForDate copy];
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.delegate eventCenterEventsChanged];
        });
    });
}

- (void)checkForZoomURL:(EventInfo *)info {
    static NSDataDetector *linkDetector = nil;
    if (linkDetector == nil) {
        linkDetector = [NSDataDetector dataDetectorWithTypes:NSTextCheckingTypeLink error:NULL];
    }
    void (^GetZoomURL)(NSString*) = ^(NSString *text) {
        [linkDetector enumerateMatchesInString:text options:kNilOptions range:NSMakeRange(0, text.length) usingBlock:^(NSTextCheckingResult * _Nullable result, NSMatchingFlags flags, BOOL * _Nonnull stop) {
            NSURL *url = result.URL;
            NSString *link = url.absoluteString;
            // Match on the URL's host (and scheme, for app-link URIs), not on
            // the raw URL string. A substring check like
            // [link containsString:@"zoom.us/j/"] would also match a hostile
            // link such as https://evil.example/zoom.us/j/123.
            NSString *host   = url.host.lowercaseString ?: @"";
            NSString *path   = url.path ?: @"";
            NSString *scheme = url.scheme.lowercaseString ?: @"";
            BOOL (^hostIs)(NSString *) = ^BOOL(NSString *domain) {
                return [host isEqualToString:domain] || [host hasSuffix:[@"." stringByAppendingString:domain]];
            };
            BOOL (^hostHasPrefix)(NSString *) = ^BOOL(NSString *prefix) {
                return [host hasPrefix:prefix];
            };
            if (   (hostIs(@"zoom.us") || hostIs(@"zoomgov.com"))
                && ([path hasPrefix:@"/j/"] || [path hasPrefix:@"/s/"]
                    || [path hasPrefix:@"/w/"] || [path hasPrefix:@"/my/"])) {
                info.zoomURL = url;
                // Test if user has the Zoom app and, if so, create a Zoom app link.
                if ([NSWorkspace.sharedWorkspace URLForApplicationToOpenURL:[NSURL URLWithString:@"zoommtg://"]]) {
                    link = [link stringByReplacingOccurrencesOfString:@"https://" withString:@"zoommtg://"];
                    link = [link stringByReplacingOccurrencesOfString:@"?" withString:@"&"];
                    link = [link stringByReplacingOccurrencesOfString:@"/j/" withString:@"/join?confno="];
                    link = [link stringByReplacingOccurrencesOfString:@"/s/" withString:@"/join?confno="];
                    link = [link stringByReplacingOccurrencesOfString:@"/w/" withString:@"/join?confno="];
                    NSURL *appLink = [NSURL URLWithString:link];
                    if (appLink) info.zoomURL = appLink;
                }
            }
            else if (hostIs(@"teams.microsoft.com") && [path hasPrefix:@"/l/meetup-join/"]) {
                info.zoomURL = url;
                // Test if user has the Teams app and, if so, create a Teams app link.
                if ([NSWorkspace.sharedWorkspace URLForApplicationToOpenURL:[NSURL URLWithString:@"msteams://"]]) {
                    link = [link stringByReplacingOccurrencesOfString:@"https://" withString:@"msteams://"];
                    NSURL *appLink = [NSURL URLWithString:link];
                    if (appLink) info.zoomURL = appLink;
                }
            }
            else if (hostIs(@"chime.aws")) {
                info.zoomURL = url;
                // Test if user has the Chime app, and if so, create a Chime app link.
                if ([NSWorkspace.sharedWorkspace URLForApplicationToOpenURL:[NSURL URLWithString:@"chime://"]]) {
                    link = [link stringByReplacingOccurrencesOfString:@"https://chime.aws/" withString:@"chime://meeting?pin="];
                    NSURL *appLink = [NSURL URLWithString:link];
                    if (appLink) info.zoomURL = appLink;
                }
            }
            else if (   [scheme isEqualToString:@"zoommtg"]
                     || [scheme isEqualToString:@"msteams"]
                     || [scheme isEqualToString:@"chime"]
                     || hostIs(@"meet.google.com")
                     || hostIs(@"hangouts.google.com")
                     || hostIs(@"webex.com")
                     || (hostIs(@"gotomeeting.com") && [path hasPrefix:@"/join"])
                     || (hostIs(@"ringcentral.com") && [path hasPrefix:@"/j"])
                     || (hostIs(@"bigbluebutton.org") && [path hasPrefix:@"/gl"])
                     || ([scheme isEqualToString:@"https"] && (hostHasPrefix(@"bigbluebutton.") || hostHasPrefix(@"bbb.")))
                     || hostIs(@"meet.jit.si")
                     || hostIs(@"indigo.collocall.de")
                     || hostIs(@"public.senfcall.de")
                     || (hostIs(@"facetime.apple.com") && [path hasPrefix:@"/join"])
                     || (hostIs(@"workplace.com") && [path hasPrefix:@"/meet"])
                     || (hostIs(@"youcanbook.me") && [path hasPrefix:@"/zoom/"])
                     || (hostIs(@"vk.com") && [path hasPrefix:@"/call/"])) {
                info.zoomURL = url;
            }
            *stop = info.zoomURL != nil;
        }];
    };
    info.zoomURL = nil;
    if (info.event.location) GetZoomURL(info.event.location);
    if (info.zoomURL) return;
    if (info.event.URL) GetZoomURL(info.event.URL.absoluteString);
    if (info.zoomURL) return;
    if (info.event.hasNotes && info.event.notes) GetZoomURL(info.event.notes);
}

@end
