//
//  GoogleOAuth.m
//  Itsycal
//

#import "GoogleOAuth.h"
#import "RemoteHTTP.h"
#import "RemoteJS.h"
#import <AppKit/AppKit.h>
#import <CommonCrypto/CommonDigest.h>
#import <Security/Security.h>
#import <sys/socket.h>
#import <sys/time.h>
#import <netinet/in.h>
#import <arpa/inet.h>
#import <fcntl.h>
#import <unistd.h>

NSString * const GoogleOAuthErrorDomain = @"Itsycal.GoogleOAuth";
const NSInteger GoogleOAuthErrorSignInAgain = 401;

static NSString * const kAuthURL   = @"https://accounts.google.com/o/oauth2/v2/auth";
static NSString * const kTokenURL  = @"https://oauth2.googleapis.com/token";
static NSString * const kRevokeURL = @"https://oauth2.googleapis.com/revoke";
// Calendar read/write (CalDAV needs the full calendar scope), plus the
// account's email address so Itsycal can label the account.
static NSString * const kScopes    = @"openid email https://www.googleapis.com/auth/calendar";
static const NSTimeInterval kSignInTimeout = 300;

static NSError *OAuthError(NSInteger code, NSString *message)
{
    return [NSError errorWithDomain:GoogleOAuthErrorDomain code:code
                           userInfo:@{NSLocalizedDescriptionKey: message}];
}

static NSString *RandomURLSafeString(NSUInteger bytes)
{
    NSMutableData *data = [NSMutableData dataWithLength:bytes];
    if (SecRandomCopyBytes(kSecRandomDefault, bytes, data.mutableBytes) != errSecSuccess) {
        arc4random_buf(data.mutableBytes, bytes);
    }
    NSString *b64 = [data base64EncodedStringWithOptions:0];
    b64 = [b64 stringByReplacingOccurrencesOfString:@"+" withString:@"-"];
    b64 = [b64 stringByReplacingOccurrencesOfString:@"/" withString:@"_"];
    return [b64 stringByReplacingOccurrencesOfString:@"=" withString:@""];
}

static NSString *PKCEChallenge(NSString *verifier)
{
    NSData *v = [verifier dataUsingEncoding:NSASCIIStringEncoding];
    unsigned char digest[CC_SHA256_DIGEST_LENGTH];
    CC_SHA256(v.bytes, (CC_LONG)v.length, digest);
    NSString *b64 = [[NSData dataWithBytes:digest length:sizeof(digest)] base64EncodedStringWithOptions:0];
    b64 = [b64 stringByReplacingOccurrencesOfString:@"+" withString:@"-"];
    b64 = [b64 stringByReplacingOccurrencesOfString:@"/" withString:@"_"];
    return [b64 stringByReplacingOccurrencesOfString:@"=" withString:@""];
}

// ---------------------------------------------------------------------------
// One-shot loopback web server
// ---------------------------------------------------------------------------

@interface GoogleOAuthSession : NSObject
@property (nonatomic, copy) NSString *clientID, *secret, *state, *verifier, *redirectURI;
@property (nonatomic, copy) void (^completion)(NSDictionary *, NSError *);
@end

@implementation GoogleOAuthSession
{
    int _fd;
    dispatch_source_t _source;
    dispatch_queue_t _queue;
    BOOL _finished;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        _fd = -1;
        _queue = dispatch_queue_create("local.itsycal.oauth", DISPATCH_QUEUE_SERIAL);
    }
    return self;
}

// Starts listening on 127.0.0.1 at a port the system picks. Returns the port, or 0.
- (int)listen
{
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) return 0;
    int yes = 1;
    setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes));
    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_len = sizeof(addr);
    addr.sin_family = AF_INET;
    addr.sin_port = 0;
    addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);   // this Mac only
    if (bind(fd, (struct sockaddr *)&addr, sizeof(addr)) != 0 || listen(fd, 8) != 0) {
        close(fd);
        return 0;
    }
    socklen_t len = sizeof(addr);
    getsockname(fd, (struct sockaddr *)&addr, &len);
    fcntl(fd, F_SETFL, fcntl(fd, F_GETFL) | O_NONBLOCK);
    _fd = fd;

    _source = dispatch_source_create(DISPATCH_SOURCE_TYPE_READ, (uintptr_t)fd, 0, _queue);
    __weak typeof(self) weakSelf = self;
    dispatch_source_set_event_handler(_source, ^{ [weakSelf acceptConnection]; });
    dispatch_source_set_cancel_handler(_source, ^{ close(fd); });
    dispatch_resume(_source);
    return ntohs(addr.sin_port);
}

- (void)stop
{
    if (_source) { dispatch_source_cancel(_source); _source = nil; }
}

static void SendHTML(int c, int code, NSString *title, NSString *message)
{
    NSString *html = [NSString stringWithFormat:
        @"<!doctype html><html><head><meta charset=\"utf-8\"><title>%@</title>"
        @"<style>body{font:16px -apple-system,Helvetica,sans-serif;margin:4em auto;max-width:32em;padding:0 1em;color:#222}"
        @"@media (prefers-color-scheme:dark){body{background:#1e1e1e;color:#eee}}</style></head>"
        @"<body><h2>%@</h2><p>%@</p></body></html>", title, title, message];
    NSData *body = [html dataUsingEncoding:NSUTF8StringEncoding];
    NSString *head = [NSString stringWithFormat:
        @"HTTP/1.1 %d %@\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: %lu\r\n"
        @"Cache-Control: no-store\r\nConnection: close\r\n\r\n",
        code, code == 200 ? @"OK" : @"Not Found", (unsigned long)body.length];
    NSMutableData *out = [[head dataUsingEncoding:NSUTF8StringEncoding] mutableCopy];
    [out appendData:body];
    const uint8_t *p = out.bytes;
    size_t left = out.length;
    while (left > 0) {
        ssize_t n = send(c, p, left, 0);
        if (n <= 0) break;
        p += n; left -= (size_t)n;
    }
}

- (void)acceptConnection
{
    int c = accept(_fd, NULL, NULL);
    if (c < 0) return;
    fcntl(c, F_SETFL, fcntl(c, F_GETFL) & ~O_NONBLOCK);
    int yes = 1;
    setsockopt(c, SOL_SOCKET, SO_NOSIGPIPE, &yes, sizeof(yes));
    struct timeval tv = { .tv_sec = 5, .tv_usec = 0 };
    setsockopt(c, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));

    NSMutableData *buf = [NSMutableData new];
    uint8_t chunk[2048];
    while (buf.length < 16384) {
        ssize_t n = recv(c, chunk, sizeof(chunk), 0);
        if (n <= 0) break;
        [buf appendBytes:chunk length:(NSUInteger)n];
        NSString *sofar = [[NSString alloc] initWithData:buf encoding:NSISOLatin1StringEncoding];
        if ([sofar containsString:@"\r\n\r\n"]) break;
    }
    NSString *request = [[NSString alloc] initWithData:buf encoding:NSISOLatin1StringEncoding] ?: @"";
    NSString *firstLine = [request componentsSeparatedByString:@"\r\n"].firstObject ?: @"";
    NSArray *parts = [firstLine componentsSeparatedByString:@" "];
    NSString *target = parts.count >= 2 ? parts[1] : @"";
    NSURLComponents *comps = [NSURLComponents componentsWithString:[@"http://127.0.0.1" stringByAppendingString:target]];
    NSMutableDictionary *q = [NSMutableDictionary new];
    for (NSURLQueryItem *item in comps.queryItems) if (item.value) q[item.name] = item.value;

    if (_finished || (!q[@"code"] && !q[@"error"])) {
        // Browser extras (favicon etc.) or a second visit.
        SendHTML(c, 404, @"Itsycal", @"Nothing here.");
        close(c);
        return;
    }
    if (![q[@"state"] isEqualToString:self.state]) {
        SendHTML(c, 200, @"Sign-in didn't match", @"This reply doesn't belong to the sign-in Itsycal started. Close this tab and try again from Itsycal's settings.");
        close(c);
        return;
    }
    _finished = YES;
    if (q[@"error"]) {
        SendHTML(c, 200, @"Sign-in cancelled", @"Itsycal wasn't given access. You can close this tab.");
        close(c);
        [self stop];
        NSString *msg = [q[@"error"] isEqualToString:@"access_denied"]
            ? @"Access wasn't allowed on Google's page."
            : [NSString stringWithFormat:@"Google reported: %@", q[@"error"]];
        [self finishWithResult:nil error:OAuthError(1, msg)];
        return;
    }
    SendHTML(c, 200, @"Signed in", @"You can close this tab and go back to Itsycal.");
    close(c);
    [self stop];

    NSError *error = nil;
    NSDictionary *result = [self exchangeCode:q[@"code"] error:&error];
    [self finishWithResult:result error:error];
}

- (NSDictionary *)exchangeCode:(NSString *)code error:(NSError **)error
{
    NSMutableURLRequest *req = [RemoteHTTP formPost:[NSURL URLWithString:kTokenURL] fields:@{
        @"code": code,
        @"client_id": self.clientID,
        @"client_secret": self.secret,
        @"redirect_uri": self.redirectURI,
        @"grant_type": @"authorization_code",
        @"code_verifier": self.verifier,
    }];
    NSInteger status = 0;
    NSData *data = [RemoteHTTP send:req status:&status error:error];
    if (!data) return nil;
    NSDictionary *json = [NSJSONSerialization JSONObjectWithData:data options:0 error:NULL];
    if (status != 200 || ![json isKindOfClass:[NSDictionary class]] || !json[@"access_token"]) {
        NSString *why = [json isKindOfClass:[NSDictionary class]] ? (json[@"error_description"] ?: json[@"error"]) : nil;
        if (error) *error = OAuthError(status, [NSString stringWithFormat:@"Google didn't accept the sign-in (%@). Check the client ID and secret in Itsycal's settings.", why ?: @(status)]);
        return nil;
    }
    if (![json[@"refresh_token"] isKindOfClass:[NSString class]]) {
        if (error) *error = OAuthError(2, @"Google didn't send a long-term sign-in token. Remove Itsycal at myaccount.google.com/permissions and add the account again.");
        return nil;
    }
    NSString *email = nil;
    if ([json[@"id_token"] isKindOfClass:[NSString class]]) {
        NSDictionary *claims = [[RemoteJS shared] call:@"jwtPayload" args:@[json[@"id_token"]] error:NULL];
        if ([claims isKindOfClass:[NSDictionary class]] && [claims[@"email"] isKindOfClass:[NSString class]]) {
            email = [claims[@"email"] lowercaseString];
        }
    }
    if (!email) {
        if (error) *error = OAuthError(3, @"Google didn't say which account signed in.");
        return nil;
    }
    NSTimeInterval expiresIn = [json[@"expires_in"] doubleValue] ?: 3600;
    return @{@"refresh_token": json[@"refresh_token"],
             @"access_token": json[@"access_token"],
             @"expires_at": [NSDate dateWithTimeIntervalSinceNow:expiresIn],
             @"email": email};
}

- (void)finishWithResult:(NSDictionary *)result error:(NSError *)error
{
    void (^completion)(NSDictionary *, NSError *) = self.completion;
    self.completion = nil;
    if (!completion) return;
    dispatch_async(dispatch_get_main_queue(), ^{ completion(result, error); });
}

- (void)cancelWithError:(NSError *)error
{
    dispatch_async(_queue, ^{
        if (self->_finished) return;
        self->_finished = YES;
        [self stop];
        [self finishWithResult:nil error:error];
    });
}

@end

// ---------------------------------------------------------------------------

@implementation GoogleOAuth

static GoogleOAuthSession *gSession;

+ (void)signInWithClientID:(NSString *)clientID secret:(NSString *)secret loginHint:(NSString *)loginHint
                completion:(void (^)(NSDictionary *, NSError *))completion
{
    [self cancelSignIn];
    GoogleOAuthSession *s = [GoogleOAuthSession new];
    s.clientID = clientID;
    s.secret = secret;
    s.state = RandomURLSafeString(24);
    s.verifier = RandomURLSafeString(48);   // 64 characters
    __weak GoogleOAuthSession *weakS = s;
    s.completion = ^(NSDictionary *result, NSError *error) {
        if (gSession == weakS) gSession = nil;
        completion(result, error);
    };
    int port = [s listen];
    if (port == 0) {
        completion(nil, OAuthError(4, @"Itsycal couldn't open its one-time sign-in page on this Mac."));
        return;
    }
    s.redirectURI = [NSString stringWithFormat:@"http://127.0.0.1:%d/", port];
    gSession = s;

    NSURLComponents *url = [NSURLComponents componentsWithString:kAuthURL];
    NSMutableArray *items = [@[
        [NSURLQueryItem queryItemWithName:@"client_id" value:clientID],
        [NSURLQueryItem queryItemWithName:@"redirect_uri" value:s.redirectURI],
        [NSURLQueryItem queryItemWithName:@"response_type" value:@"code"],
        [NSURLQueryItem queryItemWithName:@"scope" value:kScopes],
        [NSURLQueryItem queryItemWithName:@"state" value:s.state],
        [NSURLQueryItem queryItemWithName:@"code_challenge" value:PKCEChallenge(s.verifier)],
        [NSURLQueryItem queryItemWithName:@"code_challenge_method" value:@"S256"],
        [NSURLQueryItem queryItemWithName:@"access_type" value:@"offline"],
        // Always show the account chooser (personal vs work) and the consent
        // screen, so Google always sends a long-term token.
        [NSURLQueryItem queryItemWithName:@"prompt" value:@"select_account consent"],
    ] mutableCopy];
    if (loginHint.length) [items addObject:[NSURLQueryItem queryItemWithName:@"login_hint" value:loginHint]];
    url.queryItems = items;
    // NSURLComponents leaves "+" alone in queries; Google would read it as a space.
    url.percentEncodedQuery = [url.percentEncodedQuery stringByReplacingOccurrencesOfString:@"+" withString:@"%2B"];
    [[NSWorkspace sharedWorkspace] openURL:url.URL];

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(kSignInTimeout * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        GoogleOAuthSession *strong = weakS;
        if (strong) [strong cancelWithError:OAuthError(5, @"Sign-in timed out. Try again.")];
    });
}

+ (void)cancelSignIn
{
    GoogleOAuthSession *s = gSession;
    gSession = nil;
    [s cancelWithError:OAuthError(NSUserCancelledError, @"Sign-in cancelled.")];
}

+ (NSDictionary *)refreshWithClientID:(NSString *)clientID secret:(NSString *)secret
                         refreshToken:(NSString *)refreshToken error:(NSError **)error
{
    NSMutableURLRequest *req = [RemoteHTTP formPost:[NSURL URLWithString:kTokenURL] fields:@{
        @"client_id": clientID,
        @"client_secret": secret,
        @"refresh_token": refreshToken,
        @"grant_type": @"refresh_token",
    }];
    NSInteger status = 0;
    NSData *data = [RemoteHTTP send:req status:&status error:error];
    if (!data) return nil;
    NSDictionary *json = [NSJSONSerialization JSONObjectWithData:data options:0 error:NULL];
    if (status == 200 && [json isKindOfClass:[NSDictionary class]] && [json[@"access_token"] isKindOfClass:[NSString class]]) {
        NSTimeInterval expiresIn = [json[@"expires_in"] doubleValue] ?: 3600;
        return @{@"access_token": json[@"access_token"],
                 @"expires_at": [NSDate dateWithTimeIntervalSinceNow:expiresIn]};
    }
    NSString *code = [json isKindOfClass:[NSDictionary class]] ? json[@"error"] : nil;
    if ([code isEqualToString:@"invalid_grant"]) {
        if (error) *error = OAuthError(GoogleOAuthErrorSignInAgain, @"Google signed Itsycal out of this account. Sign in again.");
    } else if ([code isEqualToString:@"invalid_client"] || [code isEqualToString:@"unauthorized_client"]) {
        if (error) *error = OAuthError(status, @"Google doesn't recognise the client ID or secret in Itsycal's settings.");
    } else {
        if (error) *error = OAuthError(status, [NSString stringWithFormat:@"Couldn't refresh Google sign-in (%@).", code ?: @(status)]);
    }
    return nil;
}

+ (void)revokeToken:(NSString *)token
{
    NSMutableURLRequest *req = [RemoteHTTP formPost:[NSURL URLWithString:kRevokeURL] fields:@{@"token": token}];
    [RemoteHTTP send:req status:NULL error:NULL];
}

@end
