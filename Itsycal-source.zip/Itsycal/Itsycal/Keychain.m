//
//  Keychain.m
//  Itsycal
//

#import "Keychain.h"
#import <Security/Security.h>

static NSString * const kService = @"Itsycal QuickEntry";

@implementation Keychain

+ (NSMutableDictionary *)queryForKey:(NSString *)key
{
    return [@{(__bridge id)kSecClass:       (__bridge id)kSecClassGenericPassword,
              (__bridge id)kSecAttrService: kService,
              (__bridge id)kSecAttrAccount: key} mutableCopy];
}

+ (nullable NSString *)stringForKey:(NSString *)key
{
    NSMutableDictionary *q = [self queryForKey:key];
    q[(__bridge id)kSecReturnData] = @YES;
    q[(__bridge id)kSecMatchLimit] = (__bridge id)kSecMatchLimitOne;
    CFTypeRef result = NULL;
    OSStatus status = SecItemCopyMatching((__bridge CFDictionaryRef)q, &result);
    if (status != errSecSuccess || result == NULL) return nil;
    NSData *data = CFBridgingRelease(result);
    return [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
}

+ (BOOL)setString:(NSString *)value forKey:(NSString *)key
{
    NSData *data = [value dataUsingEncoding:NSUTF8StringEncoding];
    NSMutableDictionary *q = [self queryForKey:key];
    OSStatus status = SecItemUpdate((__bridge CFDictionaryRef)q,
                                    (__bridge CFDictionaryRef)@{(__bridge id)kSecValueData: data});
    if (status == errSecItemNotFound) {
        q[(__bridge id)kSecValueData] = data;
        q[(__bridge id)kSecAttrLabel] = [NSString stringWithFormat:@"%@ (%@)", kService, key];
        status = SecItemAdd((__bridge CFDictionaryRef)q, NULL);
    }
    return status == errSecSuccess;
}

+ (void)removeKey:(NSString *)key
{
    SecItemDelete((__bridge CFDictionaryRef)[self queryForKey:key]);
}

@end
