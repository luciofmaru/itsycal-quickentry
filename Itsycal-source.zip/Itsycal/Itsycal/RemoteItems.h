//
//  RemoteItems.h
//  Itsycal
//
//  Calendars and events from Itsycal's own accounts (Google, CalDAV).
//
//  Itsycal's views were written for EventKit's EKCalendar and EKEvent. These
//  classes answer the same property names the views read (title, color,
//  startDate, location, ...), so remote calendars and events can travel
//  through EventCenter and the agenda alongside EventKit ones. They are NOT
//  EventKit objects: never hand them to EKEventStore. EventCenter sends
//  changes to remote events to RemoteCenter instead (see EventCenter's
//  create/update/delete methods).
//
//  Any EKEvent/EKCalendar property these classes don't implement answers
//  nil/0 instead of crashing (see -forwardInvocation:).
//

#import <Cocoa/Cocoa.h>
#import <EventKit/EventKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface RemoteCalendarItem : NSObject

@property (nonatomic, copy) NSString *calendarIdentifier;  // "remote:<account id>:<calendar path>"
@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *accountID;
@property (nonatomic, copy) NSString *calendarKey;         // calendar path, as used by remote.js
@property (nonatomic, copy, nullable) NSString *accountEmail; // Google accounts
@property (nonatomic, copy) NSString *sourceTitle;          // account name, for menus
@property (nonatomic) NSColor *color;
@property (nonatomic) BOOL allowsContentModifications;

+ (BOOL)isRemote:(nullable id)calendarOrEvent;

@end

@interface RemoteEventItem : NSObject

@property (nonatomic, copy, nullable) NSString *title;
@property (nonatomic, copy, nullable) NSString *location;
@property (nonatomic, copy, nullable) NSString *notes;
@property (nonatomic, copy, nullable) NSURL *URL;
@property (nonatomic) NSDate *startDate;
@property (nonatomic) NSDate *endDate;
@property (nonatomic, getter=isAllDay) BOOL allDay;
@property (nonatomic) RemoteCalendarItem *calendar;
@property (nonatomic, copy, nullable) NSArray<EKRecurrenceRule *> *recurrenceRules;
@property (nonatomic, readonly) BOOL hasRecurrenceRules;
@property (nonatomic, readonly) BOOL hasNotes;
@property (nonatomic, readonly) BOOL hasAttendees;
@property (nonatomic, readonly, nullable) NSArray *attendees;
@property (nonatomic, readonly, nullable) id organizer;
@property (nonatomic, readonly) NSInteger participationStatus;
@property (nonatomic, copy) NSString *eventIdentifier;
@property (nonatomic, readonly) NSString *calendarItemIdentifier;
@property (nonatomic, readonly, nullable) NSTimeZone *timeZone;
@property (nonatomic) BOOL tentative;

// Where the event lives (for edits): calendar resource, UID, and the
// occurrence's RECURRENCE-ID (nil unless part of a repeating event).
@property (nonatomic, copy) NSString *resourceKey;
@property (nonatomic, copy) NSString *uid;
@property (nonatomic, copy, nullable) NSString *recurrenceID;
// Zone the event's start is written in (e.g. "America/Los_Angeles"), or nil.
@property (nonatomic, copy, nullable) NSString *startTimeZoneName;
// Seconds from the start for the first alert, or nil.
@property (nonatomic, nullable) NSNumber *alarmOffset;
// One occurrence of a repeating event.
@property (nonatomic, readonly) BOOL isSeriesOccurrence;

// Web page showing this event's day (Google Calendar), or nil.
@property (nonatomic, readonly, nullable) NSURL *itsyWebURL;

// Builds an event from one occurrence returned by remote.js's expand().
+ (nullable instancetype)eventWithOccurrence:(NSDictionary *)occ calendar:(RemoteCalendarItem *)calendar;

@end

NS_ASSUME_NONNULL_END
