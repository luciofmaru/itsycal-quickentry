//
//  QuickEntryBar.m
//  Itsycal
//

#import "QuickEntryBar.h"
#import "QuickEntryParser.h"
#import "QuickEntryEvent.h"
#import "EventCenter.h"
#import "EventDraft.h"
#import "Sizer.h"

// Text field that brings Itsycal forward when clicked, so typing goes to it
// (Itsycal's window is a non-activating panel).
@interface QuickEntryTextField : NSTextField
@end

@implementation QuickEntryTextField
- (BOOL)becomeFirstResponder
{
    BOOL ok = [super becomeFirstResponder];
    if (ok) [NSApp activateIgnoringOtherApps:YES];
    return ok;
}
@end

@implementation QuickEntryBar
{
    QuickEntryTextField *_field;
    NSTextField *_preview;
    NSStackView *_stack;
    NSTimer *_confirmationTimer;
    BOOL _saving;
}

- (instancetype)initWithFrame:(NSRect)frameRect
{
    self = [super initWithFrame:frameRect];
    if (self) {
        _field = [QuickEntryTextField new];
        _field.bezeled = YES;
        _field.bezelStyle = NSTextFieldRoundedBezel;
        _field.placeholderString = NSLocalizedString(@"New event: Lunch Fri 1pm at Nopa /work", @"");
        _field.toolTip = NSLocalizedString(@"Type an event and press Return to add it.\n⌘Return opens the full New Event form.\nEsc clears.\n\nExamples:\n  Dentist Tue 3:30pm for 45 min\n  Yoga every Tue and Thu 6pm\n  Trip to Boston Oct 20-23\n  Standup weekdays 9:15am until Dec 1 /work", @"");
        _field.delegate = self;
        _field.usesSingleLineMode = YES;
        _field.lineBreakMode = NSLineBreakByTruncatingTail;
        [_field.cell setScrollable:YES];

        _preview = [NSTextField wrappingLabelWithString:@""];
        _preview.selectable = NO;
        _preview.maximumNumberOfLines = 5;
        _preview.hidden = YES;

        _stack = [NSStackView stackViewWithViews:@[_field, _preview]];
        _stack.orientation = NSUserInterfaceLayoutOrientationVertical;
        _stack.alignment = NSLayoutAttributeLeading;
        _stack.spacing = 3;
        _stack.detachesHiddenViews = YES;
        _stack.translatesAutoresizingMaskIntoConstraints = NO;
        [self addSubview:_stack];
        [NSLayoutConstraint activateConstraints:@[
            [_stack.topAnchor constraintEqualToAnchor:self.topAnchor],
            [_stack.bottomAnchor constraintEqualToAnchor:self.bottomAnchor],
            [_stack.leadingAnchor constraintEqualToAnchor:self.leadingAnchor],
            [_stack.trailingAnchor constraintEqualToAnchor:self.trailingAnchor],
            [_field.widthAnchor constraintEqualToAnchor:_stack.widthAnchor],
            [_preview.widthAnchor constraintEqualToAnchor:_stack.widthAnchor constant:-4],
        ]];
        [_preview setContentCompressionResistancePriority:NSLayoutPriorityRequired
                                           forOrientation:NSLayoutConstraintOrientationVertical];

        // Stay exactly as tall as the field (and preview). Without this the bar
        // soaks up spare height when the window should shrink (e.g. after the
        // event list gets shorter), leaving a blank gap above the month.
        // Priority: above the window's "keep my size" (500), below the
        // contents' own resistance to being squashed (750+).
        [_stack setHuggingPriority:NSLayoutPriorityRequired forOrientation:NSLayoutConstraintOrientationVertical];
        NSLayoutConstraint *snug = [self.heightAnchor constraintEqualToConstant:0];
        snug.priority = 600;
        snug.active = YES;

        [self applyFontSize];
        REGISTER_FOR_SIZE_CHANGE;
    }
    return self;
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [_confirmationTimer invalidate];
}

- (void)sizeChanged:(id)sender
{
    [self applyFontSize];
    [self updatePreview];
}

- (void)applyFontSize
{
    _field.font = [NSFont systemFontOfSize:SizePref.fontSize];
    _preview.font = [NSFont systemFontOfSize:SizePref.fontSize - 1];
}

- (void)layout
{
    [super layout];
    // Let the preview wrap to the bar's width.
    CGFloat width = NSWidth(self.bounds) - 4;
    if (width > 0 && _preview.preferredMaxLayoutWidth != width) {
        _preview.preferredMaxLayoutWidth = width;
        [_preview invalidateIntrinsicContentSize];
    }
}

- (void)focus
{
    [self.window makeFirstResponder:_field];
}

#pragma mark - Preview

- (void)showPreviewText:(NSAttributedString *)text
{
    _preview.attributedStringValue = text;
    _preview.hidden = (text.length == 0);
}

- (NSAttributedString *)line:(NSString *)s color:(NSColor *)color bold:(BOOL)bold
{
    CGFloat size = SizePref.fontSize - 1;
    NSFont *font = bold ? [NSFont systemFontOfSize:size weight:NSFontWeightSemibold] : [NSFont systemFontOfSize:size];
    return [[NSAttributedString alloc] initWithString:s attributes:@{NSFontAttributeName: font, NSForegroundColorAttributeName: color}];
}

- (nullable EventDraft *)currentEventWithResult:(QuickEntryResult * _Nullable * _Nullable)resultOut
{
    NSString *text = [_field.stringValue stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if (text.length == 0 || !self.ec) return nil;
    QuickEntryResult *r = [[QuickEntryParser sharedParser] parse:text];
    if (!r) return nil;
    if (resultOut) *resultOut = r;
    NSDate *day = self.selectedDay ? self.selectedDay() : [NSDate new];
    return [QuickEntryEvent draftForResult:r eventCenter:self.ec calendar:self.cal selectedDay:day];
}

- (void)updatePreview
{
    [_confirmationTimer invalidate];
    _confirmationTimer = nil;

    NSString *text = [_field.stringValue stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if (text.length == 0) {
        [self showPreviewText:[NSAttributedString new]];
        return;
    }
    if (_saving) return;

    QuickEntryResult *r = nil;
    EventDraft *event = [self currentEventWithResult:&r];
    if (!event) {
        NSString *msg = self.ec.calendarAccessGranted
            ? NSLocalizedString(@"No calendar you can add events to.", @"")
            : NSLocalizedString(@"Itsycal doesn't have access to your calendars.", @"");
        [self showPreviewText:[self line:msg color:NSColor.systemRedColor bold:NO]];
        return;
    }

    NSMutableAttributedString *s = [NSMutableAttributedString new];
    // Coloured dot for the calendar, then the title.
    [s appendAttributedString:[self line:@"● " color:[event.calendar color] ?: NSColor.secondaryLabelColor bold:NO]];
    if (event.title.length) {
        [s appendAttributedString:[self line:event.title color:NSColor.labelColor bold:YES]];
    } else {
        [s appendAttributedString:[self line:NSLocalizedString(@"Add a title", @"") color:NSColor.systemOrangeColor bold:YES]];
    }

    NSMutableArray<NSString *> *details = [NSMutableArray new];
    [details addObject:[QuickEntryEvent whenStringForDraft:event]];
    if (event.location.length) [details addObject:event.location];
    if (r.repeatSummary) [details addObject:r.repeatSummary];
    [details addObject:[event.calendar title] ?: @""];
    [s appendAttributedString:[self line:[@"\n" stringByAppendingString:[details componentsJoinedByString:@" · "]]
                                   color:NSColor.secondaryLabelColor bold:NO]];
    if (![QuickEntryEvent isCalendarShown:event.calendar inEventCenter:self.ec]) {
        NSString *warn = [NSString stringWithFormat:NSLocalizedString(@"\n%@ is hidden in Itsycal (tick it in Settings to see it here).", @""), [event.calendar title]];
        [s appendAttributedString:[self line:warn color:NSColor.systemOrangeColor bold:NO]];
    }
    if (r.calendarTag && ![QuickEntryEvent calendarForTag:r.calendarTag inCalendars:[QuickEntryEvent writableCalendarsInEventCenter:self.ec]]) {
        NSString *warn = [NSString stringWithFormat:NSLocalizedString(@"\nNo calendar matches /%@; using %@.", @""), r.calendarTag, [event.calendar title]];
        [s appendAttributedString:[self line:warn color:NSColor.systemOrangeColor bold:NO]];
    }
    [self showPreviewText:s];
}

#pragma mark - Saving

- (void)save
{
    if (_saving) return;
    QuickEntryResult *r = nil;
    EventDraft *event = [self currentEventWithResult:&r];
    if (!event || event.title.length == 0) {
        NSBeep();
        [self updatePreview];
        return;
    }
    // Google/CalDAV saves take a moment; keep the text until the server says yes.
    _saving = YES;
    _field.enabled = NO;
    NSString *calTitle = [event.calendar title] ?: @"";
    [self showPreviewText:[self line:[NSString stringWithFormat:NSLocalizedString(@"Adding to %@…", @""), calTitle]
                               color:NSColor.secondaryLabelColor bold:NO]];
    __weak typeof(self) weakSelf = self;
    [self.ec createEventFromDraft:event completion:^(NSError *error) {
        typeof(self) strongSelf = weakSelf;
        if (!strongSelf) return;
        strongSelf->_saving = NO;
        strongSelf->_field.enabled = YES;
        if (error) {
            [strongSelf showPreviewText:[strongSelf line:[NSString stringWithFormat:NSLocalizedString(@"Couldn't add the event: %@", @""), error.localizedDescription]
                                                   color:NSColor.systemRedColor bold:NO]];
            [strongSelf focus];
            return;
        }
        strongSelf->_field.stringValue = @"";
        NSString *done = [NSString stringWithFormat:NSLocalizedString(@"✓ Added “%@” to %@\n%@", @""),
                          event.title, calTitle, [QuickEntryEvent whenStringForDraft:event]];
        [strongSelf showPreviewText:[strongSelf line:done color:NSColor.systemGreenColor bold:NO]];
        strongSelf->_confirmationTimer = [NSTimer scheduledTimerWithTimeInterval:4 repeats:NO block:^(NSTimer *t) {
            typeof(self) s2 = weakSelf;
            if (s2 && s2->_field.stringValue.length == 0) {
                [s2 showPreviewText:[NSAttributedString new]];
            }
        }];
        if (strongSelf.didSaveEvent) strongSelf.didSaveEvent(event.startDate);
        [strongSelf focus];
    }];
}

#pragma mark - NSTextFieldDelegate

- (void)controlTextDidChange:(NSNotification *)obj
{
    [self updatePreview];
}

- (BOOL)control:(NSControl *)control textView:(NSTextView *)textView doCommandBySelector:(SEL)commandSelector
{
    if (commandSelector == @selector(insertNewline:) || commandSelector == @selector(insertLineBreak:)) {
        BOOL command = (NSApp.currentEvent.modifierFlags & NSEventModifierFlagCommand) != 0;
        if (command) {
            NSString *text = _field.stringValue;
            _field.stringValue = @"";
            [self updatePreview];
            if (self.openFullForm) self.openFullForm(text);
        } else {
            [self save];
        }
        return YES;
    }
    if (commandSelector == @selector(cancelOperation:)) {
        if (_field.stringValue.length) {
            _field.stringValue = @"";
            [self updatePreview];
        } else if (self.resignFocus) {
            self.resignFocus();
        }
        return YES;
    }
    return NO;
}

@end
