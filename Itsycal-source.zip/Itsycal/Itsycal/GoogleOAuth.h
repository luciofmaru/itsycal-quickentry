//
//  GoogleOAuth.h
//  Itsycal
//
//  Google sign-in for a "Desktop app" OAuth client, done the way Google
//  recommends for installed apps: the browser opens Google's sign-in page,
//  and Google sends the browser back to a one-time web server Itsycal runs on
//  this Mac only (http://127.0.0.1:<random port>), with PKCE and a random
//  state value. Nothing goes through macOS Internet Accounts.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

extern NSString * const GoogleOAuthErrorDomain;
// Error code when Google refuses the refresh token (revoked or expired):
// the account has to be signed in again.
extern const NSInteger GoogleOAuthErrorSignInAgain;

@interface GoogleOAuth : NSObject

// Opens the browser for sign-in. Completion (main thread) gets
// { refresh_token, access_token, expires_at (NSDate), email } or an error.
// loginHint (optional) preselects an account on Google's page.
+ (void)signInWithClientID:(NSString *)clientID
                    secret:(NSString *)secret
                 loginHint:(nullable NSString *)loginHint
                completion:(void (^)(NSDictionary * _Nullable result, NSError * _Nullable error))completion;

// Stops waiting for a sign-in in progress (completion gets a cancel error).
+ (void)cancelSignIn;

// Blocking (background queue only). Returns { access_token, expires_at }.
+ (nullable NSDictionary *)refreshWithClientID:(NSString *)clientID
                                        secret:(NSString *)secret
                                  refreshToken:(NSString *)refreshToken
                                         error:(NSError * _Nullable * _Nullable)error;

// Revokes a token at Google (best effort, background queue only).
+ (void)revokeToken:(NSString *)token;

@end

NS_ASSUME_NONNULL_END
