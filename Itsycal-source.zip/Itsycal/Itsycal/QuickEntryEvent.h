//
//  QuickEntryEvent.h
//  Itsycal
//
//  Turns a parsed quick-entry result into a ready-to-save EKEvent, using the
//  same defaults as the New Event form (start time, duration, calendar).
//  Shared by the quick-entry bar in the main window and the New Event form.
//

#import <Foundation/Foundation.h>
#import <EventKit/EventKit.h>
#import "QuickEntryParser.h"

@class EventCenter;

NS_ASSUME_NONNULL_BEGIN

@interface QuickEntryEvent : NSObject

// Calendar.app's "Default duration in minutes for new event" (60 if unset).
+ (NSInteger)defaultDurationMinutes;

// Start used when no date/time was typed: the next whole hour if `day` is
// today, otherwise 8 AM on `day`. (Same rule as the New Event form.)
+ (NSDate *)defaultStartForDay:(NSDate *)day calendar:(NSCalendar *)cal;

// Writable calendars, in Itsycal's usual order.
+ (NSArray<EKCalendar *> *)writableCalendarsInEventCenter:(EventCenter *)ec;

// Calendar for a "/tag": exact name match first, then a name that starts with
// the tag; letters/numbers only, ignoring case. nil if none matches.
+ (nullable EKCalendar *)calendarForTag:(NSString *)tag inCalendars:(NSArray<EKCalendar *> *)calendars;

// The calendar quick entry will use: the tagged one, else Itsycal's default
// calendar, else the first writable calendar. nil only if none are writable.
+ (nullable EKCalendar *)calendarForResult:(QuickEntryResult *)r eventCenter:(EventCenter *)ec;

// Fully filled-in event (title, location, dates, repeat, calendar, the
// calendar's default alerts), not yet saved. nil if no writable calendar.
+ (nullable EKEvent *)eventForResult:(QuickEntryResult *)r
                         eventCenter:(EventCenter *)ec
                            calendar:(NSCalendar *)cal
                         selectedDay:(NSDate *)selectedDay;

// One-line description for previews: "Fri, Oct 16, 1:00 – 2:00 PM".
+ (NSString *)whenStringForEvent:(EKEvent *)event;

@end

NS_ASSUME_NONNULL_END
