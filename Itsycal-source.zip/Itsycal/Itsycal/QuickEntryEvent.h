//
//  QuickEntryEvent.h
//  Itsycal
//
//  Turns a parsed quick-entry result into a ready-to-save EventDraft, using
//  the same defaults as the New Event form (start time, duration, calendar).
//  Calendars here are EKCalendar or RemoteCalendarItem (Google, CalDAV);
//  both answer title, color, calendarIdentifier, allowsContentModifications.
//

#import <Foundation/Foundation.h>
#import <EventKit/EventKit.h>
#import "QuickEntryParser.h"
#import "EventDraft.h"

@class EventCenter;

NS_ASSUME_NONNULL_BEGIN

@interface QuickEntryEvent : NSObject

// Calendar.app's "Default duration in minutes for new event" (60 if unset).
+ (NSInteger)defaultDurationMinutes;

// Start used when no date/time was typed: the next whole hour if `day` is
// today, otherwise 8 AM on `day`. (Same rule as the New Event form.)
+ (NSDate *)defaultStartForDay:(NSDate *)day calendar:(NSCalendar *)cal;

// Writable calendars, in Itsycal's usual order.
+ (NSArray *)writableCalendarsInEventCenter:(EventCenter *)ec;

// Calendar for a "/tag": exact name match first, then a name that starts with
// the tag; letters/numbers only, ignoring case. nil if none matches.
+ (nullable id)calendarForTag:(NSString *)tag inCalendars:(NSArray *)calendars;

// Whether a calendar is ticked (shown) in Itsycal's settings.
+ (BOOL)isCalendarShown:(id)calendar inEventCenter:(EventCenter *)ec;

// The calendar quick entry will use: the tagged one; otherwise the default
// calendar if it's shown in Itsycal, else the first shown writable calendar,
// else the default calendar. nil only if none are writable.
+ (nullable id)calendarForResult:(QuickEntryResult *)r eventCenter:(EventCenter *)ec;

// Fully filled-in draft (title, location, dates, repeat, calendar), not yet
// saved. Alerts are left to the calendar's defaults. nil if no writable calendar.
+ (nullable EventDraft *)draftForResult:(QuickEntryResult *)r
                            eventCenter:(EventCenter *)ec
                               calendar:(NSCalendar *)cal
                            selectedDay:(NSDate *)selectedDay;

// One-line description for previews: "Fri, Oct 16, 1:00 – 2:00 PM".
+ (NSString *)whenStringForDraft:(EventDraft *)draft;

@end

NS_ASSUME_NONNULL_END
