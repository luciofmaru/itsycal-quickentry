//
//  QuickEntryParser.h
//  Itsycal
//
//  Natural-language quick entry. Runs quickentry.bundle.js (chrono plus
//  local rules, see QuickEntry/ in the repo root) inside JavaScriptCore.
//  Nothing leaves the Mac.
//

#import <Foundation/Foundation.h>
#import <EventKit/EventKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface QuickEntryResult : NSObject

@property (nonatomic, copy) NSString *title;            // may be empty
@property (nonatomic, copy, nullable) NSString *location;
@property (nonatomic, copy, nullable) NSString *calendarTag; // "work" from "/work"
@property (nonatomic) BOOL hasDate;                     // NO: no date/time found
@property (nonatomic) BOOL allDay;
@property (nonatomic, nullable) NSDate *start;
@property (nonatomic, nullable) NSDate *end;            // nil: use the default duration
@property (nonatomic) NSInteger durationMinutes;        // 0: none given

// Repeat, if one was typed. The simple fields let the form match its
// existing Repeat menu; `rule` is the full rule for anything else.
@property (nonatomic) BOOL repeats;
@property (nonatomic) EKRecurrenceFrequency frequency;
@property (nonatomic) NSInteger interval;
@property (nonatomic, copy) NSArray<NSNumber *> *daysOfWeek; // 1 = Sunday … 7 = Saturday
@property (nonatomic, nullable) NSDate *until;          // last day the event repeats on
@property (nonatomic) NSInteger count;                  // 0: no count
@property (nonatomic, readonly, nullable) EKRecurrenceRule *rule;
@property (nonatomic, readonly, nullable) NSString *repeatSummary; // "Every Tue, Thu"

@end

@interface QuickEntryParser : NSObject

+ (instancetype)sharedParser;

// Returns nil only if the JavaScript bundle failed to load.
- (nullable QuickEntryResult *)parse:(NSString *)text;

@end

NS_ASSUME_NONNULL_END
