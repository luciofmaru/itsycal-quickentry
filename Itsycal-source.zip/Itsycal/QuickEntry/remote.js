// remote.js: CalDAV and iCalendar support for Itsycal's own calendar accounts.
//
// Bundled (with fast-xml-parser and ical.js) into Itsycal/remote.bundle.js and
// run in JavaScriptCore. The app does the networking (NSURLSession) and keeps
// the cache; this file only builds request bodies, reads the server's XML
// replies and turns iCalendar data into a flat list of event occurrences.
//
// Everything here must run on macOS 10.14's JavaScriptCore (Safari 12):
// no regex lookbehind, no URL class, no fetch.

import { XMLParser } from 'fast-xml-parser';
import ICAL from 'ical.js';

// ---------------------------------------------------------------------------
// Request bodies
// ---------------------------------------------------------------------------

const XML_HEAD = '<?xml version="1.0" encoding="utf-8"?>\n';

export function propfindPrincipalBody() {
  return XML_HEAD +
    '<d:propfind xmlns:d="DAV:" xmlns:c="urn:ietf:params:xml:ns:caldav">' +
    '<d:prop><d:current-user-principal/><c:calendar-home-set/><d:resourcetype/></d:prop>' +
    '</d:propfind>';
}

export function propfindHomeBody() {
  return XML_HEAD +
    '<d:propfind xmlns:d="DAV:" xmlns:c="urn:ietf:params:xml:ns:caldav">' +
    '<d:prop><c:calendar-home-set/></d:prop>' +
    '</d:propfind>';
}

export function propfindCalendarsBody() {
  return XML_HEAD +
    '<d:propfind xmlns:d="DAV:" xmlns:c="urn:ietf:params:xml:ns:caldav" ' +
    'xmlns:cs="http://calendarserver.org/ns/" xmlns:ic="http://apple.com/ns/ical/">' +
    '<d:prop>' +
    '<d:resourcetype/><d:displayname/><ic:calendar-color/><cs:getctag/><d:sync-token/>' +
    '<c:supported-calendar-component-set/><d:current-user-privilege-set/>' +
    '</d:prop>' +
    '</d:propfind>';
}

export function propfindCtagBody() {
  return XML_HEAD +
    '<d:propfind xmlns:d="DAV:" xmlns:cs="http://calendarserver.org/ns/">' +
    '<d:prop><cs:getctag/><d:sync-token/></d:prop>' +
    '</d:propfind>';
}

export function propfindEtagsBody() {
  return XML_HEAD +
    '<d:propfind xmlns:d="DAV:">' +
    '<d:prop><d:getetag/><d:resourcetype/></d:prop>' +
    '</d:propfind>';
}

function xmlEscape(s) {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
                  .replace(/"/g, '&quot;');
}

export function multigetBody(hrefs) {
  return XML_HEAD +
    '<c:calendar-multiget xmlns:d="DAV:" xmlns:c="urn:ietf:params:xml:ns:caldav">' +
    '<d:prop><d:getetag/><c:calendar-data/></d:prop>' +
    hrefs.map(h => '<d:href>' + xmlEscape(h) + '</d:href>').join('') +
    '</c:calendar-multiget>';
}

// ---------------------------------------------------------------------------
// URLs (JavaScriptCore has no URL class)
// ---------------------------------------------------------------------------

function splitUrl(url) {
  const m = /^([a-zA-Z][a-zA-Z0-9+.-]*:\/\/[^\/?#]*)([^?#]*)/.exec(url);
  return m ? { origin: m[1], path: m[2] || '/' } : null;
}

export function resolveUrl(base, href) {
  if (!href) return null;
  href = String(href).trim();
  if (/^[a-zA-Z][a-zA-Z0-9+.-]*:/.test(href)) return href;
  const b = splitUrl(base);
  if (!b) return null;
  if (href.charAt(0) === '/') return b.origin + href;
  const dir = b.path.replace(/[^\/]*$/, '');
  return b.origin + dir + href;
}

// Path of a URL or href, percent-decoded where possible, for comparing hrefs
// that different replies may encode differently ("@" vs "%40").
export function hrefKey(urlOrHref) {
  let p = String(urlOrHref || '');
  const s = splitUrl(p);
  if (s) p = s.path;
  try { p = decodeURIComponent(p); } catch (e) { /* keep as is */ }
  return p;
}

function sameCollection(a, b) {
  return hrefKey(a).replace(/\/+$/, '') === hrefKey(b).replace(/\/+$/, '');
}

// ---------------------------------------------------------------------------
// Multistatus parsing
// ---------------------------------------------------------------------------

const parser = new XMLParser({
  ignoreAttributes: false,
  attributeNamePrefix: '@',
  removeNSPrefix: true,
  parseTagValue: false,
  parseAttributeValue: false,
  trimValues: false,
  processEntities: true,
  htmlEntities: true,
  isArray: (name) => ['response', 'propstat', 'href', 'comp', 'privilege'].indexOf(name) >= 0,
});

function text(v) {
  if (v == null) return null;
  if (typeof v === 'string') return v;
  if (typeof v === 'number' || typeof v === 'boolean') return String(v);
  if (Array.isArray(v)) return text(v[0]);
  if (typeof v === 'object' && '#text' in v) return text(v['#text']);
  return null;
}

function trimmed(v) {
  const t = text(v);
  return t == null ? null : t.trim();
}

function childNames(v) {
  if (!v || typeof v !== 'object') return [];
  return Object.keys(v).filter(k => k.charAt(0) !== '@' && k !== '#text');
}

function statusOk(s) {
  const t = trimmed(s);
  return !t || / 2\d\d /.test(t + ' ');
}

// [{ href, ok, props: { name: rawValue } }] with only the props that came
// back with a 2xx propstat status.
export function parseMultistatus(xml) {
  const doc = parser.parse(String(xml || ''));
  const ms = doc && doc.multistatus;
  if (!ms) throw new Error('The server reply was not a WebDAV multistatus.');
  const responses = ms.response || [];
  return responses.map(r => {
    const href = trimmed(r.href);
    const props = {};
    for (const ps of (r.propstat || [])) {
      if (!statusOk(ps.status)) continue;
      const prop = ps.prop || {};
      for (const k of childNames(prop)) props[k] = prop[k];
    }
    return { href, ok: statusOk(r.status), props };
  });
}

function hrefOf(v) {
  if (!v || typeof v !== 'object') return null;
  return trimmed(v.href);
}

// Principal discovery: { principal, home } as absolute URLs (either may be null).
export function principalInfo(xml, requestUrl) {
  let principal = null, home = null;
  for (const r of parseMultistatus(xml)) {
    const p = hrefOf(r.props['current-user-principal']);
    const h = hrefOf(r.props['calendar-home-set']);
    if (p && !principal) principal = resolveUrl(requestUrl, p);
    if (h && !home) home = resolveUrl(requestUrl, h);
  }
  return { principal, home };
}

function normalizeColor(c) {
  c = trimmed(c);
  if (!c) return null;
  const m = /^#?([0-9a-fA-F]{6})([0-9a-fA-F]{2})?$/.exec(c);
  return m ? '#' + m[1].toUpperCase() : null;
}

// Calendars in a calendar home (Depth 1 PROPFIND).
export function calendarList(xml, homeUrl) {
  const out = [];
  for (const r of parseMultistatus(xml)) {
    if (!r.href) continue;
    const types = childNames(r.props.resourcetype);
    if (types.indexOf('calendar') < 0) continue;
    const compSet = r.props['supported-calendar-component-set'];
    let comps = null;
    if (compSet && compSet.comp) {
      comps = compSet.comp.map(c => (c && c['@name']) || '').filter(Boolean).map(s => s.toUpperCase());
    }
    if (comps && comps.length && comps.indexOf('VEVENT') < 0) continue; // task-only lists
    const privs = [];
    const ps = r.props['current-user-privilege-set'];
    if (ps && ps.privilege) for (const p of ps.privilege) privs.push.apply(privs, childNames(p));
    const url = resolveUrl(homeUrl, r.href);
    out.push({
      url,
      key: hrefKey(url),
      name: trimmed(r.props.displayname) || null,
      color: normalizeColor(r.props['calendar-color']),
      ctag: trimmed(r.props.getctag),
      syncToken: trimmed(r.props['sync-token']),
      // Unknown privileges (null) means the server didn't say.
      writable: privs.length ? (privs.indexOf('write') >= 0 || privs.indexOf('write-content') >= 0 || privs.indexOf('all') >= 0) : null,
    });
  }
  return out;
}

// Depth 0 change marker for a calendar: "ctag|sync-token" (either may be empty).
export function changeMarker(xml) {
  for (const r of parseMultistatus(xml)) {
    const c = trimmed(r.props.getctag) || '';
    const s = trimmed(r.props['sync-token']) || '';
    if (c || s) return c + '|' + s;
  }
  return null;
}

// Compare the server's etag listing with what we have cached.
// cached: { hrefKey: etag }. Returns { fetch: [href], removed: [hrefKey], etags: { hrefKey: etag } }.
export function diffEtags(xml, collectionUrl, cached) {
  cached = cached || {};
  const fetch = [], etags = {};
  for (const r of parseMultistatus(xml)) {
    if (!r.href || sameCollection(r.href, collectionUrl)) continue;
    if (childNames(r.props.resourcetype).indexOf('collection') >= 0) continue;
    const key = hrefKey(r.href);
    const etag = trimmed(r.props.getetag) || '';
    etags[key] = etag;
    if (cached[key] !== etag || !etag) fetch.push(r.href);
  }
  const removed = Object.keys(cached).filter(k => !(k in etags));
  return { fetch, removed, etags };
}

// Event resources from a calendar-multiget (or calendar-query) reply.
export function resources(xml) {
  const out = [];
  for (const r of parseMultistatus(xml)) {
    const data = text(r.props['calendar-data']);
    if (!r.href || !data) continue;
    out.push({ href: r.href, key: hrefKey(r.href), etag: trimmed(r.props.getetag) || '', ics: data });
  }
  return out;
}

// ---------------------------------------------------------------------------
// iCalendar: parse and expand
// ---------------------------------------------------------------------------

const MAX_OCCURRENCES_SCANNED = 20000;
const DAY_MS = 86400000;

function registerTimezones(comp) {
  for (const vtz of comp.getAllSubcomponents('vtimezone')) {
    try {
      const tzid = vtz.getFirstPropertyValue('tzid');
      if (tzid && !ICAL.TimezoneService.has(tzid)) ICAL.TimezoneService.register(vtz);
    } catch (e) { /* a broken VTIMEZONE shouldn't stop the event */ }
  }
}

function tzidOfProp(comp, name) {
  const p = comp.getFirstProperty(name);
  return p ? (p.getParameter('tzid') || null) : null;
}

// A time as wall-clock fields plus its zone, for the app to convert:
// tz = "UTC", an Olson name, or null (floating / all-day);
// utc = milliseconds since 1970 when ical.js knows the zone, else null.
function timeOut(t, fallbackTz) {
  let tz = null, utc = null;
  if (!t.isDate) {
    const zone = t.zone;
    if (zone && zone.tzid === 'UTC') tz = 'UTC';
    else tz = t.timezone || (zone && zone.tzid !== 'floating' ? zone.tzid : null) || fallbackTz || null;
    if (zone && zone.tzid !== 'floating') {
      try { utc = t.toUnixTime() * 1000; } catch (e) { utc = null; }
    }
  }
  return { y: t.year, M: t.month, d: t.day, h: t.isDate ? 0 : t.hour, m: t.isDate ? 0 : t.minute,
           s: t.isDate ? 0 : t.second, tz, utc, date: !!t.isDate };
}

// Rough position on the timeline for range checks (the app clips exactly).
function approxMs(t) {
  if (!t.isDate && t.zone && t.zone.tzid !== 'floating') {
    try { return t.toUnixTime() * 1000; } catch (e) { /* fall through */ }
  }
  return Date.UTC(t.year, t.month - 1, t.day, t.isDate ? 0 : t.hour, t.isDate ? 0 : t.minute, t.isDate ? 0 : t.second);
}

// End of an occurrence: ical.js's end if it's after the start; an all-day
// event with no end lasts one day; otherwise a zero-length event.
function endFor(start, end) {
  if (end && end.compare(start) > 0) return end;
  if (start.isDate) {
    const e = start.clone();
    e.day += 1;
    e.normalize();
    return e;
  }
  return start.clone();
}

function isDeclinedBy(comp, selfEmails) {
  if (!selfEmails || !selfEmails.length) return false;
  for (const p of comp.getAllProperties('attendee')) {
    const v = String(p.getFirstValue() || '').toLowerCase().replace(/^mailto:/, '');
    if (selfEmails.indexOf(v) >= 0) {
      return String(p.getParameter('partstat') || '').toUpperCase() === 'DECLINED';
    }
  }
  return false;
}

function rruleSummary(comp) {
  const r = comp.getFirstPropertyValue('rrule');
  if (!r) return null;
  const out = { freq: r.freq || null, interval: r.interval || 1, count: r.count || null, until: null };
  if (r.until) out.until = timeOut(r.until, null);
  return out;
}

function str(comp, name) {
  const v = comp.getFirstPropertyValue(name);
  if (v == null) return null;
  const s = String(v).trim();
  return s.length ? s : null;
}

// Parsed calendar resources, by calendar key and then by resource key.
// Parsing is cached until the etag changes.
const calendars = {};

function parseResource(ics) {
  const comp = new ICAL.Component(ICAL.parse(ics));
  registerTimezones(comp);
  const vevents = comp.getAllSubcomponents('vevent');
  const byUid = {};
  for (const v of vevents) {
    const uid = v.getFirstPropertyValue('uid') || '';
    (byUid[uid] = byUid[uid] || []).push(v);
  }
  const events = [];
  for (const uid of Object.keys(byUid)) {
    const list = byUid[uid];
    const masters = list.filter(v => !v.hasProperty('recurrence-id'));
    const overrides = list.filter(v => v.hasProperty('recurrence-id'));
    if (masters.length) {
      const ev = new ICAL.Event(masters[0], { strictExceptions: true });
      for (const o of overrides) {
        try { ev.relateException(o); } catch (e) { events.push({ ev: new ICAL.Event(o), uid }); }
      }
      events.push({ ev, uid });
    } else {
      // Only single instances of a series (e.g. invited to one occurrence).
      for (const o of overrides) events.push({ ev: new ICAL.Event(o), uid });
    }
  }
  return events;
}

// items: [{ key, etag, ics }]. Replaces the calendar's contents.
// options: { selfEmails: [..] } used to hide events you've declined.
export function setCalendar(calKey, items, options) {
  const old = (calendars[calKey] && calendars[calKey].resources) || {};
  const res = {};
  const errors = [];
  for (const it of (items || [])) {
    const prev = old[it.key];
    if (prev && prev.etag === it.etag && it.etag) { res[it.key] = prev; continue; }
    try {
      res[it.key] = { etag: it.etag, events: parseResource(it.ics) };
    } catch (e) {
      errors.push(it.key + ': ' + (e && e.message));
    }
  }
  const selfEmails = ((options && options.selfEmails) || []).map(s => String(s).toLowerCase());
  calendars[calKey] = { resources: res, selfEmails };
  return { count: Object.keys(res).length, errors };
}

export function removeCalendar(calKey) {
  delete calendars[calKey];
}

function emit(out, calKey, uid, item, start, end, rid, fallbackTz, selfEmails, rrule) {
  const comp = item.component;
  const status = String(comp.getFirstPropertyValue('status') || '').toUpperCase();
  if (status === 'CANCELLED') return;
  if (isDeclinedBy(comp, selfEmails)) return;
  const startTz = tzidOfProp(comp, 'dtstart') || fallbackTz;
  const endTz = tzidOfProp(comp, 'dtend') || startTz;
  out.push({
    cal: calKey,
    uid,
    rid: rid ? rid.toString() : null,
    title: str(comp, 'summary') || '',
    location: str(comp, 'location'),
    notes: str(comp, 'description'),
    url: str(comp, 'url'),
    allDay: !!start.isDate,
    start: timeOut(start, startTz),
    end: timeOut(end, endTz),
    tentative: status === 'TENTATIVE',
    rrule,
  });
}

// Occurrences overlapping [startMs, endMs) for the given calendars.
// Returns an array (the app clips to exact days itself).
export function expand(calKeys, startMs, endMs) {
  const out = [];
  const lo = startMs - DAY_MS, hi = endMs + DAY_MS;
  for (const calKey of calKeys) {
    const cal = calendars[calKey];
    if (!cal) continue;
    for (const rkey of Object.keys(cal.resources)) {
      for (const { ev, uid } of cal.resources[rkey].events) {
        try {
          expandEvent(out, calKey, uid, ev, lo, hi, cal.selfEmails);
        } catch (e) {
          // Skip an event we can't read rather than losing the whole calendar.
        }
      }
    }
  }
  return out;
}

function expandEvent(out, calKey, uid, ev, lo, hi, selfEmails) {
  const master = ev.component;
  const fallbackTz = tzidOfProp(master, 'dtstart');
  const start0 = ev.startDate;
  if (!start0) return;
  if (!ev.isRecurring() || ev.isRecurrenceException()) {
    const end0 = endFor(start0, ev.endDate);
    if (approxMs(end0) < lo || approxMs(start0) >= hi) return;
    const rid = ev.isRecurrenceException() ? ev.recurrenceId : null;
    emit(out, calKey, uid, ev, start0, end0, rid, fallbackTz, selfEmails, null);
    return;
  }
  const rrule = rruleSummary(master);
  const it = ev.iterator();
  // Moved occurrences can land up to a while away from their original slot.
  const stopAt = hi + 60 * DAY_MS;
  let next, n = 0;
  while ((next = it.next()) && n++ < MAX_OCCURRENCES_SCANNED) {
    if (approxMs(next) >= stopAt) break;
    const det = ev.getOccurrenceDetails(next);
    const s = det.startDate, item = det.item;
    const end = endFor(s, det.endDate);
    if (approxMs(end) < lo || approxMs(s) >= hi) continue;
    if (end.compare(s) === 0 && !s.isDate && approxMs(s) < lo) continue;
    emit(out, calKey, uid, item, s, end, det.recurrenceId, fallbackTz, selfEmails, rrule);
  }
}

// ---------------------------------------------------------------------------
// Small helpers for the app
// ---------------------------------------------------------------------------

// Payload of a JWT (Google's id_token) as an object; the token comes straight
// from Google's token endpoint over HTTPS, so it isn't verified here.
export function jwtPayload(jwt) {
  const part = String(jwt || '').split('.')[1];
  if (!part) return null;
  let b64 = part.replace(/-/g, '+').replace(/_/g, '/');
  while (b64.length % 4) b64 += '=';
  const bin = atobPolyfill(b64);
  // UTF-8 decode
  let s = '';
  try { s = decodeURIComponent(bin.split('').map(c => '%' + ('0' + c.charCodeAt(0).toString(16)).slice(-2)).join('')); }
  catch (e) { s = bin; }
  try { return JSON.parse(s); } catch (e) { return null; }
}

function atobPolyfill(b64) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  let out = '', buffer = 0, bits = 0;
  for (let i = 0; i < b64.length; i++) {
    const c = b64.charAt(i);
    if (c === '=') break;
    const v = chars.indexOf(c);
    if (v < 0) continue;
    buffer = (buffer << 6) | v;
    bits += 6;
    if (bits >= 8) {
      bits -= 8;
      out += String.fromCharCode((buffer >> bits) & 0xff);
    }
  }
  return out;
}

// JSON-string entry points (simplest across the JavaScriptCore bridge).
export function call(name, argsJSON) {
  const fns = { propfindPrincipalBody, propfindHomeBody, propfindCalendarsBody, propfindCtagBody,
                propfindEtagsBody, multigetBody, resolveUrl, hrefKey, principalInfo, calendarList,
                changeMarker, diffEtags, resources, setCalendar, removeCalendar, expand, jwtPayload };
  try {
    const fn = fns[name];
    if (!fn) throw new Error('Unknown function ' + name);
    const args = argsJSON ? JSON.parse(argsJSON) : [];
    const result = fn.apply(null, args);
    return JSON.stringify({ ok: true, result: result === undefined ? null : result });
  } catch (e) {
    return JSON.stringify({ ok: false, error: String((e && e.message) || e) });
  }
}
