// remote.js: CalDAV and iCalendar support for Itsycal's own calendar accounts.
//
// Bundled (with fast-xml-parser and ical.js) into Itsycal/remote.bundle.js and
// run in JavaScriptCore. The app does the networking (NSURLSession) and keeps
// the cache; this file only builds request bodies, reads the server's XML
// replies and turns iCalendar data into a flat list of event occurrences.
//
// Everything here must run on macOS 10.14's JavaScriptCore (Safari 12):
// no regex lookbehind, no URL class, no fetch.

import { XMLParser } from 'fast-xml-parser';
import ICAL from 'ical.js';

// ---------------------------------------------------------------------------
// Request bodies
// ---------------------------------------------------------------------------

const XML_HEAD = '<?xml version="1.0" encoding="utf-8"?>\n';

export function propfindPrincipalBody() {
  return XML_HEAD +
    '<d:propfind xmlns:d="DAV:" xmlns:c="urn:ietf:params:xml:ns:caldav">' +
    '<d:prop><d:current-user-principal/><c:calendar-home-set/><d:resourcetype/></d:prop>' +
    '</d:propfind>';
}

export function propfindHomeBody() {
  return XML_HEAD +
    '<d:propfind xmlns:d="DAV:" xmlns:c="urn:ietf:params:xml:ns:caldav">' +
    '<d:prop><c:calendar-home-set/></d:prop>' +
    '</d:propfind>';
}

export function propfindCalendarsBody() {
  return XML_HEAD +
    '<d:propfind xmlns:d="DAV:" xmlns:c="urn:ietf:params:xml:ns:caldav" ' +
    'xmlns:cs="http://calendarserver.org/ns/" xmlns:ic="http://apple.com/ns/ical/">' +
    '<d:prop>' +
    '<d:resourcetype/><d:displayname/><ic:calendar-color/><cs:getctag/><d:sync-token/>' +
    '<c:supported-calendar-component-set/><d:current-user-privilege-set/>' +
    '</d:prop>' +
    '</d:propfind>';
}

export function propfindCtagBody() {
  return XML_HEAD +
    '<d:propfind xmlns:d="DAV:" xmlns:cs="http://calendarserver.org/ns/">' +
    '<d:prop><cs:getctag/><d:sync-token/></d:prop>' +
    '</d:propfind>';
}

export function propfindEtagsBody() {
  return XML_HEAD +
    '<d:propfind xmlns:d="DAV:">' +
    '<d:prop><d:getetag/><d:resourcetype/></d:prop>' +
    '</d:propfind>';
}

function xmlEscape(s) {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
                  .replace(/"/g, '&quot;');
}

// RFC 6578: "what changed since `token`?" (empty token = everything).
export function syncCollectionBody(token) {
  return XML_HEAD +
    '<d:sync-collection xmlns:d="DAV:">' +
    '<d:sync-token>' + xmlEscape(token || '') + '</d:sync-token>' +
    '<d:sync-level>1</d:sync-level>' +
    '<d:prop><d:getetag/></d:prop>' +
    '</d:sync-collection>';
}

export function multigetBody(hrefs) {
  return XML_HEAD +
    '<c:calendar-multiget xmlns:d="DAV:" xmlns:c="urn:ietf:params:xml:ns:caldav">' +
    '<d:prop><d:getetag/><c:calendar-data/></d:prop>' +
    hrefs.map(h => '<d:href>' + xmlEscape(h) + '</d:href>').join('') +
    '</c:calendar-multiget>';
}

// ---------------------------------------------------------------------------
// URLs (JavaScriptCore has no URL class)
// ---------------------------------------------------------------------------

function splitUrl(url) {
  const m = /^([a-zA-Z][a-zA-Z0-9+.-]*:\/\/[^\/?#]*)([^?#]*)/.exec(url);
  return m ? { origin: m[1], path: m[2] || '/' } : null;
}

export function resolveUrl(base, href) {
  if (!href) return null;
  href = String(href).trim();
  if (/^[a-zA-Z][a-zA-Z0-9+.-]*:/.test(href)) return href;
  const b = splitUrl(base);
  if (!b) return null;
  if (href.charAt(0) === '/') return b.origin + href;
  const dir = b.path.replace(/[^\/]*$/, '');
  return b.origin + dir + href;
}

// Path of a URL or href, percent-decoded where possible, for comparing hrefs
// that different replies may encode differently ("@" vs "%40").
export function hrefKey(urlOrHref) {
  let p = String(urlOrHref || '');
  const s = splitUrl(p);
  if (s) p = s.path;
  try { p = decodeURIComponent(p); } catch (e) { /* keep as is */ }
  return p;
}

function sameCollection(a, b) {
  return hrefKey(a).replace(/\/+$/, '') === hrefKey(b).replace(/\/+$/, '');
}

// ---------------------------------------------------------------------------
// Multistatus parsing
// ---------------------------------------------------------------------------

const parser = new XMLParser({
  ignoreAttributes: false,
  attributeNamePrefix: '@',
  removeNSPrefix: true,
  parseTagValue: false,
  parseAttributeValue: false,
  trimValues: false,
  processEntities: true,
  htmlEntities: true,
  isArray: (name) => ['response', 'propstat', 'href', 'comp', 'privilege'].indexOf(name) >= 0,
});

function text(v) {
  if (v == null) return null;
  if (typeof v === 'string') return v;
  if (typeof v === 'number' || typeof v === 'boolean') return String(v);
  if (Array.isArray(v)) return text(v[0]);
  if (typeof v === 'object' && '#text' in v) return text(v['#text']);
  return null;
}

function trimmed(v) {
  const t = text(v);
  return t == null ? null : t.trim();
}

function childNames(v) {
  if (!v || typeof v !== 'object') return [];
  return Object.keys(v).filter(k => k.charAt(0) !== '@' && k !== '#text');
}

function statusOk(s) {
  const t = trimmed(s);
  return !t || / 2\d\d /.test(t + ' ');
}

// [{ href, ok, props: { name: rawValue } }] with only the props that came
// back with a 2xx propstat status.
export function parseMultistatus(xml) {
  const doc = parser.parse(String(xml || ''));
  const ms = doc && doc.multistatus;
  if (!ms) throw new Error('The server reply was not a WebDAV multistatus.');
  const responses = ms.response || [];
  return responses.map(r => {
    const href = trimmed(r.href);
    const props = {};
    for (const ps of (r.propstat || [])) {
      if (!statusOk(ps.status)) continue;
      const prop = ps.prop || {};
      for (const k of childNames(prop)) props[k] = prop[k];
    }
    return { href, ok: statusOk(r.status), props };
  });
}

function hrefOf(v) {
  if (!v || typeof v !== 'object') return null;
  return trimmed(v.href);
}

// Principal discovery: { principal, home } as absolute URLs (either may be null).
export function principalInfo(xml, requestUrl) {
  let principal = null, home = null;
  for (const r of parseMultistatus(xml)) {
    const p = hrefOf(r.props['current-user-principal']);
    const h = hrefOf(r.props['calendar-home-set']);
    if (p && !principal) principal = resolveUrl(requestUrl, p);
    if (h && !home) home = resolveUrl(requestUrl, h);
  }
  return { principal, home };
}

function normalizeColor(c) {
  c = trimmed(c);
  if (!c) return null;
  const m = /^#?([0-9a-fA-F]{6})([0-9a-fA-F]{2})?$/.exec(c);
  return m ? '#' + m[1].toUpperCase() : null;
}

// Calendars in a calendar home (Depth 1 PROPFIND).
export function calendarList(xml, homeUrl) {
  const out = [];
  for (const r of parseMultistatus(xml)) {
    if (!r.href) continue;
    const types = childNames(r.props.resourcetype);
    if (types.indexOf('calendar') < 0) continue;
    const compSet = r.props['supported-calendar-component-set'];
    let comps = null;
    if (compSet && compSet.comp) {
      comps = compSet.comp.map(c => (c && c['@name']) || '').filter(Boolean).map(s => s.toUpperCase());
    }
    if (comps && comps.length && comps.indexOf('VEVENT') < 0) continue; // task-only lists
    const privs = [];
    const ps = r.props['current-user-privilege-set'];
    if (ps && ps.privilege) for (const p of ps.privilege) privs.push.apply(privs, childNames(p));
    const url = resolveUrl(homeUrl, r.href);
    out.push({
      url,
      key: hrefKey(url),
      name: trimmed(r.props.displayname) || null,
      color: normalizeColor(r.props['calendar-color']),
      ctag: trimmed(r.props.getctag),
      syncToken: trimmed(r.props['sync-token']),
      // Unknown privileges (null) means the server didn't say.
      writable: privs.length ? (privs.indexOf('write') >= 0 || privs.indexOf('write-content') >= 0 || privs.indexOf('all') >= 0) : null,
    });
  }
  return out;
}

// Depth 0 change marker for a calendar: "ctag|sync-token" (either may be empty).
export function changeMarker(xml) {
  for (const r of parseMultistatus(xml)) {
    const c = trimmed(r.props.getctag) || '';
    const s = trimmed(r.props['sync-token']) || '';
    if (c || s) return c + '|' + s;
  }
  return null;
}

// Compare the server's etag listing with what we have cached.
// cached: { hrefKey: etag }. Returns { fetch: [href], removed: [hrefKey], etags: { hrefKey: etag } }.
export function diffEtags(xml, collectionUrl, cached) {
  cached = cached || {};
  const fetch = [], etags = {};
  for (const r of parseMultistatus(xml)) {
    if (!r.href || sameCollection(r.href, collectionUrl)) continue;
    if (childNames(r.props.resourcetype).indexOf('collection') >= 0) continue;
    const key = hrefKey(r.href);
    const etag = trimmed(r.props.getetag) || '';
    etags[key] = etag;
    if (cached[key] !== etag || !etag) fetch.push(r.href);
  }
  const removed = Object.keys(cached).filter(k => !(k in etags));
  return { fetch, removed, etags };
}

// Reply to a sync-collection REPORT.
// cached: { hrefKey: etag }. full: the request had an empty token (complete list).
// Returns { fetch: [href], removed: [hrefKey], token, more }.
//   more = the server cut the list short; ask again with the new token.
export function syncChanges(xml, collectionUrl, cached, full) {
  cached = cached || {};
  const doc = parser.parse(String(xml || ''));
  const ms = doc && doc.multistatus;
  if (!ms) throw new Error('The server reply was not a WebDAV multistatus.');
  const token = trimmed(ms['sync-token']);
  const fetch = [], removed = [], seen = {};
  let more = false;
  for (const r of (ms.response || [])) {
    const href = trimmed(r.href);
    if (!href) continue;
    const status = trimmed(r.status) || '';
    if (sameCollection(href, collectionUrl)) {
      if (/ 507 /.test(status + ' ')) more = true;
      continue;
    }
    const key = hrefKey(href);
    if (/ 404 /.test(status + ' ')) {
      if (key in cached) removed.push(key);
      continue;
    }
    let etag = '';
    let isCollection = false;
    for (const ps of (r.propstat || [])) {
      if (!statusOk(ps.status)) continue;
      const prop = ps.prop || {};
      if (prop.getetag != null) etag = trimmed(prop.getetag) || '';
      if (childNames(prop.resourcetype).indexOf('collection') >= 0) isCollection = true;
    }
    if (isCollection) continue;
    seen[key] = true;
    if (!etag || cached[key] !== etag) fetch.push(href);
  }
  if (full && !more) {
    for (const k of Object.keys(cached)) if (!seen[k] && removed.indexOf(k) < 0) removed.push(k);
  }
  return { fetch, removed, token: token || null, more };
}

// Event resources from a calendar-multiget (or calendar-query) reply.
export function resources(xml) {
  const out = [];
  for (const r of parseMultistatus(xml)) {
    const data = text(r.props['calendar-data']);
    if (!r.href || !data) continue;
    out.push({ href: r.href, key: hrefKey(r.href), etag: trimmed(r.props.getetag) || '', ics: data });
  }
  return out;
}

// ---------------------------------------------------------------------------
// iCalendar: parse and expand
// ---------------------------------------------------------------------------

const MAX_OCCURRENCES_SCANNED = 20000;
const DAY_MS = 86400000;

function registerTimezones(comp) {
  for (const vtz of comp.getAllSubcomponents('vtimezone')) {
    try {
      const tzid = vtz.getFirstPropertyValue('tzid');
      if (tzid && !ICAL.TimezoneService.has(tzid)) ICAL.TimezoneService.register(vtz);
    } catch (e) { /* a broken VTIMEZONE shouldn't stop the event */ }
  }
}

function tzidOfProp(comp, name) {
  const p = comp.getFirstProperty(name);
  return p ? (p.getParameter('tzid') || null) : null;
}

// A time as wall-clock fields plus its zone, for the app to convert:
// tz = "UTC", an Olson name, or null (floating / all-day);
// utc = milliseconds since 1970 when ical.js knows the zone, else null.
function timeOut(t, fallbackTz) {
  let tz = null, utc = null;
  if (!t.isDate) {
    const zone = t.zone;
    if (zone && zone.tzid === 'UTC') tz = 'UTC';
    else tz = t.timezone || (zone && zone.tzid !== 'floating' ? zone.tzid : null) || fallbackTz || null;
    if (zone && zone.tzid !== 'floating') {
      try { utc = t.toUnixTime() * 1000; } catch (e) { utc = null; }
    }
  }
  return { y: t.year, M: t.month, d: t.day, h: t.isDate ? 0 : t.hour, m: t.isDate ? 0 : t.minute,
           s: t.isDate ? 0 : t.second, tz, utc, date: !!t.isDate };
}

// Rough position on the timeline for range checks (the app clips exactly).
function approxMs(t) {
  if (!t.isDate && t.zone && t.zone.tzid !== 'floating') {
    try { return t.toUnixTime() * 1000; } catch (e) { /* fall through */ }
  }
  return Date.UTC(t.year, t.month - 1, t.day, t.isDate ? 0 : t.hour, t.isDate ? 0 : t.minute, t.isDate ? 0 : t.second);
}

// End of an occurrence: ical.js's end if it's after the start; an all-day
// event with no end lasts one day; otherwise a zero-length event.
function endFor(start, end) {
  if (end && end.compare(start) > 0) return end;
  if (start.isDate) {
    const e = start.clone();
    e.addDuration(ICAL.Duration.fromData({ days: 1 }));
    return e;
  }
  return start.clone();
}

function isDeclinedBy(comp, selfEmails) {
  if (!selfEmails || !selfEmails.length) return false;
  for (const p of comp.getAllProperties('attendee')) {
    const v = String(p.getFirstValue() || '').toLowerCase().replace(/^mailto:/, '');
    if (selfEmails.indexOf(v) >= 0) {
      return String(p.getParameter('partstat') || '').toUpperCase() === 'DECLINED';
    }
  }
  return false;
}

function rruleSummary(comp) {
  const r = comp.getFirstPropertyValue('rrule');
  if (!r) return null;
  const out = { freq: r.freq || null, interval: r.interval || 1, count: r.count || null, until: null };
  if (r.until) out.until = timeOut(r.until, null);
  const parts = r.parts || {};
  for (const k of ['BYDAY', 'BYMONTHDAY', 'BYMONTH', 'BYSETPOS']) {
    if (parts[k] && parts[k].length) out[k.toLowerCase()] = parts[k].map(String);
  }
  return out;
}

function str(comp, name) {
  const v = comp.getFirstPropertyValue(name);
  if (v == null) return null;
  const s = String(v).trim();
  return s.length ? s : null;
}

// Parsed calendar resources, by calendar key and then by resource key.
// Parsing is cached until the etag changes.
const calendars = {};

function parseResource(ics) {
  const comp = new ICAL.Component(ICAL.parse(ics));
  registerTimezones(comp);
  const vevents = comp.getAllSubcomponents('vevent');
  const byUid = {};
  for (const v of vevents) {
    const uid = v.getFirstPropertyValue('uid') || '';
    (byUid[uid] = byUid[uid] || []).push(v);
  }
  const events = [];
  for (const uid of Object.keys(byUid)) {
    const list = byUid[uid];
    const masters = list.filter(v => !v.hasProperty('recurrence-id'));
    const overrides = list.filter(v => v.hasProperty('recurrence-id'));
    if (masters.length) {
      const ev = new ICAL.Event(masters[0], { strictExceptions: true });
      for (const o of overrides) {
        try { ev.relateException(o); } catch (e) { events.push({ ev: new ICAL.Event(o), uid }); }
      }
      events.push({ ev, uid });
    } else {
      // Only single instances of a series (e.g. invited to one occurrence).
      for (const o of overrides) events.push({ ev: new ICAL.Event(o), uid });
    }
  }
  return events;
}

// items: [{ key, etag, ics }]. Replaces the calendar's contents.
// options: { selfEmails: [..] } used to hide events you've declined.
export function setCalendar(calKey, items, options) {
  const old = (calendars[calKey] && calendars[calKey].resources) || {};
  const res = {};
  const errors = [];
  for (const it of (items || [])) {
    const prev = old[it.key];
    if (prev && prev.etag === it.etag && it.etag) { res[it.key] = prev; continue; }
    try {
      res[it.key] = { etag: it.etag, events: parseResource(it.ics) };
    } catch (e) {
      errors.push(it.key + ': ' + (e && e.message));
    }
  }
  const selfEmails = ((options && options.selfEmails) || []).map(s => String(s).toLowerCase());
  calendars[calKey] = { resources: res, selfEmails };
  return { count: Object.keys(res).length, errors };
}

export function removeCalendar(calKey) {
  delete calendars[calKey];
}

// Seconds from the start for the first alert, or null.
function alarmOffset(comp) {
  for (const a of comp.getAllSubcomponents('valarm')) {
    const p = a.getFirstProperty('trigger');
    if (!p) continue;
    const v = p.getFirstValue();
    if (!v || typeof v.toSeconds !== 'function') continue;   // absolute time
    if (String(p.getParameter('related') || '').toUpperCase() === 'END') continue;
    return v.toSeconds();
  }
  return null;
}

function emit(out, calKey, res, uid, item, start, end, rid, fallbackTz, selfEmails, rrule) {
  const comp = item.component;
  const status = String(comp.getFirstPropertyValue('status') || '').toUpperCase();
  if (status === 'CANCELLED') return;
  if (isDeclinedBy(comp, selfEmails)) return;
  const startTz = tzidOfProp(comp, 'dtstart') || fallbackTz;
  const endTz = tzidOfProp(comp, 'dtend') || startTz;
  out.push({
    cal: calKey,
    res,
    uid,
    rid: rid ? rid.toString() : null,
    title: str(comp, 'summary') || '',
    location: str(comp, 'location'),
    notes: str(comp, 'description'),
    url: str(comp, 'url'),
    allDay: !!start.isDate,
    start: timeOut(start, startTz),
    end: timeOut(end, endTz),
    tentative: status === 'TENTATIVE',
    alarm: alarmOffset(comp),
    rrule,
  });
}

// Occurrences overlapping [startMs, endMs) for the given calendars.
// Returns an array (the app clips to exact days itself).
export function expand(calKeys, startMs, endMs) {
  const out = [];
  const lo = startMs - DAY_MS, hi = endMs + DAY_MS;
  for (const calKey of calKeys) {
    const cal = calendars[calKey];
    if (!cal) continue;
    for (const rkey of Object.keys(cal.resources)) {
      for (const { ev, uid } of cal.resources[rkey].events) {
        try {
          expandEvent(out, calKey, rkey, uid, ev, lo, hi, cal.selfEmails);
        } catch (e) {
          // Skip an event we can't read rather than losing the whole calendar.
        }
      }
    }
  }
  return out;
}

function expandEvent(out, calKey, res, uid, ev, lo, hi, selfEmails) {
  const master = ev.component;
  const fallbackTz = tzidOfProp(master, 'dtstart');
  const start0 = ev.startDate;
  if (!start0) return;
  if (!ev.isRecurring() || ev.isRecurrenceException()) {
    const end0 = endFor(start0, ev.endDate);
    if (approxMs(end0) < lo || approxMs(start0) >= hi) return;
    const rid = ev.isRecurrenceException() ? ev.recurrenceId : null;
    emit(out, calKey, res, uid, ev, start0, end0, rid, fallbackTz, selfEmails, null);
    return;
  }
  const rrule = rruleSummary(master);
  const it = ev.iterator();
  // Moved occurrences can land up to a while away from their original slot.
  const stopAt = hi + 60 * DAY_MS;
  let next, n = 0;
  while ((next = it.next()) && n++ < MAX_OCCURRENCES_SCANNED) {
    if (approxMs(next) >= stopAt) break;
    const det = ev.getOccurrenceDetails(next);
    const s = det.startDate, item = det.item;
    const end = endFor(s, det.endDate);
    if (approxMs(end) < lo || approxMs(s) >= hi) continue;
    if (end.compare(s) === 0 && !s.isDate && approxMs(s) < lo) continue;
    emit(out, calKey, res, uid, item, s, end, det.recurrenceId, fallbackTz, selfEmails, rrule);
  }
}

// ---------------------------------------------------------------------------
// Writing events (create, edit, delete)
// ---------------------------------------------------------------------------
//
// Times from the app are wall-clock fields in a named zone:
//   { y, M, d, h, m, s, tz: "America/Los_Angeles" | "UTC" }   timed
//   { y, M, d, date: true }                                    all-day
// Edits keep everything the app doesn't know about (attendees, video-call
// details, Google's own fields...) and only change what's asked.

const PRODID = '-//Itsycal QuickEntry//EN';

function timeIn(t) {
  if (t.date) return ICAL.Time.fromData({ year: t.y, month: t.M, day: t.d, isDate: true });
  const time = ICAL.Time.fromData({ year: t.y, month: t.M, day: t.d, hour: t.h || 0, minute: t.m || 0, second: t.s || 0 });
  if (t.tz === 'UTC') time.zone = ICAL.Timezone.utcTimezone;
  return time;
}

// Replaces property `name` with a time (adds TZID for zoned times).
function setTime(comp, name, t) {
  comp.removeAllProperties(name);
  const p = comp.addPropertyWithValue(name, timeIn(t));
  if (!t.date && t.tz && t.tz !== 'UTC') p.setParameter('tzid', t.tz);
  return p;
}

function setText(comp, name, value) {
  comp.removeAllProperties(name);
  if (value != null && String(value).trim() !== '') comp.addPropertyWithValue(name, String(value));
}

function nowUTC() {
  const t = ICAL.Time.fromJSDate(new Date(), true);
  t.zone = ICAL.Timezone.utcTimezone;
  return t;
}

function touch(comp, bumpSequence) {
  comp.updatePropertyWithValue('dtstamp', nowUTC());
  comp.updatePropertyWithValue('last-modified', nowUTC());
  if (bumpSequence) {
    const seq = parseInt(comp.getFirstPropertyValue('sequence'), 10) || 0;
    comp.updatePropertyWithValue('sequence', seq + 1);
  }
}

// rule: { freq, interval, byday: ["MO","2TU"], bymonthday: [..], bymonth: [..],
//         bysetpos: [..], count, until: time dict | null }
function recurFrom(rule) {
  const data = { freq: rule.freq, interval: rule.interval || 1 };
  if (rule.byday && rule.byday.length) data.byday = rule.byday;
  if (rule.bymonthday && rule.bymonthday.length) data.bymonthday = rule.bymonthday;
  if (rule.bymonth && rule.bymonth.length) data.bymonth = rule.bymonth;
  if (rule.bysetpos && rule.bysetpos.length) data.bysetpos = rule.bysetpos;
  if (rule.count) data.count = rule.count;
  if (rule.until) data.until = timeIn(rule.until);
  return new ICAL.Recur(data);
}

function setAlarm(comp, seconds) {
  for (const a of comp.getAllSubcomponents('valarm')) comp.removeSubcomponent(a);
  if (seconds == null) return;
  const a = new ICAL.Component('valarm');
  a.addPropertyWithValue('action', 'DISPLAY');
  a.addPropertyWithValue('trigger', ICAL.Duration.fromSeconds(seconds));
  a.addPropertyWithValue('description', 'Reminder');
  comp.addSubcomponent(a);
}

// Applies the plain fields that are present in `f`.
function applyFields(comp, f) {
  if ('title' in f) setText(comp, 'summary', f.title);
  if ('location' in f) setText(comp, 'location', f.location);
  if ('notes' in f) setText(comp, 'description', f.notes);
  if ('url' in f) setText(comp, 'url', f.url);
  if ('alarm' in f) setAlarm(comp, f.alarm);
}

// ---- Time zone definitions (VTIMEZONE) from the system's zone data ----

function offsetMs(dtf, ms) {
  const parts = {};
  for (const p of dtf.formatToParts(new Date(ms))) parts[p.type] = p.value;
  let h = parseInt(parts.hour, 10);
  if (h === 24) h = 0;
  const asUTC = Date.UTC(parseInt(parts.year, 10), parseInt(parts.month, 10) - 1, parseInt(parts.day, 10),
                         h, parseInt(parts.minute, 10), parseInt(parts.second, 10));
  return asUTC - Math.floor(ms / 1000) * 1000;
}

function fmtOffset(ms) {
  const sign = ms < 0 ? '-' : '+';
  const mins = Math.round(Math.abs(ms) / 60000);
  return sign + ('0' + Math.floor(mins / 60)).slice(-2) + ('0' + (mins % 60)).slice(-2);
}

function pad2(n) { return ('0' + n).slice(-2); }

// VTIMEZONE text for an IANA zone, with yearly rules worked out from the
// transitions in `year` (use the year before the event's start).
export function vtimezone(tzid, year) {
  if (!tzid || tzid === 'UTC') return null;
  let dtf;
  try {
    dtf = new Intl.DateTimeFormat('en-US', { timeZone: tzid, hour12: false, hourCycle: 'h23',
      year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' });
  } catch (e) {
    return null;   // unknown zone
  }
  const start = Date.UTC(year, 0, 1), end = Date.UTC(year + 1, 0, 1);
  const transitions = [];
  let prev = offsetMs(dtf, start);
  for (let t = start + DAY_MS; t <= end && transitions.length < 4; t += DAY_MS) {
    const off = offsetMs(dtf, t);
    if (off !== prev) {
      let lo = t - DAY_MS, hi = t;   // offset(lo) = prev, offset(hi) = off
      while (hi - lo > 60000) {
        const mid = lo + Math.floor((hi - lo) / 120000) * 60000;
        if (offsetMs(dtf, mid) === prev) lo = mid; else hi = mid;
      }
      transitions.push({ at: hi, from: prev, to: off });
      prev = off;
    }
  }
  const lines = ['BEGIN:VTIMEZONE', 'TZID:' + tzid];
  if (transitions.length < 2) {
    const off = offsetMs(dtf, start);
    lines.push('BEGIN:STANDARD', 'DTSTART:19700101T000000', 'TZOFFSETFROM:' + fmtOffset(off),
               'TZOFFSETTO:' + fmtOffset(off), 'END:STANDARD');
  } else {
    const days = ['SU', 'MO', 'TU', 'WE', 'TH', 'FR', 'SA'];
    const maxOff = Math.max(transitions[0].to, transitions[1].to);
    for (const tr of transitions.slice(0, 2)) {
      const local = new Date(tr.at + tr.from);   // wall clock just before the change
      const y = local.getUTCFullYear(), mo = local.getUTCMonth() + 1, d = local.getUTCDate();
      const dim = new Date(Date.UTC(y, mo, 0)).getUTCDate();
      const nth = d + 7 > dim ? -1 : Math.ceil(d / 7);
      const kind = tr.to === maxOff ? 'DAYLIGHT' : 'STANDARD';
      lines.push('BEGIN:' + kind,
        'DTSTART:' + y + pad2(mo) + pad2(d) + 'T' + pad2(local.getUTCHours()) + pad2(local.getUTCMinutes()) + '00',
        'RRULE:FREQ=YEARLY;BYMONTH=' + mo + ';BYDAY=' + nth + days[local.getUTCDay()],
        'TZOFFSETFROM:' + fmtOffset(tr.from), 'TZOFFSETTO:' + fmtOffset(tr.to), 'END:' + kind);
    }
  }
  lines.push('END:VTIMEZONE');
  return lines.join('\r\n');
}

function ensureTimezone(vcal, t) {
  if (!t || t.date || !t.tz || t.tz === 'UTC') return;
  for (const z of vcal.getAllSubcomponents('vtimezone')) {
    if (z.getFirstPropertyValue('tzid') === t.tz) return;
  }
  const text = vtimezone(t.tz, t.y - 1);
  if (!text) return;
  const z = new ICAL.Component(ICAL.parse(text));
  vcal.addSubcomponent(z);
  try { if (!ICAL.TimezoneService.has(t.tz)) ICAL.TimezoneService.register(z); } catch (e) { /* ignore */ }
}

function finish(vcal) {
  // CRLF line endings, as the standard wants.
  return vcal.toString().replace(/\r?\n/g, '\r\n') + '\r\n';
}

// New event. f: { uid, title, location, notes, url, start, end, rrule, alarm }
// Returns the iCalendar text.
export function buildEvent(f) {
  const vcal = new ICAL.Component('vcalendar');
  vcal.addPropertyWithValue('prodid', PRODID);
  vcal.addPropertyWithValue('version', '2.0');
  ensureTimezone(vcal, f.start);
  if (f.end && f.end.tz !== f.start.tz) ensureTimezone(vcal, f.end);
  const ev = new ICAL.Component('vevent');
  ev.addPropertyWithValue('uid', f.uid);
  touch(ev, false);
  ev.addPropertyWithValue('created', nowUTC());
  ev.addPropertyWithValue('sequence', 0);
  setTime(ev, 'dtstart', f.start);
  setTime(ev, 'dtend', f.end || f.start);
  applyFields(ev, f);
  if (f.rrule) ev.addPropertyWithValue('rrule', recurFrom(f.rrule));
  vcal.addSubcomponent(ev);
  return finish(vcal);
}

function vevents(vcal, uid) {
  return vcal.getAllSubcomponents('vevent').filter(v => (v.getFirstPropertyValue('uid') || '') === uid);
}

function ridString(v) {
  const r = v.getFirstPropertyValue('recurrence-id');
  return r ? r.toString() : null;
}

function sameDuration(a, b) { return a && b && a.toSeconds() === b.toSeconds(); }

// Shifts a time property in place by `delta` (ICAL.Duration), keeping its TZID.
function shiftProp(p, delta) {
  const vals = p.getValues().map(v => { const c = v.clone(); c.addDuration(delta); return c; });
  if (vals.length === 1) p.setValue(vals[0]); else p.setValues(vals);
}

// Edit an event inside a calendar resource.
//   scope "all":  the whole event (for a repeating event, the series)
//   scope "this": only the occurrence whose RECURRENCE-ID is `rid`
// f: fields to change, plus for time changes:
//   start, end (new times), occStart (the occurrence's current start, used to
//   move a series by the same amount), rrule (object, or null to stop repeating).
// Returns the new iCalendar text.
export function updateEvent(ics, uid, rid, scope, f) {
  const vcal = new ICAL.Component(ICAL.parse(ics));
  registerTimezones(vcal);
  const list = vevents(vcal, uid);
  if (!list.length) throw new Error('The event is no longer on the server.');
  const master = list.find(v => !v.hasProperty('recurrence-id'));
  const isSeries = !!(master && master.hasProperty('rrule'));
  if (f.start) ensureTimezone(vcal, f.start);
  if (f.end) ensureTimezone(vcal, f.end);

  let target;
  if (scope === 'this' && rid) {
    target = list.find(v => ridString(v) === rid);
    if (!target) {
      if (!master) throw new Error('The event is no longer on the server.');
      // New override: a copy of the series event for this one date.
      target = ICAL.Component.fromString(master.toString());
      for (const n of ['rrule', 'rdate', 'exdate']) target.removeAllProperties(n);
      const masterStart = master.getFirstProperty('dtstart');
      const ridTime = ICAL.Time.fromString(rid);
      if (/Z$/.test(rid)) ridTime.zone = ICAL.Timezone.utcTimezone;
      const p = target.addPropertyWithValue('recurrence-id', ridTime);
      const tzid = masterStart && masterStart.getParameter('tzid');
      if (tzid && !ridTime.isDate && !/Z$/.test(rid)) p.setParameter('tzid', tzid);
      // Keep the occurrence's own times unless new ones are given.
      const dur = master.getFirstPropertyValue('dtend')
        ? master.getFirstPropertyValue('dtend').subtractDate(master.getFirstPropertyValue('dtstart'))
        : null;
      target.removeAllProperties('dtstart');
      const sp = target.addPropertyWithValue('dtstart', ridTime.clone());
      if (tzid && !ridTime.isDate && !/Z$/.test(rid)) sp.setParameter('tzid', tzid);
      if (dur) {
        const e = ridTime.clone(); e.addDuration(dur);
        target.removeAllProperties('dtend');
        const ep = target.addPropertyWithValue('dtend', e);
        if (tzid && !e.isDate && !/Z$/.test(rid)) ep.setParameter('tzid', tzid);
      }
      vcal.addSubcomponent(target);
    }
    if (f.start) setTime(target, 'dtstart', f.start);
    if (f.end) { target.removeAllProperties('duration'); setTime(target, 'dtend', f.end); }
    applyFields(target, f);
    touch(target, true);
    return finish(vcal);
  }

  // Whole event / series.
  target = master || list[0];
  if (f.start && isSeries && f.occStart) {
    const oldStart = target.getFirstPropertyValue('dtstart');
    const newStart = timeIn(f.start);
    const occ = timeIn(f.occStart);
    const switchesAllDay = !!oldStart.isDate !== !!newStart.isDate;
    if (switchesAllDay) {
      // All-day <-> timed: restart the series from the new start and drop
      // per-date changes, which can't be carried over.
      setTime(target, 'dtstart', f.start);
      if (f.end) { target.removeAllProperties('duration'); setTime(target, 'dtend', f.end); }
      target.removeAllProperties('exdate');
      for (const o of list) if (o !== target) vcal.removeSubcomponent(o);
    } else {
      // Move the series by however much this occurrence moved.
      const delta = newStart.subtractDate(occ);
      const dur = f.end ? timeIn(f.end).subtractDate(newStart) : null;
      const moved = oldStart.clone(); moved.addDuration(delta);
      // Keep the series in its own zone.
      const startProp = target.getFirstProperty('dtstart');
      const tz = startProp.getParameter('tzid') ||
                 (oldStart.zone && oldStart.zone.tzid === 'UTC' ? 'UTC' : null);
      setTime(target, 'dtstart', { y: moved.year, M: moved.month, d: moved.day, h: moved.hour, m: moved.minute,
                                   s: moved.second, date: moved.isDate, tz });
      if (dur) {
        const e = moved.clone(); e.addDuration(dur);
        target.removeAllProperties('duration');
        setTime(target, 'dtend', { y: e.year, M: e.month, d: e.day, h: e.hour, m: e.minute, s: e.second,
                                   date: e.isDate, tz });
      }
      if (delta.toSeconds() !== 0) {
        for (const p of target.getAllProperties('exdate')) shiftProp(p, delta);
        for (const o of list) {
          if (o === target) continue;
          const rp = o.getFirstProperty('recurrence-id');
          if (rp) shiftProp(rp, delta);
        }
      }
    }
  } else {
    if (f.start) setTime(target, 'dtstart', f.start);
    if (f.end) { target.removeAllProperties('duration'); setTime(target, 'dtend', f.end); }
  }
  if ('rrule' in f) {
    target.removeAllProperties('rrule');
    if (f.rrule) {
      target.addPropertyWithValue('rrule', recurFrom(f.rrule));
    } else {
      // No longer repeating: drop the per-date changes too.
      for (const n of ['rdate', 'exdate']) target.removeAllProperties(n);
      for (const o of list) if (o !== target) vcal.removeSubcomponent(o);
    }
  }
  applyFields(target, f);
  touch(target, true);
  return finish(vcal);
}

// Delete from a calendar resource.
//   scope "all":    the whole event          -> { action: "delete" }
//   scope "this":   one occurrence           -> { action: "put", ics }
//   scope "future": this and later ones      -> { action: "put", ics } or "delete"
// occStartMs: the occurrence's start (ms), used when the zone isn't known.
export function deleteFromEvent(ics, uid, rid, scope, occStartMs) {
  const vcal = new ICAL.Component(ICAL.parse(ics));
  registerTimezones(vcal);
  const list = vevents(vcal, uid);
  const others = vcal.getAllSubcomponents('vevent').filter(v => list.indexOf(v) < 0);
  const master = list.find(v => !v.hasProperty('recurrence-id'));
  const isSeries = !!(master && master.hasProperty('rrule'));

  const removeAll = () => {
    if (!others.length) return { action: 'delete' };
    for (const v of list) vcal.removeSubcomponent(v);
    return { action: 'put', ics: finish(vcal) };
  };

  if (scope === 'all' || !rid || !list.length) return removeAll();

  if (!isSeries) {
    // A lone copy of one occurrence: remove just that.
    const v = list.find(x => ridString(x) === rid);
    if (v) vcal.removeSubcomponent(v);
    if (!vcal.getAllSubcomponents('vevent').length) return { action: 'delete' };
    return { action: 'put', ics: finish(vcal) };
  }

  const ridTime = ICAL.Time.fromString(rid);
  if (/Z$/.test(rid)) ridTime.zone = ICAL.Timezone.utcTimezone;
  const startProp = master.getFirstProperty('dtstart');
  const tzid = startProp.getParameter('tzid');

  if (scope === 'this') {
    for (const v of list) if (ridString(v) === rid) vcal.removeSubcomponent(v);
    const p = master.addPropertyWithValue('exdate', ridTime);
    if (tzid && !ridTime.isDate && !/Z$/.test(rid)) p.setParameter('tzid', tzid);
    touch(master, true);
    return { action: 'put', ics: finish(vcal) };
  }

  // "future": end the series just before this occurrence.
  const first = master.getFirstPropertyValue('dtstart');
  const ridForCompare = ridTime.clone();
  if (tzid && !ridTime.isDate && ICAL.TimezoneService.has(tzid)) ridForCompare.zone = ICAL.TimezoneService.get(tzid);
  if (ridForCompare.compare(first) <= 0) return removeAll();
  const recur = master.getFirstPropertyValue('rrule');
  let until;
  if (first.isDate) {
    until = ridTime.clone(); until.addDuration(ICAL.Duration.fromData({ days: -1 }));
  } else {
    let ms = null;
    if (ridForCompare.zone && ridForCompare.zone.tzid !== 'floating') ms = ridForCompare.toUnixTime() * 1000;
    if (ms == null) ms = occStartMs;
    until = ICAL.Time.fromJSDate(new Date(ms - 1000), true);
    until.zone = ICAL.Timezone.utcTimezone;
  }
  const data = recur.toJSON();
  delete data.count;
  data.until = until;
  master.updatePropertyWithValue('rrule', new ICAL.Recur(Object.assign({}, data, { until })));
  // Drop per-date changes on or after this occurrence.
  for (const v of list) {
    if (v === master) continue;
    const r = v.getFirstPropertyValue('recurrence-id');
    if (r && r.compare(ridForCompare) >= 0) vcal.removeSubcomponent(v);
  }
  touch(master, true);
  return { action: 'put', ics: finish(vcal) };
}

// ---------------------------------------------------------------------------
// Small helpers for the app
// ---------------------------------------------------------------------------

// Payload of a JWT (Google's id_token) as an object; the token comes straight
// from Google's token endpoint over HTTPS, so it isn't verified here.
export function jwtPayload(jwt) {
  const part = String(jwt || '').split('.')[1];
  if (!part) return null;
  let b64 = part.replace(/-/g, '+').replace(/_/g, '/');
  while (b64.length % 4) b64 += '=';
  const bin = atobPolyfill(b64);
  // UTF-8 decode
  let s = '';
  try { s = decodeURIComponent(bin.split('').map(c => '%' + ('0' + c.charCodeAt(0).toString(16)).slice(-2)).join('')); }
  catch (e) { s = bin; }
  try { return JSON.parse(s); } catch (e) { return null; }
}

function atobPolyfill(b64) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  let out = '', buffer = 0, bits = 0;
  for (let i = 0; i < b64.length; i++) {
    const c = b64.charAt(i);
    if (c === '=') break;
    const v = chars.indexOf(c);
    if (v < 0) continue;
    buffer = (buffer << 6) | v;
    bits += 6;
    if (bits >= 8) {
      bits -= 8;
      out += String.fromCharCode((buffer >> bits) & 0xff);
    }
  }
  return out;
}

// JSON-string entry points (simplest across the JavaScriptCore bridge).
export function call(name, argsJSON) {
  const fns = { propfindPrincipalBody, propfindHomeBody, propfindCalendarsBody, propfindCtagBody,
                propfindEtagsBody, multigetBody, syncCollectionBody, syncChanges, resolveUrl, hrefKey, principalInfo, calendarList,
                changeMarker, diffEtags, resources, setCalendar, removeCalendar, expand, jwtPayload,
                vtimezone, buildEvent, updateEvent, deleteFromEvent };
  try {
    const fn = fns[name];
    if (!fn) throw new Error('Unknown function ' + name);
    const args = argsJSON ? JSON.parse(argsJSON) : [];
    const result = fn.apply(null, args);
    return JSON.stringify({ ok: true, result: result === undefined ? null : result });
  } catch (e) {
    return JSON.stringify({ ok: false, error: String((e && e.message) || e) });
  }
}
