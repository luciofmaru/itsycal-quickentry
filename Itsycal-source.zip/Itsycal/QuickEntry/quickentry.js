// quickentry.js
// Natural-language parser for Itsycal's quick-entry field.
//
// chrono (MIT, https://github.com/wanasit/chrono) finds dates and times.
// The rules in this file add what chrono doesn't do on its own:
//   - calendar tags      "/work"
//   - repeats            "every Tuesday", "daily", "every other week until Dec 1"
//   - durations          "for 45 min", "for 1.5 hours", "for 3 days"
//   - locations          "at Nopa", "@ Blue Bottle", "in Paris"
// Everything runs locally; nothing is sent anywhere.
//
// Build: see QuickEntry/README.md. The bundle exposes a global
// `QuickEntry` with parse(text, referenceMillis) -> JSON string.

import * as chrono from 'chrono-node';

const WEEKDAYS = {
  sun: 1, sunday: 1, sundays: 1,
  mon: 2, monday: 2, mondays: 2,
  tue: 3, tues: 3, tuesday: 3, tuesdays: 3,
  wed: 4, weds: 4, wednesday: 4, wednesdays: 4,
  thu: 5, thur: 5, thurs: 5, thursday: 5, thursdays: 5,
  fri: 6, friday: 6, fridays: 6,
  sat: 7, saturday: 7, saturdays: 7,
};
const WEEKDAY_RE = '(?:sun(?:days?)?|mon(?:days?)?|tue(?:s(?:days?)?)?|wed(?:s|nesdays?)?|thu(?:r(?:s(?:days?)?)?)?|fri(?:days?)?|sat(?:urdays?)?)';
const NUM_WORDS = {
  a: 1, an: 1, one: 1, two: 2, three: 3, four: 4, five: 5, six: 6,
  seven: 7, eight: 8, nine: 9, ten: 10, eleven: 11, twelve: 12,
};
const NUM_RE = '(?:\\d+(?:\\.\\d+)?|a|an|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve)';

function num(s) {
  s = s.toLowerCase();
  return NUM_WORDS[s] !== undefined ? NUM_WORDS[s] : parseFloat(s);
}

// ---------------------------------------------------------------------------
// Span bookkeeping: each rule claims a [start, end) range of the original
// text. Claimed ranges are blanked out (replaced by spaces) so later rules
// and chrono never see them, while character indexes stay stable.

class Text {
  constructor(s) {
    this.original = s;
    this.work = s;
    this.claimed = [];
  }
  claim(start, end) {
    this.claimed.push([start, end]);
    this.work = this.work.slice(0, start) + ' '.repeat(end - start) + this.work.slice(end);
  }
  // Run a regex over the working text and claim the first match.
  take(re) {
    re.lastIndex = 0;
    const m = re.exec(this.work);
    if (!m) return null;
    this.claim(m.index, m.index + m[0].length);
    return m;
  }
}

// ---------------------------------------------------------------------------
// Rules

function takeCalendarTag(t) {
  // "/work" or "/Family Shared" is not supported; tag is one word.
  const m = t.take(/(?:^|\s)\/([\p{L}\p{N}_-]+)/u);
  return m ? m[1] : null;
}

function takeRecurrence(t) {
  let rec = null;
  let m;

  // every weekday / weekdays
  if ((m = t.take(/\b(?:every\s+weekday|weekdays|on\s+weekdays)\b/i))) {
    rec = { frequency: 'weekly', interval: 1, daysOfWeek: [2, 3, 4, 5, 6] };
  }
  // every weekend / weekends
  else if ((m = t.take(/\b(?:every\s+weekend|weekends|on\s+weekends)\b/i))) {
    rec = { frequency: 'weekly', interval: 1, daysOfWeek: [1, 7] };
  }
  // every (other) Tuesday (and Thursday, Fri)
  else if ((m = t.take(new RegExp(
      '\\b(?:every|each)\\s+(other\\s+)?(' + WEEKDAY_RE + '(?:\\s*(?:,|and|&|\\+)\\s*' + WEEKDAY_RE + ')*)\\b', 'i')))) {
    const days = m[2].toLowerCase().split(/\s*(?:,|and|&|\+)\s*/)
      .map(d => WEEKDAYS[d]).filter(Boolean);
    rec = { frequency: 'weekly', interval: m[1] ? 2 : 1, daysOfWeek: Array.from(new Set(days)).sort() };
  }
  // every (other | N) day/week/month/year(s)
  else if ((m = t.take(new RegExp(
      '\\bevery\\s+(other\\s+|' + NUM_RE + '\\s+)?(day|week|fortnight|month|year)s?\\b', 'i')))) {
    let interval = 1;
    if (m[1]) interval = /other/i.test(m[1]) ? 2 : Math.max(1, Math.round(num(m[1].trim())));
    let unit = m[2].toLowerCase();
    if (unit === 'fortnight') { unit = 'week'; interval *= 2; }
    rec = { frequency: unit === 'day' ? 'daily' : unit + 'ly', interval };
    if (rec.frequency === 'dayly') rec.frequency = 'daily';
  }
  // daily / weekly / biweekly / fortnightly / monthly / yearly / annually
  else if ((m = t.take(/\b(daily|nightly|weekly|bi-?weekly|fortnightly|monthly|yearly|annually)\b/i))) {
    const w = m[1].toLowerCase().replace('-', '');
    rec = {
      daily: { frequency: 'daily', interval: 1 },
      nightly: { frequency: 'daily', interval: 1 },
      weekly: { frequency: 'weekly', interval: 1 },
      biweekly: { frequency: 'weekly', interval: 2 },
      fortnightly: { frequency: 'weekly', interval: 2 },
      monthly: { frequency: 'monthly', interval: 1 },
      yearly: { frequency: 'yearly', interval: 1 },
      annually: { frequency: 'yearly', interval: 1 },
    }[w];
  }
  if (!rec) return null;

  rec.until = null;      // filled in later (needs chrono / the start date)
  rec.count = null;
  rec.forSpan = null;

  // "N times"
  if ((m = t.take(new RegExp('\\b(?:for\\s+)?(' + NUM_RE + ')\\s+(?:times|occurrences)\\b', 'i')))) {
    rec.count = Math.max(1, Math.round(num(m[1])));
  }
  // "for N weeks/months/days/years" (only meaningful with a repeat)
  else if ((m = t.take(new RegExp('\\bfor\\s+(' + NUM_RE + ')\\s+(day|week|month|year)s?\\b', 'i')))) {
    rec.forSpan = { amount: Math.max(1, Math.round(num(m[1]))), unit: m[2].toLowerCase() };
  }
  // "until Dec 1" / "till" / "through" / "ending Dec 1" -> parse the date part later
  else if ((m = t.take(/\b(?:until|till|til|thru|through|ending(?:\s+on)?)\s+(.+?)(?=\s+(?:at|@|in|for|from)\s|\s*\/|$)/i))) {
    rec.untilText = m[1];
  }
  return rec;
}

function takeDuration(t) {
  // for 1h30m, for 1h 30m
  let m = t.take(/\bfor\s+(\d+)\s*h(?:rs?|ours?)?\s*(\d+)\s*m(?:ins?|inutes?)?\b/i);
  if (m) return { minutes: parseInt(m[1], 10) * 60 + parseInt(m[2], 10) };
  // for half an hour
  m = t.take(/\bfor\s+(?:a\s+)?half\s+(?:an\s+)?hour\b/i);
  if (m) return { minutes: 30 };
  // for an hour and a half
  m = t.take(/\bfor\s+(?:an|one|1)\s+hour\s+and\s+a\s+half\b/i);
  if (m) return { minutes: 90 };
  // for 45 min / for 2 hours / for 1.5h
  m = t.take(new RegExp('\\bfor\\s+(' + NUM_RE + ')\\s*(m|mins?|minutes?|h|hrs?|hours?)\\b', 'i'));
  if (m) {
    const n = num(m[1]);
    return { minutes: Math.round(/^m/i.test(m[2]) ? n : n * 60) };
  }
  // for 3 days (multi-day, without a repeat)
  m = t.take(new RegExp('\\bfor\\s+(' + NUM_RE + ')\\s+days?\\b', 'i'));
  if (m) return { days: Math.max(1, Math.round(num(m[1]))) };
  return null;
}

// Location: text after "at", "@" or "in" (+ capitalised word) that isn't a
// date/time chrono already matched. Runs AFTER chrono's matches are claimed.
function takeLocation(t) {
  // Prefer the last marker so "Drinks at 6 at Zeitgeist" style text still works
  // (the "at 6" is claimed by chrono before we get here).
  let best = null;
  const markers = /(?:^|\s)(@\s*|at\s+|in\s+(?=[\p{Lu}\d]))/giu;
  let m;
  while ((m = markers.exec(t.work))) {
    const from = m.index + m[0].length;
    // location runs until the next claimed (blank) gap of 2+ spaces or the end
    const rest = t.work.slice(from);
    const stop = rest.search(/\s{2,}|$/);
    const value = rest.slice(0, stop).trim();
    if (!value) continue;
    // "in" must start with an uppercase letter or digit (case-sensitive check)
    if (/^in\s/i.test(m[1]) && !/^[\p{Lu}\d]/u.test(value)) continue;
    best = { start: m.index, end: from + stop, value };
  }
  if (!best) return null;
  t.claim(best.start, best.end);
  return best.value.replace(/[,.;]+$/, '');
}

// ---------------------------------------------------------------------------
// Date helpers

function startOfDay(d) { return new Date(d.getFullYear(), d.getMonth(), d.getDate()); }
function addDays(d, n) { const x = new Date(d.getTime()); x.setDate(x.getDate() + n); return x; }
function addUnit(d, unit, n) {
  const x = new Date(d.getTime());
  if (unit === 'day') x.setDate(x.getDate() + n);
  else if (unit === 'week') x.setDate(x.getDate() + 7 * n);
  else if (unit === 'month') x.setMonth(x.getMonth() + n);
  else if (unit === 'year') x.setFullYear(x.getFullYear() + n);
  return x;
}
// Next date (today included) whose weekday (1=Sun..7=Sat) is in `days`.
function nextWeekday(from, days) {
  for (let i = 0; i < 7; i++) {
    const d = addDays(from, i);
    if (days.indexOf(d.getDay() + 1) !== -1) return d;
  }
  return from;
}

// ---------------------------------------------------------------------------

export function parseObject(text, refMillis) {
  const ref = refMillis !== undefined ? new Date(refMillis) : new Date();
  const t = new Text(text || '');
  const out = {
    title: '', location: null, calendar: null, allDay: false,
    start: null, end: null, durationMinutes: null, recurrence: null,
    hasDate: false,
  };

  out.calendar = takeCalendarTag(t);
  const rec = takeRecurrence(t);
  const dur = takeDuration(t);

  // Dates and times.
  const certainty = r => ['day', 'weekday', 'month', 'year', 'hour', 'minute']
    .filter(k => r.start.isCertain(k)).length;
  let results = chrono.parse(t.work, ref, { forwardDate: true });
  // Bare words like "night" in "Pizza night" match with nothing certain
  // about them; treat them as part of the title, not as a date.
  results = results.filter(r => certainty(r) > 0);
  // Most specific match first; ties keep their order in the text.
  results = results.map((r, i) => [r, i])
    .sort((a, b) => certainty(b[0]) - certainty(a[0]) || a[1] - b[1])
    .map(x => x[0]);
  // Skip bare numbers chrono sometimes reads as dates ("Room 5").
  results = results.filter(r => !/^\d{1,2}$/.test(r.text.trim()));
  const dayish = r => r.start.isCertain('day') || r.start.isCertain('weekday') || r.start.isCertain('month');
  // "tonight", "this evening", "noon" carry a time even though chrono marks it implied.
  const timed = r => r.start.isCertain('hour') ||
    /\b(?:tonight|noon|midnight|this\s+(?:morning|afternoon|evening))\b/i.test(r.text);
  // The date and the time can come from two separate matches,
  // e.g. "Lunch Friday with Sam at 1pm".
  let dateR = null, timeR = null;
  const primary = results[0] || null;
  if (primary) {
    if (timed(primary) && !dayish(primary)) {
      timeR = primary;
      dateR = results.find(r => r !== primary && dayish(r) && !timed(r)) || null;
    } else if (dayish(primary) && !timed(primary)) {
      dateR = primary;
      timeR = results.find(r => r !== primary && timed(r) && !dayish(r)) || null;
    } else {
      dateR = timeR = primary;
    }
    for (const r of new Set([dateR, timeR])) if (r) t.claim(r.index, r.index + r.text.length);
  }

  out.location = takeLocation(t);

  // Title: whatever is left, tidied.
  out.title = t.work
    .replace(/\s+/g, ' ')
    .trim()
    .replace(/^(?:on|at|from|@|-|,)\s+/i, '')
    .replace(/\s+(?:on|at|from|starting|@|-|,)$/i, '')
    .replace(/[,;:\s]+$/, '')
    .trim();

  if (rec && rec.daysOfWeek && rec.daysOfWeek.length === 7) {
    rec.frequency = 'daily'; delete rec.daysOfWeek;
  }

  let start = null, end = null, allDay = false;
  const hasTime = !!(timeR && timed(timeR));

  if (primary) {
    const base = (dateR || timeR).start.date();
    if (hasTime) {
      const tt = timeR.start.date();
      start = new Date(base.getFullYear(), base.getMonth(), base.getDate(), tt.getHours(), tt.getMinutes());
      if (timeR.end && timeR.end.isCertain('hour')) {
        // "3-4pm": keep the range's length, anchored on the chosen date.
        end = new Date(start.getTime() + (timeR.end.date() - tt));
        if (end <= start) end = addDays(end, 1);
      }
    } else {
      start = base;
      if (dateR && dateR.end) end = dateR.end.date();
    }
  }

  // A repeat on specific weekdays with no explicit date starts on the next such day.
  if (rec && rec.daysOfWeek && rec.daysOfWeek.length) {
    const explicitDay = !!(dateR && (dateR.start.isCertain('day') || dateR.start.isCertain('weekday')));
    if (!explicitDay) {
      const base = start || ref;
      let day = nextWeekday(startOfDay(ref), rec.daysOfWeek);
      let s = hasTime
        ? new Date(day.getFullYear(), day.getMonth(), day.getDate(), base.getHours(), base.getMinutes())
        : day;
      // Today's slot already passed? Use the next matching day.
      if (hasTime && s < ref) {
        day = nextWeekday(addDays(startOfDay(ref), 1), rec.daysOfWeek);
        s = new Date(day.getFullYear(), day.getMonth(), day.getDate(), base.getHours(), base.getMinutes());
      }
      if (end && start) end = new Date(s.getTime() + (end - start));
      start = s;
    }
  }

  if (start) {
    out.hasDate = true;
    allDay = !hasTime;
    if (allDay) {
      start = startOfDay(start);
      end = end ? startOfDay(end) : null;
      if (dur && dur.days) end = addDays(start, dur.days - 1);
      if (!end) end = start;
    } else {
      if (dur && dur.minutes) {
        end = new Date(start.getTime() + dur.minutes * 60000);
        out.durationMinutes = dur.minutes;
      } else if (dur && dur.days) {
        end = addDays(start, dur.days);
      }
    }
  } else if (dur && dur.minutes) {
    out.durationMinutes = dur.minutes;
  }

  if (rec) {
    if (rec.untilText) {
      const u = chrono.parseDate(rec.untilText, start || ref, { forwardDate: true });
      if (u) rec.until = startOfDay(u).getTime();
      else out.title = (out.title + ' until ' + rec.untilText).trim(); // couldn't read it; keep the words
    }
    if (rec.forSpan) {
      const base = start || ref;
      rec.until = addDays(addUnit(startOfDay(base), rec.forSpan.unit, rec.forSpan.amount), -1).getTime();
    }
    delete rec.untilText;
    delete rec.forSpan;
    out.recurrence = rec;
  }

  out.allDay = allDay;
  out.start = start ? start.getTime() : null;
  out.end = end ? end.getTime() : null;
  return out;
}

export function parse(text, refMillis) {
  return JSON.stringify(parseObject(text, refMillis));
}
