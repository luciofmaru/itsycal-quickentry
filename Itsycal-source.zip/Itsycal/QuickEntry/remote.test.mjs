// Tests for remote.js. Run: node remote.test.mjs
// Optional live test against a CalDAV server (e.g. a local Radicale):
//   CALDAV_URL=http://127.0.0.1:5299/ CALDAV_USER=u CALDAV_PASS=p node remote.test.mjs
import * as R from './remote.js';

let failures = 0, passes = 0;
function eq(name, got, want) {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  if (g === w) { passes++; }
  else { failures++; console.log('FAIL', name, '\n  got ', g, '\n  want', w); }
}
function ok(name, cond, extra) {
  if (cond) passes++; else { failures++; console.log('FAIL', name, extra !== undefined ? JSON.stringify(extra) : ''); }
}

// --- URLs -------------------------------------------------------------------
eq('resolve abs path', R.resolveUrl('https://a.example/caldav/v2/', '/caldav/v2/x%40y/user'), 'https://a.example/caldav/v2/x%40y/user');
eq('resolve relative', R.resolveUrl('https://a.example/cal/home/', 'work/'), 'https://a.example/cal/home/work/');
eq('resolve absolute', R.resolveUrl('https://a.example/', 'https://b.example/x'), 'https://b.example/x');
eq('hrefKey decode', R.hrefKey('https://a.example/caldav/v2/me%40gmail.com/events/'), '/caldav/v2/me@gmail.com/events/');

// --- Google-style XML replies ----------------------------------------------
const principalXml = `<?xml version="1.0" encoding="UTF-8"?>
<D:multistatus xmlns:D="DAV:" xmlns:caldav="urn:ietf:params:xml:ns:caldav">
 <D:response><D:href>/caldav/v2/</D:href>
  <D:propstat><D:status>HTTP/1.1 200 OK</D:status><D:prop>
   <D:current-user-principal><D:href>/caldav/v2/me%40gmail.com/user</D:href></D:current-user-principal>
  </D:prop></D:propstat>
  <D:propstat><D:status>HTTP/1.1 404 Not Found</D:status><D:prop><caldav:calendar-home-set/></D:prop></D:propstat>
 </D:response>
</D:multistatus>`;
eq('principal', R.principalInfo(principalXml, 'https://apidata.googleusercontent.com/caldav/v2/'),
   { principal: 'https://apidata.googleusercontent.com/caldav/v2/me%40gmail.com/user', home: null });

const homeXml = `<?xml version="1.0"?><d:multistatus xmlns:d="DAV:" xmlns:cal="urn:ietf:params:xml:ns:caldav">
<d:response><d:href>/caldav/v2/me%40gmail.com/user</d:href><d:propstat><d:prop>
<cal:calendar-home-set><d:href>/caldav/v2/me%40gmail.com/</d:href></cal:calendar-home-set>
</d:prop><d:status>HTTP/1.1 200 OK</d:status></d:propstat></d:response></d:multistatus>`;
eq('home', R.principalInfo(homeXml, 'https://apidata.googleusercontent.com/caldav/v2/me%40gmail.com/user').home,
   'https://apidata.googleusercontent.com/caldav/v2/me%40gmail.com/');

const calsXml = `<?xml version="1.0" encoding="UTF-8"?>
<D:multistatus xmlns:D="DAV:" xmlns:C="urn:ietf:params:xml:ns:caldav" xmlns:CS="http://calendarserver.org/ns/" xmlns:ICAL="http://apple.com/ns/ical/">
 <D:response><D:href>/caldav/v2/me%40gmail.com/</D:href><D:propstat><D:status>HTTP/1.1 200 OK</D:status><D:prop><D:resourcetype><D:collection/></D:resourcetype></D:prop></D:propstat></D:response>
 <D:response><D:href>/caldav/v2/me%40gmail.com/events/</D:href><D:propstat><D:status>HTTP/1.1 200 OK</D:status><D:prop>
   <D:resourcetype><D:collection/><C:calendar/></D:resourcetype>
   <D:displayname>Mary Lucia &amp; Co</D:displayname>
   <ICAL:calendar-color>#9fe1e7ff</ICAL:calendar-color>
   <CS:getctag>63901234</CS:getctag>
   <C:supported-calendar-component-set><C:comp name="VEVENT"/></C:supported-calendar-component-set>
   <D:current-user-privilege-set><D:privilege><D:read/></D:privilege><D:privilege><D:write/></D:privilege></D:current-user-privilege-set>
 </D:prop></D:propstat></D:response>
 <D:response><D:href>/caldav/v2/family123%40group.calendar.google.com/events/</D:href><D:propstat><D:status>HTTP/1.1 200 OK</D:status><D:prop>
   <D:resourcetype><D:collection/><C:calendar/></D:resourcetype>
 </D:prop></D:propstat>
 <D:propstat><D:status>HTTP/1.1 404 Not Found</D:status><D:prop><D:displayname/></D:prop></D:propstat></D:response>
 <D:response><D:href>/tasks/</D:href><D:propstat><D:status>HTTP/1.1 200 OK</D:status><D:prop>
   <D:resourcetype><D:collection/><C:calendar/></D:resourcetype>
   <C:supported-calendar-component-set><C:comp name="VTODO"/></C:supported-calendar-component-set>
 </D:prop></D:propstat></D:response>
</D:multistatus>`;
const cals = R.calendarList(calsXml, 'https://apidata.googleusercontent.com/caldav/v2/me%40gmail.com/');
eq('calendar count', cals.length, 2);
eq('calendar 1', cals[0], {
  url: 'https://apidata.googleusercontent.com/caldav/v2/me%40gmail.com/events/',
  key: '/caldav/v2/me@gmail.com/events/', name: 'Mary Lucia & Co', color: '#9FE1E7',
  ctag: '63901234', syncToken: null, writable: true });
eq('calendar 2 unnamed', [cals[1].name, cals[1].color, cals[1].writable], [null, null, null]);
eq('change marker', R.changeMarker(calsXml.replace(/<D:response><D:href>\/caldav\/v2\/me%40gmail.com\/<\/D:href>.*?<\/D:response>/s, '')), '63901234|');

const etagXml = `<d:multistatus xmlns:d="DAV:">
<d:response><d:href>/caldav/v2/me%40gmail.com/events/</d:href><d:propstat><d:prop><d:resourcetype><d:collection/></d:resourcetype></d:prop><d:status>HTTP/1.1 200 OK</d:status></d:propstat></d:response>
<d:response><d:href>/caldav/v2/me%40gmail.com/events/a.ics</d:href><d:propstat><d:prop><d:getetag>"1"</d:getetag><d:resourcetype/></d:prop><d:status>HTTP/1.1 200 OK</d:status></d:propstat></d:response>
<d:response><d:href>/caldav/v2/me%40gmail.com/events/b.ics</d:href><d:propstat><d:prop><d:getetag>"2"</d:getetag><d:resourcetype/></d:prop><d:status>HTTP/1.1 200 OK</d:status></d:propstat></d:response>
</d:multistatus>`;
eq('diff etags', R.diffEtags(etagXml, 'https://apidata.googleusercontent.com/caldav/v2/me%40gmail.com/events/',
     { '/caldav/v2/me@gmail.com/events/a.ics': '"1"', '/caldav/v2/me@gmail.com/events/gone.ics': '"9"' }),
   { fetch: ['/caldav/v2/me%40gmail.com/events/b.ics'],
     removed: ['/caldav/v2/me@gmail.com/events/gone.ics'],
     etags: { '/caldav/v2/me@gmail.com/events/a.ics': '"1"', '/caldav/v2/me@gmail.com/events/b.ics': '"2"' } });

ok('multiget body', R.multigetBody(['/x/a&b.ics']).indexOf('<d:href>/x/a&amp;b.ics</d:href>') > 0);

// --- iCalendar --------------------------------------------------------------
const VTZ_LA = `BEGIN:VTIMEZONE
TZID:America/Los_Angeles
X-LIC-LOCATION:America/Los_Angeles
BEGIN:DAYLIGHT
TZOFFSETFROM:-0800
TZOFFSETTO:-0700
TZNAME:PDT
DTSTART:19700308T020000
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU
END:DAYLIGHT
BEGIN:STANDARD
TZOFFSETFROM:-0700
TZOFFSETTO:-0800
TZNAME:PST
DTSTART:19701101T020000
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU
END:STANDARD
END:VTIMEZONE`;
const cal = (body, tz = VTZ_LA) => `BEGIN:VCALENDAR\r\nPRODID:-//Google Inc//Google Calendar 70.9054//EN\r\nVERSION:2.0\r\n${tz}\n${body}\nEND:VCALENDAR\r\n`;

// Weekly Monday 9-10 LA, one date excluded, one moved, one cancelled.
const weekly = cal(`BEGIN:VEVENT
DTSTART;TZID=America/Los_Angeles:20261005T090000
DTEND;TZID=America/Los_Angeles:20261005T100000
RRULE:FREQ=WEEKLY;BYDAY=MO;UNTIL=20261231T235959Z
EXDATE;TZID=America/Los_Angeles:20261019T090000
UID:weekly@google.com
SUMMARY:Standup
LOCATION:Room 1
DESCRIPTION:Join: https://meet.google.com/abc-defg-hij
END:VEVENT
BEGIN:VEVENT
DTSTART;TZID=America/Los_Angeles:20261013T140000
DTEND;TZID=America/Los_Angeles:20261013T150000
RECURRENCE-ID;TZID=America/Los_Angeles:20261012T090000
UID:weekly@google.com
SUMMARY:Standup (moved)
END:VEVENT
BEGIN:VEVENT
DTSTART;TZID=America/Los_Angeles:20261026T090000
DTEND;TZID=America/Los_Angeles:20261026T100000
RECURRENCE-ID;TZID=America/Los_Angeles:20261026T090000
STATUS:CANCELLED
UID:weekly@google.com
SUMMARY:Standup
END:VEVENT`);

const allDay = cal(`BEGIN:VEVENT
DTSTART;VALUE=DATE:20261020
DTEND;VALUE=DATE:20261023
UID:trip@google.com
SUMMARY:Trip to Boston
END:VEVENT`, '');

const declined = cal(`BEGIN:VEVENT
DTSTART:20261014T170000Z
DTEND:20261014T180000Z
UID:declined@google.com
SUMMARY:Declined meeting
ORGANIZER:mailto:boss@example.com
ATTENDEE;PARTSTAT=DECLINED:mailto:Me@Gmail.com
END:VEVENT`, '');

const noTzDef = cal(`BEGIN:VEVENT
DTSTART;TZID=Europe/London:20261015T090000
DTEND;TZID=Europe/London:20261015T093000
UID:london@x
SUMMARY:Call London
END:VEVENT
BEGIN:VEVENT
DTSTART;VALUE=DATE:20261016
UID:noend@x
SUMMARY:Birthday
RRULE:FREQ=YEARLY
END:VEVENT`, '');

const r = R.setCalendar('cal1', [
  { key: 'w', etag: '1', ics: weekly },
  { key: 'a', etag: '1', ics: allDay },
  { key: 'd', etag: '1', ics: declined },
  { key: 'n', etag: '1', ics: noTzDef },
  { key: 'bad', etag: '1', ics: 'BEGIN:VCALENDAR\nthis is not ical' },
], { selfEmails: ['me@gmail.com'] });
eq('setCalendar count', r.count, 4);
eq('setCalendar errors', r.errors.length, 1);

const oct = R.expand(['cal1'], Date.UTC(2026, 9, 1), Date.UTC(2026, 10, 1));
const titles = oct.map(o => o.title + ' ' + o.start.M + '/' + o.start.d).sort();
eq('october occurrences', titles, [
  'Birthday 10/16', 'Call London 10/15',
  'Standup (moved) 10/13', 'Standup 10/5', 'Trip to Boston 10/20',
]);
const standup = oct.find(o => o.title === 'Standup');
eq('standup fields', [standup.start.h, standup.start.tz, standup.end.h, standup.location, standup.rrule.freq, standup.rrule.interval, standup.allDay],
   [9, 'America/Los_Angeles', 10, 'Room 1', 'WEEKLY', 1, false]);
eq('standup utc', standup.start.utc, Date.UTC(2026, 9, 5, 16, 0, 0));
const moved = oct.find(o => o.title === 'Standup (moved)');
eq('moved', [moved.start.d, moved.start.h, moved.start.tz], [13, 14, 'America/Los_Angeles']);
const trip = oct.find(o => o.title === 'Trip to Boston');
eq('all-day', [trip.allDay, trip.start.date, trip.start.tz, trip.end.d], [true, true, null, 23]);
const london = oct.find(o => o.title === 'Call London');
eq('unknown tz kept', [london.start.tz, london.start.h, london.start.utc], ['Europe/London', 9, null]);
const bday = oct.find(o => o.title === 'Birthday');
eq('all-day no end', [bday.end.d, bday.allDay], [17, true]);

// November: Standup until Dec 31 (Mondays) + daylight-saving switch Nov 1.
const nov = R.expand(['cal1'], Date.UTC(2026, 10, 1), Date.UTC(2026, 11, 1));
const novStandups = nov.filter(o => o.title === 'Standup');
eq('november mondays', novStandups.map(o => o.start.d), [2, 9, 16, 23, 30]);
eq('after DST still 9am wall clock, utc 17:00', [novStandups[0].start.h, novStandups[0].start.utc], [9, Date.UTC(2026, 10, 2, 17)]);

// Next year: series ended, birthday continues.
const y27 = R.expand(['cal1'], Date.UTC(2027, 9, 1), Date.UTC(2027, 10, 1)).map(o => o.title);
eq('2027', y27, ['Birthday']);

// Unchanged etag reuses the parse; removing a calendar empties it.
eq('reuse', R.setCalendar('cal1', [{ key: 'a', etag: '1', ics: allDay }]).count, 1);
R.removeCalendar('cal1');
eq('removed', R.expand(['cal1'], 0, Date.UTC(2030, 0, 1)).length, 0);

// Daily event since 2010: still fast and bounded.
const daily = cal(`BEGIN:VEVENT
DTSTART;TZID=America/Los_Angeles:20100101T070000
DTEND;TZID=America/Los_Angeles:20100101T073000
RRULE:FREQ=DAILY
UID:daily@x
SUMMARY:Meds
END:VEVENT`);
R.setCalendar('cal2', [{ key: 'x', etag: '1', ics: daily }]);
let t0 = Date.now();
const dailyOcc = R.expand(['cal2'], Date.UTC(2026, 9, 1), Date.UTC(2026, 10, 1));
const ms = Date.now() - t0;
ok('daily count ~31-33', dailyOcc.length >= 31 && dailyOcc.length <= 33, dailyOcc.length);
ok('daily fast (<1500ms)', ms < 1500, ms);

// JWT
const payload = { email: 'me@gmail.com', name: 'Mary Lucía' };
const b64 = Buffer.from(JSON.stringify(payload)).toString('base64').replace(/=+$/, '').replace(/\+/g, '-').replace(/\//g, '_');
eq('jwt', R.jwtPayload('x.' + b64 + '.sig'), payload);

// call() bridge
eq('call ok', JSON.parse(R.call('hrefKey', JSON.stringify(['/a%40b/']))), { ok: true, result: '/a@b/' });
eq('call error', JSON.parse(R.call('parseNothing', '[]')).ok, false);

// --- sync-collection --------------------------------------------------------
const scXml = `<?xml version="1.0"?><d:multistatus xmlns:d="DAV:">
<d:response><d:href>/caldav/v2/me%40gmail.com/events/a.ics</d:href><d:propstat><d:prop><d:getetag>"2"</d:getetag></d:prop><d:status>HTTP/1.1 200 OK</d:status></d:propstat></d:response>
<d:response><d:href>/caldav/v2/me%40gmail.com/events/gone.ics</d:href><d:status>HTTP/1.1 404 Not Found</d:status></d:response>
<d:response><d:href>/caldav/v2/me%40gmail.com/events/same.ics</d:href><d:propstat><d:prop><d:getetag>"7"</d:getetag></d:prop><d:status>HTTP/1.1 200 OK</d:status></d:propstat></d:response>
<d:sync-token>https://example/sync/42</d:sync-token></d:multistatus>`;
const cachedSC = { '/caldav/v2/me@gmail.com/events/a.ics': '"1"', '/caldav/v2/me@gmail.com/events/gone.ics': '"3"',
                   '/caldav/v2/me@gmail.com/events/same.ics': '"7"', '/caldav/v2/me@gmail.com/events/old.ics': '"4"' };
const COL = 'https://apidata.googleusercontent.com/caldav/v2/me%40gmail.com/events/';
eq('sync incremental', R.syncChanges(scXml, COL, cachedSC, false),
   { fetch: ['/caldav/v2/me%40gmail.com/events/a.ics'], removed: ['/caldav/v2/me@gmail.com/events/gone.ics'], token: 'https://example/sync/42', more: false });
eq('sync full drops unlisted', R.syncChanges(scXml, COL, cachedSC, true).removed,
   ['/caldav/v2/me@gmail.com/events/gone.ics', '/caldav/v2/me@gmail.com/events/old.ics']);
ok('sync body', R.syncCollectionBody('a&b').indexOf('<d:sync-token>a&amp;b</d:sync-token>') > 0);

// --- Writing events ----------------------------------------------------------
const LA = 'America/Los_Angeles';
const T = (y, M, d, h, m, tz = LA) => ({ y, M, d, h, m, s: 0, tz });
const D = (y, M, d) => ({ y, M, d, date: true });
function occ(ics, from, to, key = 'w') {
  R.setCalendar('wcal', [{ key, etag: String(Math.random()), ics }], { selfEmails: [] });
  return R.expand(['wcal'], from, to).sort((a, b) => (a.start.utc || 0) - (b.start.utc || 0) || a.start.d - b.start.d);
}
const OCT = [Date.UTC(2026, 9, 1), Date.UTC(2026, 10, 1)];

// Create: weekly Mon+Wed 9-9:45 LA, 15-minute alert.
let ics = R.buildEvent({ uid: 'new-1@itsycal', title: 'Gym, upper body', location: 'Y', notes: 'Bring water',
  url: 'https://example.org', start: T(2026, 10, 5, 9, 0), end: T(2026, 10, 5, 9, 45), alarm: -900,
  rrule: { freq: 'WEEKLY', interval: 1, byday: ['MO', 'WE'], until: { y: 2026, M: 10, d: 31, h: 6, m: 59, s: 59, tz: 'UTC' } } });
ok('build has VTIMEZONE', /BEGIN:VTIMEZONE\r\nTZID:America\/Los_Angeles/.test(ics), ics);
ok('build CRLF', !/[^\r]\n/.test(ics));
ok('build escapes comma', ics.indexOf('SUMMARY:Gym\\, upper body') > 0);
let o = occ(ics, ...OCT);
eq('built occurrences', o.map(x => x.start.d), [5, 7, 12, 14, 19, 21, 26, 28]);
eq('built fields', [o[0].title, o[0].location, o[0].notes, o[0].url, o[0].alarm, o[0].start.h, o[0].end.m, o[0].start.tz],
   ['Gym, upper body', 'Y', 'Bring water', 'https://example.org', -900, 9, 45, LA]);
eq('built utc', o[0].start.utc, Date.UTC(2026, 9, 5, 16));

// All-day, 3 days.
const tripIcs = R.buildEvent({ uid: 'trip@itsycal', title: 'Trip', start: D(2026, 10, 20), end: D(2026, 10, 23), alarm: null });
o = occ(tripIcs, ...OCT);
eq('all-day built', [o.length, o[0].allDay, o[0].start.d, o[0].end.d], [1, true, 20, 23]);
ok('no alarm', tripIcs.indexOf('VALARM') < 0);

// Edit a single event: new time and title; unknown fields kept.
const single = cal(`BEGIN:VEVENT
UID:one@google.com
DTSTART;TZID=America/Los_Angeles:20261014T100000
DTEND;TZID=America/Los_Angeles:20261014T110000
SUMMARY:Coffee
ATTENDEE;PARTSTAT=ACCEPTED:mailto:friend@example.com
X-GOOGLE-CONFERENCE:https://meet.google.com/abc
SEQUENCE:2
END:VEVENT`);
let edited = R.updateEvent(single, 'one@google.com', null, 'all',
  { title: 'Coffee with Sam', start: T(2026, 10, 15, 14, 30), end: T(2026, 10, 15, 15, 0) });
o = occ(edited, ...OCT);
eq('single edit', [o.length, o[0].title, o[0].start.d, o[0].start.h, o[0].start.m, o[0].end.m], [1, 'Coffee with Sam', 15, 14, 30, 0]);
ok('kept attendee + google field', edited.indexOf('ATTENDEE') > 0 && edited.indexOf('X-GOOGLE-CONFERENCE') > 0);
ok('sequence bumped', /SEQUENCE:3/.test(edited));

// Single -> all-day.
edited = R.updateEvent(single, 'one@google.com', null, 'all', { start: D(2026, 10, 16), end: D(2026, 10, 17) });
o = occ(edited, ...OCT);
eq('to all-day', [o[0].allDay, o[0].start.d, o[0].end.d], [true, 16, 17]);
ok('no TZID on date', !/DTSTART;TZID=America\/Los_Angeles;VALUE=DATE/.test(edited) && /DTSTART;VALUE=DATE:20261016/.test(edited));

// Series edits on the Standup fixture (Mon 9-10 LA, EXDATE 10/19, 10/12 moved to Tue 10/13 2pm, 10/26 cancelled).
// "this": move 10/5 to 11:00-11:30.
edited = R.updateEvent(weekly, 'weekly@google.com', '2026-10-05T09:00:00', 'this',
  { start: T(2026, 10, 5, 11, 0), end: T(2026, 10, 5, 11, 30) });
o = occ(edited, ...OCT);
eq('this-only moved', o.map(x => x.start.d + '@' + x.start.h + ':' + x.start.m), ['5@11:0', '13@14:0']);
eq('this-only rid', o[0].rid, '2026-10-05T09:00:00');
// November untouched.
eq('series rest untouched', occ(edited, Date.UTC(2026, 10, 1), Date.UTC(2026, 10, 10)).map(x => x.start.h), [9, 9]);
// Editing the existing moved override again.
edited = R.updateEvent(weekly, 'weekly@google.com', '2026-10-12T09:00:00', 'this', { title: 'Standup (Tue)' });
o = occ(edited, ...OCT);
eq('existing override edited', o.map(x => x.title), ['Standup', 'Standup (Tue)']);
eq('override still one per date', (edited.match(/RECURRENCE-ID/g) || []).length, 2);

// "all": move the whole series 9:00 -> 9:30 (from the 10/5 occurrence), 45 minutes long.
edited = R.updateEvent(weekly, 'weekly@google.com', '2026-10-05T09:00:00', 'all',
  { start: T(2026, 10, 5, 9, 30), end: T(2026, 10, 5, 10, 15), occStart: T(2026, 10, 5, 9, 0), title: 'Standup v2' });
o = occ(edited, ...OCT);
eq('series moved (exceptions kept)', o.map(x => x.start.d + '@' + x.start.h + ':' + x.start.m + '-' + x.end.h + ':' + x.end.m),
   ['5@9:30-10:15', '13@14:0-15:0']);
eq('series title', o[0].title, 'Standup v2');
eq('series November', occ(edited, Date.UTC(2026, 10, 1), Date.UTC(2026, 10, 10)).map(x => x.start.d + '@' + x.start.h + ':' + x.start.m), ['2@9:30', '9@9:30']);

// Stop repeating.
edited = R.updateEvent(weekly, 'weekly@google.com', '2026-10-05T09:00:00', 'all', { rrule: null });
o = occ(edited, Date.UTC(2026, 9, 1), Date.UTC(2027, 0, 1));
eq('no longer repeats', o.length, 1);

// Change repeat to every 2 weeks.
edited = R.updateEvent(weekly, 'weekly@google.com', '2026-10-05T09:00:00', 'all', { rrule: { freq: 'WEEKLY', interval: 2 } });
eq('every 2 weeks', occ(edited, Date.UTC(2026, 10, 1), Date.UTC(2026, 11, 1)).map(x => x.start.d), [2, 16, 30]);

// Alert set and cleared.
edited = R.updateEvent(single, 'one@google.com', null, 'all', { alarm: -600 });
eq('alarm set', occ(edited, ...OCT)[0].alarm, -600);
edited = R.updateEvent(edited, 'one@google.com', null, 'all', { alarm: null });
eq('alarm cleared', occ(edited, ...OCT)[0].alarm, null);

// Delete.
eq('delete single', R.deleteFromEvent(single, 'one@google.com', null, 'all', 0), { action: 'delete' });
let del = R.deleteFromEvent(weekly, 'weekly@google.com', '2026-10-05T09:00:00', 'this', 0);
eq('delete this: put', del.action, 'put');
eq('delete this', occ(del.ics, ...OCT).map(x => x.start.d), [13]);
del = R.deleteFromEvent(weekly, 'weekly@google.com', '2026-10-12T09:00:00', 'this', 0);
eq('delete moved one', occ(del.ics, ...OCT).map(x => x.start.d), [5]);
del = R.deleteFromEvent(weekly, 'weekly@google.com', '2026-11-09T09:00:00', 'future', Date.UTC(2026, 10, 9, 17));
eq('delete future', occ(del.ics, Date.UTC(2026, 10, 1), Date.UTC(2027, 0, 1)).map(x => x.start.d), [2]);
eq('delete future from first = all', R.deleteFromEvent(weekly, 'weekly@google.com', '2026-10-05T09:00:00', 'future', 0), { action: 'delete' });
// All-day series, future.
const yearly = cal(`BEGIN:VEVENT
UID:bday@x
DTSTART;VALUE=DATE:20200310
DTEND;VALUE=DATE:20200311
RRULE:FREQ=YEARLY
SUMMARY:Birthday
END:VEVENT`, '');
del = R.deleteFromEvent(yearly, 'bday@x', '2027-03-10', 'future', 0);
eq('all-day future', occ(del.ics, Date.UTC(2025, 0, 1), Date.UTC(2029, 0, 1)).map(x => x.start.y), [2025, 2026]);

// --- Optional live test --------------------------------------------------------
if (process.env.CALDAV_URL) {
  const base = process.env.CALDAV_URL;
  const auth = 'Basic ' + Buffer.from(process.env.CALDAV_USER + ':' + process.env.CALDAV_PASS).toString('base64');
  async function dav(method, url, body, depth) {
    const res = await fetch(url, { method, body, headers: { Authorization: auth, Depth: String(depth), 'Content-Type': 'application/xml; charset=utf-8' } });
    return { status: res.status, text: await res.text() };
  }
  let resp = await dav('PROPFIND', base, R.propfindPrincipalBody(), 0);
  let info = R.principalInfo(resp.text, base);
  ok('live principal', resp.status === 207 && info.principal, resp.status);
  let home = info.home;
  if (!home) {
    resp = await dav('PROPFIND', info.principal, R.propfindHomeBody(), 0);
    home = R.principalInfo(resp.text, info.principal).home;
  }
  ok('live home', !!home, home);
  resp = await dav('PROPFIND', home, R.propfindCalendarsBody(), 1);
  const live = R.calendarList(resp.text, home);
  ok('live calendars', live.length >= 1, live);
  const c = live[0];
  resp = await dav('PROPFIND', c.url, R.propfindCtagBody(), 0);
  ok('live marker', !!R.changeMarker(resp.text), resp.text.slice(0, 300));
  resp = await dav('PROPFIND', c.url, R.propfindEtagsBody(), 1);
  const diff = R.diffEtags(resp.text, c.url, {});
  ok('live etags', diff.fetch.length >= 1, diff);
  resp = await dav('REPORT', c.url, R.multigetBody(diff.fetch), 1);
  const items = R.resources(resp.text);
  eq('live multiget count', items.length, diff.fetch.length);
  const set = R.setCalendar('live', items, {});
  eq('live parse errors', set.errors, []);
  const occ = R.expand(['live'], Date.UTC(2026, 9, 1), Date.UTC(2026, 11, 1));
  console.log('live calendars:', live.map(x => [x.name, x.color, x.writable]));
  console.log('live occurrences:', occ.map(o => o.title + ' ' + o.start.M + '/' + o.start.d + ' ' + o.start.h + ':' + o.start.m + ' ' + o.start.tz));
  ok('live occurrences', occ.length >= 1);

  // Write: create, edit (If-Match), delete.
  const uid = 'itsycal-test-' + Date.now();
  const href = c.url.replace(/\/?$/, '/') + uid + '.ics';
  const put = (url, body, headers) => fetch(url, { method: 'PUT', body, headers: Object.assign({ Authorization: auth, 'Content-Type': 'text/calendar; charset=utf-8' }, headers) });
  const created = R.buildEvent({ uid, title: 'Itsycal write test', start: T(2026, 11, 3, 9, 0), end: T(2026, 11, 3, 10, 0),
                                  rrule: { freq: 'DAILY', count: 3 }, alarm: -300 });
  let res = await put(href, created, { 'If-None-Match': '*' });
  ok('live create', res.status === 201 || res.status === 204, res.status);
  const etag1 = res.headers.get('etag');
  const changed = R.updateEvent(created, uid, '2026-11-04T09:00:00', 'this', { start: T(2026, 11, 4, 15, 0), end: T(2026, 11, 4, 16, 0) });
  res = await put(href, changed, etag1 ? { 'If-Match': etag1 } : {});
  ok('live edit', res.status === 201 || res.status === 204, res.status);
  const stale = await put(href, changed, { 'If-Match': '"stale-etag"' });
  eq('live stale edit refused', stale.status, 412);
  resp = await dav('REPORT', c.url, R.multigetBody([href]), 1);
  const back = R.resources(resp.text);
  R.setCalendar('live2', back, {});
  eq('live edited occurrences', R.expand(['live2'], Date.UTC(2026, 10, 1), Date.UTC(2026, 11, 1)).map(o => o.start.d + '@' + o.start.h), ['3@9', '4@15', '5@9']);
  // sync-collection: full, then change + delete show up incrementally.
  let sc = await dav('REPORT', c.url, R.syncCollectionBody(''), 1);
  eq('live sync full status', sc.status, 207);
  const first = R.syncChanges(sc.text, c.url, {}, true);
  ok('live sync token', !!first.token, first);
  const known = {};
  for (const it of R.resources((await dav('REPORT', c.url, R.multigetBody(first.fetch), 1)).text)) known[it.key] = it.etag;
  sc = await dav('REPORT', c.url, R.syncCollectionBody(first.token), 1);
  eq('live sync nothing new', R.syncChanges(sc.text, c.url, known, false).fetch.length, 0);
  const curEtag = known[R.hrefKey(href)];
  const renamed = R.updateEvent(changed, uid, null, 'all', { title: 'Renamed elsewhere' });
  res = await put(href, renamed, curEtag ? { 'If-Match': curEtag } : {});
  ok('live rename', res.status === 201 || res.status === 204, res.status);
  sc = await dav('REPORT', c.url, R.syncCollectionBody(first.token), 1);
  const delta = R.syncChanges(sc.text, c.url, known, false);
  eq('live sync sees change', delta.fetch.map(R.hrefKey), [R.hrefKey(href)]);
  res = await fetch(href, { method: 'DELETE', headers: { Authorization: auth } });
  ok('live delete', res.status === 200 || res.status === 204, res.status);
  sc = await dav('REPORT', c.url, R.syncCollectionBody(delta.token), 1);
  eq('live sync sees delete', R.syncChanges(sc.text, c.url, known, false).removed, [R.hrefKey(href)]);
}

console.log(`${passes} passed, ${failures} failed`);
process.exit(failures ? 1 : 0);
