// Tests for remote.js. Run: node remote.test.mjs
// Optional live test against a CalDAV server (e.g. a local Radicale):
//   CALDAV_URL=http://127.0.0.1:5299/ CALDAV_USER=u CALDAV_PASS=p node remote.test.mjs
import * as R from './remote.js';

let failures = 0, passes = 0;
function eq(name, got, want) {
  const g = JSON.stringify(got), w = JSON.stringify(want);
  if (g === w) { passes++; }
  else { failures++; console.log('FAIL', name, '\n  got ', g, '\n  want', w); }
}
function ok(name, cond, extra) {
  if (cond) passes++; else { failures++; console.log('FAIL', name, extra !== undefined ? JSON.stringify(extra) : ''); }
}

// --- URLs -------------------------------------------------------------------
eq('resolve abs path', R.resolveUrl('https://a.example/caldav/v2/', '/caldav/v2/x%40y/user'), 'https://a.example/caldav/v2/x%40y/user');
eq('resolve relative', R.resolveUrl('https://a.example/cal/home/', 'work/'), 'https://a.example/cal/home/work/');
eq('resolve absolute', R.resolveUrl('https://a.example/', 'https://b.example/x'), 'https://b.example/x');
eq('hrefKey decode', R.hrefKey('https://a.example/caldav/v2/me%40gmail.com/events/'), '/caldav/v2/me@gmail.com/events/');

// --- Google-style XML replies ----------------------------------------------
const principalXml = `<?xml version="1.0" encoding="UTF-8"?>
<D:multistatus xmlns:D="DAV:" xmlns:caldav="urn:ietf:params:xml:ns:caldav">
 <D:response><D:href>/caldav/v2/</D:href>
  <D:propstat><D:status>HTTP/1.1 200 OK</D:status><D:prop>
   <D:current-user-principal><D:href>/caldav/v2/me%40gmail.com/user</D:href></D:current-user-principal>
  </D:prop></D:propstat>
  <D:propstat><D:status>HTTP/1.1 404 Not Found</D:status><D:prop><caldav:calendar-home-set/></D:prop></D:propstat>
 </D:response>
</D:multistatus>`;
eq('principal', R.principalInfo(principalXml, 'https://apidata.googleusercontent.com/caldav/v2/'),
   { principal: 'https://apidata.googleusercontent.com/caldav/v2/me%40gmail.com/user', home: null });

const homeXml = `<?xml version="1.0"?><d:multistatus xmlns:d="DAV:" xmlns:cal="urn:ietf:params:xml:ns:caldav">
<d:response><d:href>/caldav/v2/me%40gmail.com/user</d:href><d:propstat><d:prop>
<cal:calendar-home-set><d:href>/caldav/v2/me%40gmail.com/</d:href></cal:calendar-home-set>
</d:prop><d:status>HTTP/1.1 200 OK</d:status></d:propstat></d:response></d:multistatus>`;
eq('home', R.principalInfo(homeXml, 'https://apidata.googleusercontent.com/caldav/v2/me%40gmail.com/user').home,
   'https://apidata.googleusercontent.com/caldav/v2/me%40gmail.com/');

const calsXml = `<?xml version="1.0" encoding="UTF-8"?>
<D:multistatus xmlns:D="DAV:" xmlns:C="urn:ietf:params:xml:ns:caldav" xmlns:CS="http://calendarserver.org/ns/" xmlns:ICAL="http://apple.com/ns/ical/">
 <D:response><D:href>/caldav/v2/me%40gmail.com/</D:href><D:propstat><D:status>HTTP/1.1 200 OK</D:status><D:prop><D:resourcetype><D:collection/></D:resourcetype></D:prop></D:propstat></D:response>
 <D:response><D:href>/caldav/v2/me%40gmail.com/events/</D:href><D:propstat><D:status>HTTP/1.1 200 OK</D:status><D:prop>
   <D:resourcetype><D:collection/><C:calendar/></D:resourcetype>
   <D:displayname>Mary Lucia &amp; Co</D:displayname>
   <ICAL:calendar-color>#9fe1e7ff</ICAL:calendar-color>
   <CS:getctag>63901234</CS:getctag>
   <C:supported-calendar-component-set><C:comp name="VEVENT"/></C:supported-calendar-component-set>
   <D:current-user-privilege-set><D:privilege><D:read/></D:privilege><D:privilege><D:write/></D:privilege></D:current-user-privilege-set>
 </D:prop></D:propstat></D:response>
 <D:response><D:href>/caldav/v2/family123%40group.calendar.google.com/events/</D:href><D:propstat><D:status>HTTP/1.1 200 OK</D:status><D:prop>
   <D:resourcetype><D:collection/><C:calendar/></D:resourcetype>
 </D:prop></D:propstat>
 <D:propstat><D:status>HTTP/1.1 404 Not Found</D:status><D:prop><D:displayname/></D:prop></D:propstat></D:response>
 <D:response><D:href>/tasks/</D:href><D:propstat><D:status>HTTP/1.1 200 OK</D:status><D:prop>
   <D:resourcetype><D:collection/><C:calendar/></D:resourcetype>
   <C:supported-calendar-component-set><C:comp name="VTODO"/></C:supported-calendar-component-set>
 </D:prop></D:propstat></D:response>
</D:multistatus>`;
const cals = R.calendarList(calsXml, 'https://apidata.googleusercontent.com/caldav/v2/me%40gmail.com/');
eq('calendar count', cals.length, 2);
eq('calendar 1', cals[0], {
  url: 'https://apidata.googleusercontent.com/caldav/v2/me%40gmail.com/events/',
  key: '/caldav/v2/me@gmail.com/events/', name: 'Mary Lucia & Co', color: '#9FE1E7',
  ctag: '63901234', syncToken: null, writable: true });
eq('calendar 2 unnamed', [cals[1].name, cals[1].color, cals[1].writable], [null, null, null]);
eq('change marker', R.changeMarker(calsXml.replace(/<D:response><D:href>\/caldav\/v2\/me%40gmail.com\/<\/D:href>.*?<\/D:response>/s, '')), '63901234|');

const etagXml = `<d:multistatus xmlns:d="DAV:">
<d:response><d:href>/caldav/v2/me%40gmail.com/events/</d:href><d:propstat><d:prop><d:resourcetype><d:collection/></d:resourcetype></d:prop><d:status>HTTP/1.1 200 OK</d:status></d:propstat></d:response>
<d:response><d:href>/caldav/v2/me%40gmail.com/events/a.ics</d:href><d:propstat><d:prop><d:getetag>"1"</d:getetag><d:resourcetype/></d:prop><d:status>HTTP/1.1 200 OK</d:status></d:propstat></d:response>
<d:response><d:href>/caldav/v2/me%40gmail.com/events/b.ics</d:href><d:propstat><d:prop><d:getetag>"2"</d:getetag><d:resourcetype/></d:prop><d:status>HTTP/1.1 200 OK</d:status></d:propstat></d:response>
</d:multistatus>`;
eq('diff etags', R.diffEtags(etagXml, 'https://apidata.googleusercontent.com/caldav/v2/me%40gmail.com/events/',
     { '/caldav/v2/me@gmail.com/events/a.ics': '"1"', '/caldav/v2/me@gmail.com/events/gone.ics': '"9"' }),
   { fetch: ['/caldav/v2/me%40gmail.com/events/b.ics'],
     removed: ['/caldav/v2/me@gmail.com/events/gone.ics'],
     etags: { '/caldav/v2/me@gmail.com/events/a.ics': '"1"', '/caldav/v2/me@gmail.com/events/b.ics': '"2"' } });

ok('multiget body', R.multigetBody(['/x/a&b.ics']).indexOf('<d:href>/x/a&amp;b.ics</d:href>') > 0);

// --- iCalendar --------------------------------------------------------------
const VTZ_LA = `BEGIN:VTIMEZONE
TZID:America/Los_Angeles
X-LIC-LOCATION:America/Los_Angeles
BEGIN:DAYLIGHT
TZOFFSETFROM:-0800
TZOFFSETTO:-0700
TZNAME:PDT
DTSTART:19700308T020000
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU
END:DAYLIGHT
BEGIN:STANDARD
TZOFFSETFROM:-0700
TZOFFSETTO:-0800
TZNAME:PST
DTSTART:19701101T020000
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU
END:STANDARD
END:VTIMEZONE`;
const cal = (body, tz = VTZ_LA) => `BEGIN:VCALENDAR\r\nPRODID:-//Google Inc//Google Calendar 70.9054//EN\r\nVERSION:2.0\r\n${tz}\n${body}\nEND:VCALENDAR\r\n`;

// Weekly Monday 9-10 LA, one date excluded, one moved, one cancelled.
const weekly = cal(`BEGIN:VEVENT
DTSTART;TZID=America/Los_Angeles:20261005T090000
DTEND;TZID=America/Los_Angeles:20261005T100000
RRULE:FREQ=WEEKLY;BYDAY=MO;UNTIL=20261231T235959Z
EXDATE;TZID=America/Los_Angeles:20261019T090000
UID:weekly@google.com
SUMMARY:Standup
LOCATION:Room 1
DESCRIPTION:Join: https://meet.google.com/abc-defg-hij
END:VEVENT
BEGIN:VEVENT
DTSTART;TZID=America/Los_Angeles:20261013T140000
DTEND;TZID=America/Los_Angeles:20261013T150000
RECURRENCE-ID;TZID=America/Los_Angeles:20261012T090000
UID:weekly@google.com
SUMMARY:Standup (moved)
END:VEVENT
BEGIN:VEVENT
DTSTART;TZID=America/Los_Angeles:20261026T090000
DTEND;TZID=America/Los_Angeles:20261026T100000
RECURRENCE-ID;TZID=America/Los_Angeles:20261026T090000
STATUS:CANCELLED
UID:weekly@google.com
SUMMARY:Standup
END:VEVENT`);

const allDay = cal(`BEGIN:VEVENT
DTSTART;VALUE=DATE:20261020
DTEND;VALUE=DATE:20261023
UID:trip@google.com
SUMMARY:Trip to Boston
END:VEVENT`, '');

const declined = cal(`BEGIN:VEVENT
DTSTART:20261014T170000Z
DTEND:20261014T180000Z
UID:declined@google.com
SUMMARY:Declined meeting
ORGANIZER:mailto:boss@example.com
ATTENDEE;PARTSTAT=DECLINED:mailto:Me@Gmail.com
END:VEVENT`, '');

const noTzDef = cal(`BEGIN:VEVENT
DTSTART;TZID=Europe/London:20261015T090000
DTEND;TZID=Europe/London:20261015T093000
UID:london@x
SUMMARY:Call London
END:VEVENT
BEGIN:VEVENT
DTSTART;VALUE=DATE:20261016
UID:noend@x
SUMMARY:Birthday
RRULE:FREQ=YEARLY
END:VEVENT`, '');

const r = R.setCalendar('cal1', [
  { key: 'w', etag: '1', ics: weekly },
  { key: 'a', etag: '1', ics: allDay },
  { key: 'd', etag: '1', ics: declined },
  { key: 'n', etag: '1', ics: noTzDef },
  { key: 'bad', etag: '1', ics: 'BEGIN:VCALENDAR\nthis is not ical' },
], { selfEmails: ['me@gmail.com'] });
eq('setCalendar count', r.count, 4);
eq('setCalendar errors', r.errors.length, 1);

const oct = R.expand(['cal1'], Date.UTC(2026, 9, 1), Date.UTC(2026, 10, 1));
const titles = oct.map(o => o.title + ' ' + o.start.M + '/' + o.start.d).sort();
eq('october occurrences', titles, [
  'Birthday 10/16', 'Call London 10/15',
  'Standup (moved) 10/13', 'Standup 10/5', 'Trip to Boston 10/20',
]);
const standup = oct.find(o => o.title === 'Standup');
eq('standup fields', [standup.start.h, standup.start.tz, standup.end.h, standup.location, standup.rrule.freq, standup.rrule.interval, standup.allDay],
   [9, 'America/Los_Angeles', 10, 'Room 1', 'WEEKLY', 1, false]);
eq('standup utc', standup.start.utc, Date.UTC(2026, 9, 5, 16, 0, 0));
const moved = oct.find(o => o.title === 'Standup (moved)');
eq('moved', [moved.start.d, moved.start.h, moved.start.tz], [13, 14, 'America/Los_Angeles']);
const trip = oct.find(o => o.title === 'Trip to Boston');
eq('all-day', [trip.allDay, trip.start.date, trip.start.tz, trip.end.d], [true, true, null, 23]);
const london = oct.find(o => o.title === 'Call London');
eq('unknown tz kept', [london.start.tz, london.start.h, london.start.utc], ['Europe/London', 9, null]);
const bday = oct.find(o => o.title === 'Birthday');
eq('all-day no end', [bday.end.d, bday.allDay], [17, true]);

// November: Standup until Dec 31 (Mondays) + daylight-saving switch Nov 1.
const nov = R.expand(['cal1'], Date.UTC(2026, 10, 1), Date.UTC(2026, 11, 1));
const novStandups = nov.filter(o => o.title === 'Standup');
eq('november mondays', novStandups.map(o => o.start.d), [2, 9, 16, 23, 30]);
eq('after DST still 9am wall clock, utc 17:00', [novStandups[0].start.h, novStandups[0].start.utc], [9, Date.UTC(2026, 10, 2, 17)]);

// Next year: series ended, birthday continues.
const y27 = R.expand(['cal1'], Date.UTC(2027, 9, 1), Date.UTC(2027, 10, 1)).map(o => o.title);
eq('2027', y27, ['Birthday']);

// Unchanged etag reuses the parse; removing a calendar empties it.
eq('reuse', R.setCalendar('cal1', [{ key: 'a', etag: '1', ics: allDay }]).count, 1);
R.removeCalendar('cal1');
eq('removed', R.expand(['cal1'], 0, Date.UTC(2030, 0, 1)).length, 0);

// Daily event since 2010: still fast and bounded.
const daily = cal(`BEGIN:VEVENT
DTSTART;TZID=America/Los_Angeles:20100101T070000
DTEND;TZID=America/Los_Angeles:20100101T073000
RRULE:FREQ=DAILY
UID:daily@x
SUMMARY:Meds
END:VEVENT`);
R.setCalendar('cal2', [{ key: 'x', etag: '1', ics: daily }]);
let t0 = Date.now();
const dailyOcc = R.expand(['cal2'], Date.UTC(2026, 9, 1), Date.UTC(2026, 10, 1));
const ms = Date.now() - t0;
ok('daily count ~31-33', dailyOcc.length >= 31 && dailyOcc.length <= 33, dailyOcc.length);
ok('daily fast (<1500ms)', ms < 1500, ms);

// JWT
const payload = { email: 'me@gmail.com', name: 'Mary Lucía' };
const b64 = Buffer.from(JSON.stringify(payload)).toString('base64').replace(/=+$/, '').replace(/\+/g, '-').replace(/\//g, '_');
eq('jwt', R.jwtPayload('x.' + b64 + '.sig'), payload);

// call() bridge
eq('call ok', JSON.parse(R.call('hrefKey', JSON.stringify(['/a%40b/']))), { ok: true, result: '/a@b/' });
eq('call error', JSON.parse(R.call('parseNothing', '[]')).ok, false);

// --- Optional live test --------------------------------------------------------
if (process.env.CALDAV_URL) {
  const base = process.env.CALDAV_URL;
  const auth = 'Basic ' + Buffer.from(process.env.CALDAV_USER + ':' + process.env.CALDAV_PASS).toString('base64');
  async function dav(method, url, body, depth) {
    const res = await fetch(url, { method, body, headers: { Authorization: auth, Depth: String(depth), 'Content-Type': 'application/xml; charset=utf-8' } });
    return { status: res.status, text: await res.text() };
  }
  let resp = await dav('PROPFIND', base, R.propfindPrincipalBody(), 0);
  let info = R.principalInfo(resp.text, base);
  ok('live principal', resp.status === 207 && info.principal, resp.status);
  let home = info.home;
  if (!home) {
    resp = await dav('PROPFIND', info.principal, R.propfindHomeBody(), 0);
    home = R.principalInfo(resp.text, info.principal).home;
  }
  ok('live home', !!home, home);
  resp = await dav('PROPFIND', home, R.propfindCalendarsBody(), 1);
  const live = R.calendarList(resp.text, home);
  ok('live calendars', live.length >= 1, live);
  const c = live[0];
  resp = await dav('PROPFIND', c.url, R.propfindCtagBody(), 0);
  ok('live marker', !!R.changeMarker(resp.text), resp.text.slice(0, 300));
  resp = await dav('PROPFIND', c.url, R.propfindEtagsBody(), 1);
  const diff = R.diffEtags(resp.text, c.url, {});
  ok('live etags', diff.fetch.length >= 1, diff);
  resp = await dav('REPORT', c.url, R.multigetBody(diff.fetch), 1);
  const items = R.resources(resp.text);
  eq('live multiget count', items.length, diff.fetch.length);
  const set = R.setCalendar('live', items, {});
  eq('live parse errors', set.errors, []);
  const occ = R.expand(['live'], Date.UTC(2026, 9, 1), Date.UTC(2026, 11, 1));
  console.log('live calendars:', live.map(x => [x.name, x.color, x.writable]));
  console.log('live occurrences:', occ.map(o => o.title + ' ' + o.start.M + '/' + o.start.d + ' ' + o.start.h + ':' + o.start.m + ' ' + o.start.tz));
  ok('live occurrences', occ.length >= 1);
}

console.log(`${passes} passed, ${failures} failed`);
process.exit(failures ? 1 : 0);
