# Third-party code

quickentry.bundle.js includes chrono-node 2.10.2 (https://github.com/wanasit/chrono), under the MIT licence:

```
The MIT License

Copyright (c) 2014, Wanasit Tanakitrungruang

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
```

---

remote.bundle.js (built from remote.js) includes:

- **ical.js 2.2.1** (https://github.com/kewisch/ical.js), unmodified, under the
  Mozilla Public License 2.0 (https://www.mozilla.org/MPL/2.0/). Its source code
  is available at the link above and is installed by `npm ci` in this folder
  (node_modules/ical.js). The MPL covers ical.js's own files only; the rest of
  this project stays under its own licence.
- **fast-xml-parser 5.11.1** (https://github.com/NaturalIntelligence/fast-xml-parser),
  MIT licence, Copyright (c) 2017 Amit Kumar Gupta.
- Its helper packages, all MIT licence: strnum, anynum, @nodable/entities,
  is-unsafe, path-expression-matcher, xml-naming (Natural Intelligence and
  contributors).

The MIT licence text above applies to each MIT package, with its own
copyright line. Full licence files are in node_modules after `npm ci`.
