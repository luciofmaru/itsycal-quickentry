# Quick entry for Itsycal

Type an event in plain English in the bar above the month (or at the top of
the New Event form) and the event fills itself in as you type. Press Return (or click Save Event) to save.
Everything is parsed locally; the text isn't sent to Google or anyone else. Events
go to the chosen calendar: one of the Mac's (iCloud etc., through macOS) or one
of Itsycal's own accounts (Google, CalDAV; see below).

## What it understands

| You type | You get |
|---|---|
| `Lunch with Sam Friday 1pm at Nopa` | title, Fri 1:00 pm, location "Nopa" |
| `Dentist Tue 3:30pm for 45 min` | 3:30–4:15 pm |
| `Review Friday 2-3:30pm` | 2:00–3:30 pm |
| `Trip to Boston Oct 20-23` | all-day, 20–23 Oct |
| `Conference in Chicago Nov 3 for 3 days` | all-day 3–5 Nov, location "Chicago" |
| `Call mom tomorrow` | all-day tomorrow |
| `Dinner tonight` / `Lunch at noon` | timed |
| `Team sync every Monday at 9am /work` | weekly, in the calendar whose name starts with "work" |
| `Yoga every Tue and Thu 6pm` | weekly on Tue and Thu |
| `Book club every other Wednesday 7pm for 2 hours` | every 2 weeks, 7–9 pm |
| `Standup weekdays 9:15am until Dec 1` | Mon–Fri, ending 1 Dec |
| `Physio every weekday 8am for 6 weeks` | Mon–Fri for six weeks |
| `Piano every Sat 11am 10 times` | 10 occurrences |
| `Pay rent monthly on Nov 1` | monthly |

- **Location** comes after `at`, `@`, or `in` + a capitalised word
  (`in Paris`, `in Room 5`). `in the backyard` stays in the title.
- **Calendar tag** is `/` plus a word. It matches a writable calendar whose
  name equals it or starts with it, ignoring case and punctuation.
- **Repeats** the Repeat menu can show ("Every Week", "Every 2 Weeks"...) are
  selected there. Anything else ("Every Tue, Thu", "…, 10 times") appears as
  an extra item at the bottom of the Repeat menu.
- If you edit the Title or Location field by hand, quick entry stops changing
  that field. Dates, repeat and calendar always follow the quick-entry text.

## Files

- `quickentry.js` – the rules, on top of [chrono](https://github.com/wanasit/chrono) (MIT).
- `test.mjs` – test phrases with expected results.
- `../Itsycal/quickentry.bundle.js` – the built bundle the app loads. **Generated; don't edit.**
- `../Itsycal/QuickEntryParser.{h,m}` – runs the bundle in JavaScriptCore.
- `../Itsycal/EventViewController.m` – the quick-entry field and form wiring.
- `remote.js` – CalDAV and iCalendar handling for Itsycal's own calendar
  accounts (reads the server's XML replies, expands repeating events), using
  fast-xml-parser (MIT) and ical.js (MPL-2.0). Tests: `remote.test.mjs`.
- `../Itsycal/remote.bundle.js` – the built bundle. **Generated; don't edit.**

## Itsycal's own calendar accounts

Settings → Accounts connects Google accounts directly (no macOS Internet
Accounts) and plain CalDAV accounts such as Radicale or Purelymail.

- Google sign-in uses your own OAuth client ("Desktop app") from
  console.cloud.google.com. Its ID and secret are typed once in Settings and
  kept in the Mac's keychain, never in this repository.
- Sign-in happens in the browser. Google sends the browser back to a one-time
  page Itsycal serves on this Mac only (127.0.0.1, random port, PKCE).
- Each account's long-term sign-in token or password is kept in the keychain.
  Calendar copies are kept in ~/Library/Application Support so they show
  instantly and offline. Itsycal syncs every 5 minutes and after waking.
- Which Google calendars appear (e.g. a shared Family calendar) is chosen at
  calendar.google.com/calendar/syncselect. Names and colours come from Google's
  Calendar API if it's enabled for the OAuth client; otherwise Itsycal guesses.
- Events in these calendars can be added (form or quick entry, `/name` picks
  the calendar), edited and deleted in Itsycal; changes go straight to the
  account. Repeating events ask whether to change one occurrence or all.
  Edits keep fields Itsycal doesn't show (guests, video-call details).
  Changes use the server's ETag, so an event changed elsewhere since the
  last sync is never overwritten; Itsycal re-syncs and asks you to retry.
- An account can be marked **View only** (for a backup copy such as Radicale).
- Settings → Accounts → "New events go to" picks the default calendar,
  which can be a Google calendar.

To check the CalDAV code against a real server:

```sh
CALDAV_URL=https://example.org/calendar/ CALDAV_USER=me CALDAV_PASS=… node remote.test.mjs
```

## Changing the rules

Requires Node.js (on the M1: `brew install node`).

```sh
cd QuickEntry
npm install
npm test          # run the test phrases and calendar tests
npm run build     # rebuild ../Itsycal/quickentry.bundle.js and remote.bundle.js
```

Then rebuild the app in Xcode. The build targets Safari 12's JavaScript engine
so the bundle runs on macOS Mojave. Avoid regex lookbehind (`(?<=…)`,
`(?<!…)`) in new rules: Mojave can't run it and the bundler can't convert it.
