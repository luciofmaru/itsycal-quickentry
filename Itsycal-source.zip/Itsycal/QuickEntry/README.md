# Quick entry for Itsycal

Type an event in plain English at the top of Itsycal's New Event form and the
form fills itself in as you type. Press Return (or click Save Event) to save.
Everything is parsed locally; nothing is sent to Google or anyone else. Events
are saved through macOS's calendar system, so they sync to whichever account
the chosen calendar belongs to (Google via Internet Accounts, iCloud, etc.).

## What it understands

| You type | You get |
|---|---|
| `Lunch with Sam Friday 1pm at Nopa` | title, Fri 1:00 pm, location "Nopa" |
| `Dentist Tue 3:30pm for 45 min` | 3:30–4:15 pm |
| `Review Friday 2-3:30pm` | 2:00–3:30 pm |
| `Trip to Boston Oct 20-23` | all-day, 20–23 Oct |
| `Conference in Chicago Nov 3 for 3 days` | all-day 3–5 Nov, location "Chicago" |
| `Call mom tomorrow` | all-day tomorrow |
| `Dinner tonight` / `Lunch at noon` | timed |
| `Team sync every Monday at 9am /work` | weekly, in the calendar whose name starts with "work" |
| `Yoga every Tue and Thu 6pm` | weekly on Tue and Thu |
| `Book club every other Wednesday 7pm for 2 hours` | every 2 weeks, 7–9 pm |
| `Standup weekdays 9:15am until Dec 1` | Mon–Fri, ending 1 Dec |
| `Physio every weekday 8am for 6 weeks` | Mon–Fri for six weeks |
| `Piano every Sat 11am 10 times` | 10 occurrences |
| `Pay rent monthly on Nov 1` | monthly |

- **Location** comes after `at`, `@`, or `in` + a capitalised word
  (`in Paris`, `in Room 5`). `in the backyard` stays in the title.
- **Calendar tag** is `/` plus a word. It matches a writable calendar whose
  name equals it or starts with it, ignoring case and punctuation.
- **Repeats** the Repeat menu can show ("Every Week", "Every 2 Weeks"...) are
  selected there. Anything else ("Every Tue, Thu", "…, 10 times") appears as
  an extra item at the bottom of the Repeat menu.
- If you edit the Title or Location field by hand, quick entry stops changing
  that field. Dates, repeat and calendar always follow the quick-entry text.

## Files

- `quickentry.js` – the rules, on top of [chrono](https://github.com/wanasit/chrono) (MIT).
- `test.mjs` – test phrases with expected results.
- `../Itsycal/quickentry.bundle.js` – the built bundle the app loads. **Generated; don't edit.**
- `../Itsycal/QuickEntryParser.{h,m}` – runs the bundle in JavaScriptCore.
- `../Itsycal/EventViewController.m` – the quick-entry field and form wiring.

## Changing the rules

Requires Node.js (on the M1: `brew install node`).

```sh
cd QuickEntry
npm install
npm test          # run the test phrases
npm run build     # rebuild ../Itsycal/quickentry.bundle.js
```

Then rebuild the app in Xcode. The build targets Safari 12's JavaScript engine
so the bundle runs on macOS Mojave. Avoid regex lookbehind (`(?<=…)`,
`(?<!…)`) in new rules: Mojave can't run it and the bundler can't convert it.
