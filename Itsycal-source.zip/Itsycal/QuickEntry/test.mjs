// Run: node QuickEntry/test.mjs   (from the repo root, after npm install in QuickEntry)
// Reference time for every case: Saturday 10 Oct 2026, 10:00 local time.
import { parseObject } from './quickentry.js';

const REF = new Date(2026, 9, 10, 10, 0).getTime();
const d = (mo, day, h = 0, mi = 0) => new Date(2026, mo - 1, day, h, mi).getTime();

const cases = [
  ['Lunch with Sam Friday 1pm at Nopa',
    { title: 'Lunch with Sam', location: 'Nopa', allDay: false, start: d(10, 16, 13), end: null }],
  ['Dentist Tuesday 3:30pm for 45 min',
    { title: 'Dentist', allDay: false, start: d(10, 13, 15, 30), end: d(10, 13, 16, 15) }],
  ['Team sync every Monday at 9am /work',
    { title: 'Team sync', calendar: 'work', start: d(10, 12, 9), recurrence: { frequency: 'weekly', interval: 1, daysOfWeek: [2] } }],
  ['Trip to Boston Oct 20-23',
    { title: 'Trip to Boston', allDay: true, start: d(10, 20), end: d(10, 23) }],
  ['Call mom tomorrow',
    { title: 'Call mom', allDay: true, start: d(10, 11), end: d(10, 11) }],
  ['Standup daily 9:15am until Dec 1',
    { title: 'Standup', allDay: false, start: d(10, 11, 9, 15), recurrence: { frequency: 'daily', interval: 1, until: d(12, 1) } }],
  ['Yoga every Tue and Thu 6pm',
    { title: 'Yoga', start: d(10, 13, 18), recurrence: { frequency: 'weekly', interval: 1, daysOfWeek: [3, 5] } }],
  ['Coffee @ Blue Bottle 3pm',
    { title: 'Coffee', location: 'Blue Bottle', start: d(10, 10, 15) }],
  ['Book club every other Wednesday 7pm for 2 hours',
    { title: 'Book club', start: d(10, 14, 19), end: d(10, 14, 21), recurrence: { frequency: 'weekly', interval: 2, daysOfWeek: [4] } }],
  ['Conference in Chicago Nov 3 for 3 days',
    { title: 'Conference', location: 'Chicago', allDay: true, start: d(11, 3), end: d(11, 5) }],
  ['Pay rent monthly on Nov 1',
    { title: 'Pay rent', allDay: true, start: d(11, 1), recurrence: { frequency: 'monthly', interval: 1 } }],
  ['Physio every weekday 8am for 6 weeks',
    { title: 'Physio', start: d(10, 12, 8), recurrence: { frequency: 'weekly', daysOfWeek: [2, 3, 4, 5, 6], until: d(11, 22) } }],
  ['Meeting 3-4pm',
    { title: 'Meeting', start: d(10, 10, 15), end: d(10, 10, 16) }],
  ['Pick up dry cleaning',
    { title: 'Pick up dry cleaning', hasDate: false, start: null }],
  ['Flu shot Oct 14 10am at CVS on Main St',
    { title: 'Flu shot', location: 'CVS on Main St', start: d(10, 14, 10) }],
  ['Piano lessons every Sat 11am 10 times',
    { title: 'Piano lessons', start: d(10, 10, 11), // today, 11am is still ahead
      recurrence: { daysOfWeek: [7], count: 10 } }],
  ['Pizza night in the backyard Friday 6pm',
    { title: 'Pizza night in the backyard', location: null, start: d(10, 16, 18) }],
  ['Lunch Friday with Sam at 1pm',
    { title: 'Lunch with Sam', start: d(10, 16, 13) }],
  ['Pizza night',
    { title: 'Pizza night', hasDate: false }],
  ['Dinner tonight',
    { title: 'Dinner', allDay: false }],
  ['Breakfast every Sat 9am',
    { title: 'Breakfast', start: d(10, 17, 9) }], // today's 9am has passed
  ['Review Friday 2-3:30pm',
    { title: 'Review', start: d(10, 16, 14), end: d(10, 16, 15, 30) }],
  ['Offsite Oct 20 9am to Oct 22 5pm',
    { title: 'Offsite', start: d(10, 20, 9), end: d(10, 22, 17) }],
  ['Interview in Room 5 Monday 10am',
    { title: 'Interview', location: 'Room 5', start: d(10, 12, 10) }],
  ['Standup weekdays 9:15am until Dec 1',
    { title: 'Standup', start: d(10, 12, 9, 15), recurrence: { daysOfWeek: [2, 3, 4, 5, 6], until: d(12, 1) } }],
  ['Lunch Fri 1pm at Nopa /work',
    { title: 'Lunch', location: 'Nopa', calendar: 'work', start: d(10, 16, 13) }],
  ['Lunch at noon',
    { title: 'Lunch', start: d(10, 10, 12) }],
];

let fail = 0;
for (const [input, want] of cases) {
  const got = parseObject(input, REF);
  const problems = [];
  for (const [k, v] of Object.entries(want)) {
    if (k === 'recurrence') {
      for (const [rk, rv] of Object.entries(v)) {
        const gv = got.recurrence && got.recurrence[rk];
        if (JSON.stringify(gv) !== JSON.stringify(rv)) problems.push(`recurrence.${rk}: got ${JSON.stringify(gv)} want ${JSON.stringify(rv)}`);
      }
    } else if (JSON.stringify(got[k]) !== JSON.stringify(v)) {
      const show = x => (typeof x === 'number' && x > 1e11) ? new Date(x).toString().slice(0, 21) : JSON.stringify(x);
      problems.push(`${k}: got ${show(got[k])} want ${show(v)}`);
    }
  }
  if (problems.length) { fail++; console.log('FAIL', JSON.stringify(input), '\n   ', problems.join('\n    ')); }
  else console.log('ok  ', input);
}
console.log(`\n${cases.length - fail}/${cases.length} passed`);
process.exit(fail ? 1 : 0);
